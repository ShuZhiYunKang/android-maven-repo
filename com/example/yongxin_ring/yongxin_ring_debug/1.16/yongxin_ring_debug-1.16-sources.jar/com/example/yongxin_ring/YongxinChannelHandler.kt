package com.example.yongxin_ring

import android.R.attr.version
import android.app.Activity
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothAdapter.LeScanCallback
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.lm.sdk.DataApi
import com.lm.sdk.LmAPI
import com.lm.sdk.LogicalApi
import com.lm.sdk.OtaApi
import com.lm.sdk.inter.ICreateToken
import com.lm.sdk.inter.IHeartListener
import com.lm.sdk.inter.IHistoryListener
import com.lm.sdk.inter.IQ2Listener
import com.lm.sdk.inter.ITempListener
import com.lm.sdk.inter.LmOtaProgressListener
import com.lm.sdk.inter.VersionCallback
import com.lm.sdk.library.constant.Constant
import com.lm.sdk.library.utils.PreferencesUtils
import com.lm.sdk.mode.BleDeviceInfo
import com.lm.sdk.mode.HistoryDataBean
import com.lm.sdk.utils.BLEUtils
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.EventChannel.EventSink
import io.flutter.plugin.common.EventChannel.StreamHandler
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class YongxinChannelHandler(private val application: Application) : MethodCallHandler,
    StreamHandler {
    private var eventSink: EventSink? = null

    private val broadcastManager: BroadcastManager = BroadcastManager(application)
    private val devicesMap = HashMap<String, BleDeviceInfo>()
    private var connectedDevice: BleDeviceInfo? = null

    private var readDatasSuccess = false


    init {
        val broadcastReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val action = intent?.action
                if (action == BluetoothDevice.ACTION_ACL_CONNECTED) {
                    eventSink?.success(mapOf("event" to "connectStateCallback", "data" to true))
                } else if (action == BluetoothDevice.ACTION_ACL_DISCONNECTED) {
                    eventSink?.success(mapOf("event" to "connectStateCallback", "data" to false))
                }
            }
        }
        val intentFilter = IntentFilter()
        intentFilter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        intentFilter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        intentFilter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
        application.registerReceiver(broadcastReceiver, intentFilter);
    }


    private val leScanCallback =
        LeScanCallback { device, rssi, bytes ->
            if (device == null || TextUtils.isEmpty(device.name)) return@LeScanCallback
            //是否符合条件，符合条件，会返回戒指设备信息
            val bleDeviceInfo =
                LogicalApi.getBleDeviceInfoWhenBleScan(device, rssi, bytes) ?: return@LeScanCallback
            if (!devicesMap.containsKey(device.address)) {
                devicesMap[device.address] = bleDeviceInfo
                eventSink?.success(
                    mapOf(
                        "event" to "scanResult",
                        "data" to devicesMap.values.map {
                            mapOf(
                                "mac" to it.device.address,
                                "rssi" to it.rssi,
                                "peripheralName" to it.device.name
                            )
                        }
                    )
                )
            }
        }

    override fun onMethodCall(call: MethodCall, result: Result) {
        val args = call.arguments as? Map<String, Any>
        when (call.method) {
            "startScan" -> {
                Log.d("YongxinChannelHandler", "startScan -------------- startScan")
                devicesMap.clear()
                BLEUtils.startLeScan(application, leScanCallback)
                result.success(true)
            }

            "stopScan" -> {
                Log.d("YongxinChannelHandler", "stopScan -------------- stopScan")
                BLEUtils.stopLeScan(application, leScanCallback)
                result.success(true)
            }

            "connectDevice" -> {
                BLEUtils.stopLeScan(application, leScanCallback)
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    Log.d(
                        "YongxinChannelHandler",
                        "connectDevice callback --------------========== "
                    )
                    result.success(true)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(BroadcastManager.ACTION_RING_CONNECTED, callback)
                val mac = args?.get("mac") as? String
                if (mac != null) {
                    val deviceInfo = devicesMap[mac]
                    if (deviceInfo != null) {
                        BLEUtils.connectLockByBLE(application, deviceInfo.device)
                        connectedDevice = deviceInfo
                    }else{
                        result.success(false)
                    }

                } else {
                    result.success(false)
                }
            }

            "currentDevice" -> {
                result.success(
                    mapOf(
                        "mac" to connectedDevice?.device?.address,
                        "rssi" to connectedDevice?.rssi,
                        "peripheralName" to connectedDevice?.device?.name
                    )
                )
            }

            "disconnectConnect" -> {
                BLEUtils.disconnectBLE(application)
                result.success(true)
            }

            "readBattery" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val p0 = intent.getIntExtra("p0", 0)
                    val p1 = intent.getIntExtra("p1", 0)
                    println("readBattery============ $p1")
                    result.success(p1)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(BroadcastManager.ACTION_RING_BATTERY, callback)
                LmAPI.GET_BATTERY(0x00.toByte()) // 0x00获取电量，0x01获取充电状态
            }

            "readHeartRate" -> {
                // waveForm：是否配置波形 0不上传 1上传
                // acqTime：采集时间 （byte）30是正常时间,0为一直采集
                var tempHeart = 0
                LmAPI.GET_HEART_ROTA(0x01.toByte(), 0x30.toByte(), object : IHeartListener {
                    override fun progress(progress: Int) {
                        println("readHeartRate============progress  $progress")
                        eventSink?.success(
                            mapOf(
                                "event" to "heartRateResult", "data" to mapOf(
                                    "progress" to progress, "result" to 0, "error" to null
                                )
                            )
                        )
                    }

                    override fun resultDataSHOUSHI(heart: Int, bloodOxygen: Int) {
                        Log.d("Yongxin", "心率: $heart, 血氧: $bloodOxygen")
                    }

                    // 心率，心率变异性，压力，温度
                    override fun resultData(heart: Int, heartRota: Int, stress: Int, temp: Int) {
                        println("readHeartRate============resultData  $heart $heartRota $stress $temp")
                        tempHeart = heart
                    }

                    override fun waveformData(
                        seq: Byte,
                        number: Byte,
                        waveData: String
                    ) {
                    } // 心率返回波形图数据分析：waveData

                    override fun rriData(seq: Byte, number: Byte, data: String) {} // 心率测量中的RR间期值
                    override fun error(value: Int) {}
                    override fun success() {
                        eventSink?.success(
                            mapOf(
                                "event" to "heartRateResult",
                                "data" to mapOf(
                                    "progress" to 1,
                                    "result" to tempHeart,
                                    "error" to null
                                )
                            )
                        )
                    }

                    override fun stop() {
                        Log.d("Yongxin", "停止心率检查")
                    }
                })
                result.success(true)
            }

            "readHRV" -> {
                result.success(true)
            }

            "readTemperature" -> {
                LmAPI.READ_TEMP(object : ITempListener {
                    override fun resultData(p0: Int) {
                        result.success(p0 / 100)
                    }
                    override fun testing(p0: Int) {}
                    override fun error(p0: Int) {}
                })
            }

            "readO2" -> {
                var tempO2 = 0
                LmAPI.GET_HEART_Q2(0x01.toByte(), object : IQ2Listener {
                    override fun progress(progress: Int) {
                        eventSink?.success(
                            mapOf(
                                "event" to "O2Result",
                                "data" to mapOf(
                                    "progress" to progress,
                                    "result" to 0,
                                    "error" to null
                                )
                            )
                        )
                    }

                    override fun resultData(heart: Int, o2: Int, temperature: Int) {
                        tempO2 = o2
                    }

                    override fun waveformData(p0: Byte, p1: Byte, p2: String?) {}
                    override fun error(p0: Int) {}
                    override fun success() {
                        eventSink?.success(
                            mapOf(
                                "event" to "O2Result",
                                "data" to mapOf(
                                    "progress" to 1,
                                    "result" to tempO2,
                                    "error" to null
                                )
                            )
                        )
                    }
                })
                result.success(true)
            }

            "readDatas" -> {
                val rawTimestamp = args?.get("timestamp")
                val timestamp = when (rawTimestamp) {
                    is Int -> rawTimestamp.toLong()
                    is Long -> rawTimestamp
                    else -> 0L
                }
                readDatasSuccess = false
                LmAPI.READ_HISTORY(
                    // if (readAll) 0x01.toByte() else 0x00.toByte(),
                    0x01.toByte(),
                    timestamp, // todo 时间戳
                    object : IHistoryListener {
                        override fun error(code: Int) {}
                        override fun success() {

                            if (!readDatasSuccess) {
                                result.success(true)
                            }
                            readDatasSuccess = true
                        }
                        override fun progress(progress: Double, historyDataBean: HistoryDataBean) {}
                    },
                )
            }
            "getObjectsFrom" -> {
                val timestamp = args?.get("time") as? Int
                val mac = connectedDevice?.device?.address
                if (timestamp != null && mac != null) {
                    val currentTime = System.currentTimeMillis() / 1000

                    val objects =
                        DataApi.instance.queryHistoryData(timestamp.toLong(), currentTime, mac)
                    result.success(objects.map { ringDataToMap(it) })
                } else {
                    result.success(null)
                }
            }

            "getObjectsOf" -> {
                val timestamp = args?.get("time") as? Int
                val mac = connectedDevice?.device?.address
                if (timestamp != null && mac != null) {
                    val calendar = Calendar.getInstance()
                    calendar.timeInMillis = timestamp.toLong() * 1000
                    calendar.set(Calendar.HOUR_OF_DAY, 0)
                    calendar.set(Calendar.MINUTE, 0)
                    calendar.set(Calendar.SECOND, 0)
                    calendar.set(Calendar.MILLISECOND, 0)
                    val startTime = calendar.timeInMillis / 1000

                    calendar.set(Calendar.HOUR_OF_DAY, 23)
                    calendar.set(Calendar.MINUTE, 59)
                    calendar.set(Calendar.SECOND, 59)
                    calendar.set(Calendar.MILLISECOND, 999)
                    val endTime = calendar.timeInMillis / 1000
                    val objects = DataApi.instance.queryHistoryData(startTime, endTime, mac)

                    result.success(objects.map { ringDataToMap(it) })
                } else {
                    result.success(listOf<Any>())
                }
            }

            "getLatestObject" -> {
                TODO("先不实现")
            }

            "setFrequency" -> {
                val frequency = args?.get("frequency") as? Int
                if (frequency != null) {
                    val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                        result.success(true)
                        broadcastManager.unregisterReceiver(receiver)
                    }
                    broadcastManager.registerReceiver(
                        BroadcastManager.ACTION_RING_SET_COLLECTION, callback
                    )
                    LmAPI.SET_COLLECTION(frequency)
                } else {
                    result.success(false)
                }

            }

            "readFrequency" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val data = intent.getIntExtra("p0", 0)
                    result.success(data)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_GET_COLLECTION, callback
                )
                LmAPI.GET_COLLECTION()
            }

            "readSteps" -> {
                println("========0000000000000000000----readSteps21111111111111111111111111111111111111")
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val step = intent.getIntExtra("p0", 0)
                    println("========0000000000000000000----readSteps $step")
                    result.success(step)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_STEPS, callback
                )
                LmAPI.STEP_COUNTING()
            }

            "isDidConnect" -> {
                result.success(BLEUtils.isConnecting())
            }

            "readTime" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val timeStamp = intent.getLongExtra("p1", 0L)
                    result.success(timeStamp)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(BroadcastManager.ACTION_RING_SYNC_TIME, callback)
                LmAPI.READ_TIME()
            }

            "syncTime" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    result.success(true)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(BroadcastManager.ACTION_RING_SYNC_TIME, callback)
                LmAPI.SYNC_TIME()
            }

            "readAppVersion" -> {
                // 固件版本号 0x00获取固件版本，0x01获取硬件版本
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val version: String? = intent.getStringExtra("p1")
                    Log.d("YongxinChannelHandler", "readAppVersion -------------- $version")
                    result.success(version)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_GET_VERSION, callback
                )
                LmAPI.GET_VERSION(0x00.toByte())
            }

            "readHardWareVersion" -> {
                // 硬件版本号 0x00获取固件版本，0x01获取硬件版本
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val version: String? = intent.getStringExtra("p1")
                    Log.d("YongxinChannelHandler", "readHardWareVersion -------------- $version")
                    result.success(version)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_GET_VERSION, callback
                )
                LmAPI.GET_VERSION(0x01.toByte())
            }

            "caculateSleep" -> {
                val timestamp = args?.get("time") as? Int
                println("========0000000000000000000----caculateSleep------------------------------- $timestamp")
                if (timestamp != null) {
                    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    sdf.timeZone = TimeZone.getDefault()
                    val date = Date(timestamp.toLong() * 1000)
                    val formattedDate = sdf.format(date)
                    val mac = connectedDevice?.device?.address
                    val sleep = LogicalApi.calculateSleep(formattedDate, mac, 0)
                    result.success(mapOf(
                        "hours" to sleep.hours,
                        "minutes" to sleep.minutes,
                        "allHours" to sleep.allHours,
                        "allMinutes" to sleep.allMinutes,
                        "sleepHours" to sleep.sleepHours,
                        "sleepMinutes" to sleep.sleepMinutes,
                        "highTime" to sleep.highTime,
                        "lowTime" to sleep.lowTime,
                        "ydTime" to sleep.ydTime,
                        "qxTime" to sleep.qxTime,
                        "start_time" to sleep.startTime,
                        "end_time" to sleep.endTime,
                        "sleepDataList" to sleep.historyDataBeanList.map { ringDataToMap(it) }
                    ))
                } else {
                    result.success(null)
                }
            }

            "createToken" -> {
                LogicalApi.createToken("9380f98857b04cf1a1e806c07b660820", "1046078572@qq.com", object : ICreateToken {
                    override fun getTokenSuccess() {
                        println("getTokenSuccess")
                        result.success(true)
                    }
                    override fun error(msg: String?) {
                        result.error("createTokenFail", msg, null)
                    }
                })
            }
            "checkDeviceVersion" -> {
                val version = args?.get("version") as String
                OtaApi.checkVersion(version, object : VersionCallback {
                    override fun success(newVersion: String?) {
                        result.success(newVersion)
                    }

                    override fun error() {
                        result.success(null);
                    }
                },YongxinRingPlugin.activity);
            }
            "startApolloOTA" -> {
                val version = args?.get("version") as String
                val device = connectedDevice?.device;
                val rssi = connectedDevice?.rssi;
                if (rssi != null) {
                    // 阻塞1秒
                    try {
                        Thread.sleep(1000)
                    } catch (e: InterruptedException) {
                        e.printStackTrace()
                    }

                    OtaApi.otaUpdateWithCheckVersion(
                        version,
                        YongxinRingPlugin.activity,
                        device,
                        rssi,
                        object : LmOtaProgressListener {
                            override fun error(message: String) {
                                println("OTAerror============ $message")
                                Handler(Looper.getMainLooper()).post {
                                    eventSink?.success(
                                        mapOf(
                                            "event" to "ringOtaProgress",
                                            "data" to -1
                                        )
                                    )
                                }
                            }
                            override fun onProgress(i: Int) {
                                println("OTAonProgress============ $i")
                                Handler(Looper.getMainLooper()).post {
                                    eventSink?.success(
                                        mapOf(
                                            "event" to "ringOtaProgress",
                                            "data" to i
                                        )
                                    )
                                }
                            }
                            override fun onComplete() {
                                println("OTAonComplete============ 101")
                                Handler(Looper.getMainLooper()).post {
                                    eventSink?.success(
                                        mapOf(
                                            "event" to "ringOtaProgress",
                                            "data" to 101
                                        )
                                    )
                                }
                            }
                            override fun isLatestVersion() {
                                println("OTAisLatestVersion============ 100")
                                Handler(Looper.getMainLooper()).post {
                                    eventSink?.success(
                                        mapOf(
                                            "event" to "ringOtaProgress",
                                            "data" to 101
                                        )
                                    )
                                }
                            }
                        })
                } else {
                    println("OTAerror============ rssi is null")
                    eventSink?.success(
                        mapOf(
                            "event" to "ringOtaProgress",
                            "data" to -2
                        )
                    )
                }
            }
            "getBluetoothRSSI" -> {
                result.success(connectedDevice?.rssi)
            }
            else -> result.notImplemented()
        }
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
    }

    private fun ringDataToMap(ringData: HistoryDataBean): Map<String, Any> {
        val rrValues = mutableListOf<Int>()
        val rrsData = ringData.rrBytes
        if (rrsData != null && rrsData.size >= 2) {
            for (i in rrsData.indices step 2) {
                if (i + 1 < rrsData.size) {
                    val lowByte = rrsData[i].toInt() and 0xFF
                    val highByte = rrsData[i + 1].toInt() and 0xFF
                    val value = lowByte or (highByte shl 8)
                    rrValues.add(value)
                }
            }
        }

        return mapOf(
            "total" to ringData.totalNumber,
            "serialNum" to ringData.indexNumber,
            "timestamp" to ringData.time,
            "steps" to ringData.stepCount,
            "rate" to ringData.heartRate,
            "o2" to ringData.bloodOxygen,
            "hrv" to ringData.heartRateVariability,
            "stress" to ringData.stressIndex,
            "temp" to ringData.temperature / 100,
            "sleep_type" to ringData.sleepType,
            "rr_nums" to ringData.rrCount,
            "rrs" to rrValues,
            "sport" to ringData.exerciseIntensity,
            "is_wear" to ringData.measurementMarker
        )
    }
}
