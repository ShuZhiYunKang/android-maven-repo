package com.example.yongxin_ring

import android.content.Intent
import android.util.Log
import com.lm.sdk.LmAPI
import com.lm.sdk.inter.IResponseListener
import com.lm.sdk.mode.SystemControlBean
import com.lm.sdk.utils.BLEUtils
import com.lm.sdk.utils.ConvertUtils
import com.lm.sdk.utils.DataCovertUtils

class YongxinResponseListener(private val broadcastManager: BroadcastManager) : IResponseListener {
    override fun lmBleConnecting(p0: Int) {
        Log.d("YongxinResponseListener", "lmBleConnecting -------------- $p0")
    }

    override fun lmBleConnectionSucceeded(p0: Int) {
        Log.d("YongxinResponseListener", "lmBleConnectionSucceeded -------------- $p0")
        BLEUtils.setGetToken(true)
        val intent = Intent(BroadcastManager.ACTION_RING_CONNECTED)
        intent.putExtra("p0", "ok")
        broadcastManager.sendBroadcast(intent)
    }

    override fun lmBleConnectionFailed(p0: Int) {
        Log.d("YongxinResponseListener", "lmBleConnectionFailed -------------- $p0")
    }

    override fun VERSION(p0: Byte, p1: String?) {
//       type	   byte  	0或1	0代表软件版本号 1代表硬件版本号
//       version	String	1.0.0.1	版本号
        val intent = Intent(BroadcastManager.ACTION_RING_GET_VERSION)
        intent.putExtra("p0", p0.toInt())
        intent.putExtra("p1", p1)
        broadcastManager.sendBroadcast(intent)
    }

    override fun syncTime(p0: Byte, p1: ByteArray) {
        val intent = Intent(BroadcastManager.ACTION_RING_SYNC_TIME)
        intent.putExtra("p0", p0)
        intent.putExtra("p1", ConvertUtils.BytesToLong(p1))
        broadcastManager.sendBroadcast(intent)
    }

    override fun stepCount(p0: ByteArray) {
        val intent = Intent(BroadcastManager.ACTION_RING_STEPS)
        intent.putExtra("p0", ConvertUtils.BytesToInt(p0))
        broadcastManager.sendBroadcast(intent)
    }

    override fun setUserInfo(result: Byte) {
        // 你可以在这里处理用户信息，比如保存到本地，或者进行一些其他操作
        // Log.d("Yongxin", "设置的用户信息: $result")
    }

    override fun getUserInfo(sex: Int, height: Int, weight: Int, age: Int) {
        TODO("Not yet implemented")
    }

    override fun clearStepCount(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun battery(p0: Byte, p1: Byte) {
        // 参数名称	类型	   示例值	说明
        // p0	byte   0或1	    0代表电池电量 1代表充电状态
        // p1	byte   0-100	电量
        // p1	byte   1	    0未充电 1充电中 2充满
        val intent = Intent(BroadcastManager.ACTION_RING_BATTERY)
        intent.putExtra("p0", p0.toInt())
        intent.putExtra("p1", p1.toInt())
        broadcastManager.sendBroadcast(intent)
    }

    override fun timeOut() {}

    override fun saveData(p0: String?) {}

    override fun reset(p0: ByteArray?) {
        TODO("Not yet implemented")
    }

    override fun setCollection(p0: Byte) {
        val intent = Intent(BroadcastManager.ACTION_RING_SET_COLLECTION)
        intent.putExtra("p0", p0.toInt())
        broadcastManager.sendBroadcast(intent)
    }

    override fun getCollection(p0: ByteArray) {
        val intent = Intent(BroadcastManager.ACTION_RING_GET_COLLECTION)
        intent.putExtra("p0", ConvertUtils.BytesToInt(p0))
        broadcastManager.sendBroadcast(intent)
    }

    override fun getSerialNum(p0: ByteArray?) {
        TODO("Not yet implemented")
    }

    override fun setSerialNum(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun cleanHistory(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun setBlueToolName(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun readBlueToolName(p0: Byte, p1: String?) {
        TODO("Not yet implemented")
    }

    override fun stopRealTimeBP(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun BPwaveformData(p0: Byte, p1: Byte, p2: String?) {
        TODO("Not yet implemented")
    }

    override fun onSport(p0: Int, p1: ByteArray?) {
        TODO("Not yet implemented")
    }

    override fun breathLight(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun SET_HID(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun GET_HID(p0: Byte, p1: Byte, p2: Byte) {
        TODO("Not yet implemented")
    }

    override fun GET_HID_CODE(p0: ByteArray?) {
        TODO("Not yet implemented")
    }

    override fun GET_CONTROL_AUDIO_ADPCM(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun SET_AUDIO_ADPCM_AUDIO(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun setAudio(p0: Short, p1: Int, p2: ByteArray?) {
        TODO("Not yet implemented")
    }

    override fun stopHeart(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun stopQ2(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun GET_ECG(p0: ByteArray?) {
        TODO("Not yet implemented")
    }

    override fun SystemControl(p0: SystemControlBean?) {
        TODO("Not yet implemented")
    }

    override fun CONTROL_AUDIO(p0: ByteArray?) {
        TODO("Not yet implemented")
    }

    override fun motionCalibration(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun stopBloodPressure(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun appBind(p0: SystemControlBean?) {
        TODO("Not yet implemented")
    }

    override fun appConnect(p0: SystemControlBean?) {
        TODO("Not yet implemented")
    }

    override fun appRefresh(p0: SystemControlBean?) {
        TODO("Not yet implemented")
    }
    
    override fun battery_push(b: Byte, datum: Byte) {
        // TODO("Not yet implemented")
        println("$b")
    }

    override fun TOUCH_AUDIO_FINISH_XUN_FEI() {
        TODO("Not yet implemented")
    }
}