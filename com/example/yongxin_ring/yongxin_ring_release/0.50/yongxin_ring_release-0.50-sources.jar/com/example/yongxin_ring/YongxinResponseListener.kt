package com.example.yongxin_ring

import android.content.Intent
import android.util.Log
import com.lm.sdk.LmAPI
import com.lm.sdk.inter.IResponseListener
import com.lm.sdk.mode.SystemControlBean
import com.lm.sdk.utils.BLEUtils
import com.lm.sdk.utils.ConvertUtils
import com.lm.sdk.utils.DataCovertUtils

class YongxinResponseListener(private val broadcastManager: BroadcastManager) : IResponseListener {
    private fun readIntValue(source: Any?, vararg names: String): Int? {
        if (source == null) return null
        for (name in names) {
            try {
                val getterName = "get" + name.replaceFirstChar { it.uppercase() }
                val method = source.javaClass.methods.firstOrNull {
                    it.name.equals(getterName, ignoreCase = true) && it.parameterCount == 0
                }
                if (method != null) {
                    val value = method.invoke(source)
                    if (value is Number) return value.toInt()
                }
            } catch (_: Exception) {
            }
            try {
                val field = source.javaClass.declaredFields.firstOrNull {
                    it.name.equals(name, ignoreCase = true)
                }
                if (field != null) {
                    field.isAccessible = true
                    val value = field.get(source)
                    if (value is Number) return value.toInt()
                }
            } catch (_: Exception) {
            }
        }
        return null
    }
    
    // 添加日志发送方法
    private fun sendLogToFlutter(message: String) {
        val data = mapOf(
            "event" to "nativeLog",
            "data" to mapOf(
                "message" to message,
                "timestamp" to System.currentTimeMillis() / 1000.0
            )
        )
        // 通过广播发送到YongxinChannelHandler
        try {
            val intent = Intent("com.example.yongxin_ring.FLUTTER_LOG")
            intent.putExtra("message", message)
            intent.putExtra("timestamp", System.currentTimeMillis() / 1000.0)
            broadcastManager.sendBroadcast(intent)
        } catch (e: Exception) {
            Log.e("YongxinResponseListener", "发送日志到Flutter失败: ${e.message}")
        }
    }
    
    override fun lmBleConnecting(p0: Int) {
        Log.d("YongxinResponseListener", "🔄 [SDK回调] lmBleConnecting 正在连接中, 参数: $p0")
        sendLogToFlutter("🔄 [SDK回调] lmBleConnecting 正在连接中, p0=$p0")
        BLEUtils.setConnecting(true);//连接中，防止重复连接
        sendLogToFlutter("🔄 [SDK回调] 已设置 BLEUtils.isConnecting=true")
    }

    override fun lmBleConnectionSucceeded(p0: Int) {
        Log.d("YongxinResponseListener", "✅ [SDK回调] lmBleConnectionSucceeded 连接成功, 参数: $p0")
        sendLogToFlutter("✅ [SDK回调] lmBleConnectionSucceeded 连接成功, p0=$p0")
        
        // BLEUtils.stopLeScan(Context context, BluetoothAdapter.LeScanCallback leScanCallback);
        BLEUtils.setConnecting(false);
        sendLogToFlutter("✅ [SDK回调] 已设置 BLEUtils.isConnecting=false")
        
        BLEUtils.setGetToken(true)
        sendLogToFlutter("✅ [SDK回调] 已设置 BLEUtils.setGetToken=true")
        
        val intent = Intent(BroadcastManager.ACTION_RING_CONNECTED)
        intent.putExtra("p0", "ok")
        sendLogToFlutter("✅ [SDK回调] 准备发送连接成功广播: ${BroadcastManager.ACTION_RING_CONNECTED}")
        
        broadcastManager.sendBroadcast(intent)
        sendLogToFlutter("✅ [SDK回调] 连接成功广播已发送")
    }

    override fun lmBleConnectionFailed(p0: Int) {
        Log.d("YongxinResponseListener", "❌ [SDK回调] lmBleConnectionFailed 连接失败, 参数: $p0")
        sendLogToFlutter("❌ [SDK回调] lmBleConnectionFailed 连接失败, p0=$p0")
        
        BLEUtils.setGetToken(false);//连接失败
        sendLogToFlutter("❌ [SDK回调] 已设置 BLEUtils.setGetToken=false")
        
        BLEUtils.setConnecting(false);
        sendLogToFlutter("❌ [SDK回调] 已设置 BLEUtils.isConnecting=false")
        
        val intent = Intent(BroadcastManager.ACTION_RING_DISCONNECTED)
        intent.putExtra("p0", "ok")
        sendLogToFlutter("❌ [SDK回调] 准备发送连接失败广播: ${BroadcastManager.ACTION_RING_DISCONNECTED}")
        
        broadcastManager.sendBroadcast(intent)
        sendLogToFlutter("❌ [SDK回调] 连接失败广播已发送")
    }

    override fun VERSION(p0: Byte, p1: String?) {
//       type	   byte  	0或1	0代表软件版本号 1代表硬件版本号
//       version	String	1.0.0.1	版本号
        val intent = Intent(BroadcastManager.ACTION_RING_GET_VERSION)
        intent.putExtra("p0", p0.toInt())
        intent.putExtra("p1", p1)
        broadcastManager.sendBroadcast(intent)
    }

    override fun syncTime(p0: Byte, p1: ByteArray) {
        val intent = Intent(BroadcastManager.ACTION_RING_SYNC_TIME)
        intent.putExtra("p0", p0)
        intent.putExtra("p1", ConvertUtils.BytesToInt(p1).toLong())
        broadcastManager.sendBroadcast(intent)
    }

    override fun stepCount(p0: ByteArray) {
        val intent = Intent(BroadcastManager.ACTION_RING_STEPS)
        intent.putExtra("p0", ConvertUtils.BytesToInt(p0))
        broadcastManager.sendBroadcast(intent)
    }

    override fun setUserInfo(result: Byte) {
        // 你可以在这里处理用户信息，比如保存到本地，或者进行一些其他操作
        // Log.d("Yongxin", "设置的用户信息: $result")
    }

    override fun getUserInfo(sex: Int, height: Int, weight: Int, age: Int) {
        TODO("Not yet implemented")
    }

    override fun clearStepCount(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun battery(p0: Byte, p1: Byte) {
        // 参数名称	类型	   示例值	说明
        // p0	byte   0或1	    0代表电池电量 1代表充电状态
        // p1	byte   0-100	电量
        // p1	byte   1	    0未充电 1充电中 2充满
        val intent = Intent(BroadcastManager.ACTION_RING_BATTERY)
        intent.putExtra("p0", p0.toInt())
        intent.putExtra("p1", p1.toInt())
        broadcastManager.sendBroadcast(intent)
    }

    override fun timeOut() {
        // 指令超时 超时5s
        // 可能出现的情况 蓝牙断连后发送指令。或者同时发送多个指令。或者历史数据上传的时候，主动测量了
        val intent = Intent(BroadcastManager.ACTION_INSTRUCT_TIMEOUT)
        broadcastManager.sendBroadcast(intent)
    }

    override fun saveData(p0: String?) {}

    override fun reset(p0: ByteArray?) {
        TODO("Not yet implemented")
    }

    override fun setCollection(p0: Byte) {
        val intent = Intent(BroadcastManager.ACTION_RING_SET_COLLECTION)
        intent.putExtra("p0", p0.toInt())
        broadcastManager.sendBroadcast(intent)
    }

    override fun getCollection(p0: ByteArray) {
        val intent = Intent(BroadcastManager.ACTION_RING_GET_COLLECTION)
        intent.putExtra("p0", ConvertUtils.BytesToInt(p0))
        broadcastManager.sendBroadcast(intent)
    }

    override fun getSerialNum(p0: ByteArray?) {
        TODO("Not yet implemented")
    }

    override fun setSerialNum(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun cleanHistory(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun setBlueToolName(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun readBlueToolName(p0: Byte, p1: String?) {
        TODO("Not yet implemented")
    }

    override fun stopRealTimeBP(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun BPwaveformData(p0: Byte, p1: Byte, p2: String?) {
        TODO("Not yet implemented")
    }

    override fun onSport(p0: Int, p1: ByteArray?) {
        TODO("Not yet implemented")
    }

    override fun breathLight(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun SET_HID(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun GET_HID(p0: Byte, p1: Byte, p2: Byte) {
        TODO("Not yet implemented")
    }

    override fun GET_HID_CODE(p0: ByteArray?) {
        TODO("Not yet implemented")
    }

    override fun GET_CONTROL_AUDIO_ADPCM(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun SET_AUDIO_ADPCM_AUDIO(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun setAudio(p0: Short, p1: Int, p2: ByteArray?) {
        TODO("Not yet implemented")
    }

    override fun stopHeart(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun stopQ2(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun GET_ECG(p0: ByteArray?) {
        TODO("Not yet implemented")
    }

    override fun SystemControl(p0: SystemControlBean?) {
        TODO("Not yet implemented")
    }

    override fun CONTROL_AUDIO(seq: Int, bytes: ByteArray?) {
        // 新版SDK：方法签名已改变，从 (ByteArray?) 改为 (seq: Int, bytes: ByteArray?)
        // TODO("Not yet implemented")
    }

    override fun motionCalibration(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun stopBloodPressure(p0: Byte) {
        TODO("Not yet implemented")
    }

    override fun appBind(p0: SystemControlBean?) {
        TODO("Not yet implemented")
    }

    override fun appConnect(p0: SystemControlBean?) {
        sendLogToFlutter("appConnect callback: ${p0?.toString() ?: "null"}")
        val intent = Intent(BroadcastManager.ACTION_APP_CONNECT)
        intent.putExtra("raw", p0?.toString() ?: "")
        intent.putExtra("battery", readIntValue(p0, "battery", "batteryLevel") ?: -1)
        intent.putExtra("chargingStatus", readIntValue(p0, "chargingStatus", "chargingState") ?: -1)
        intent.putExtra("stepCounting", readIntValue(p0, "stepCounting", "stepCount") ?: -1)
        intent.putExtra("collectionInterval", readIntValue(p0, "collectionInterval", "collectInterval") ?: -1)
        intent.putExtra("gomoreSleep", readIntValue(p0, "gomoreSleep", "isGoMoreSleepAlgorithmSupported") ?: -1)
        intent.putExtra("gomoreUserAge", readIntValue(p0, "gomoreUserAge", "gomoreAge", "age") ?: -1)
        intent.putExtra("gomoreUserGender", readIntValue(p0, "gomoreUserGender", "gomoreGender", "sex") ?: -1)
        intent.putExtra("gomoreUserHeight", readIntValue(p0, "gomoreUserHeight", "gomoreHeight", "height") ?: -1)
        intent.putExtra("gomoreUserWeight", readIntValue(p0, "gomoreUserWeight", "gomoreWeight", "weight") ?: -1)
        intent.putExtra("gomoreMaxHeartRate", readIntValue(p0, "gomoreMaxHeartRate", "maximumHeartRate", "maxHeartRate") ?: -1)
        intent.putExtra("gomoreRestingHeartRate", readIntValue(p0, "gomoreRestingHeartRate", "normalHeartRate") ?: -1)
        intent.putExtra("gomoreMaxOxygenUptake", readIntValue(p0, "gomoreMaxOxygenUptake", "maximalOxygenUptake") ?: -1)
        broadcastManager.sendBroadcast(intent)
    }

    override fun appRefresh(p0: SystemControlBean?) {
        TODO("Not yet implemented")
    }
    
    override fun battery_push(b: Byte, datum: Byte) {
        val intent = Intent(BroadcastManager.ACTION_BATTERY_PUSH)
        intent.putExtra("p0", datum.toInt())
        broadcastManager.sendBroadcast(intent)
    }

    override fun TOUCH_AUDIO_FINISH_XUN_FEI() {
        TODO("Not yet implemented")
    }
}