package com.example.yongxin_ring

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Base64
import android.util.Log
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.lm.sdk.utils.ConvertUtils

class BroadcastManager(private val application: Application) {
    // 发送广播
    fun sendBroadcast(intent: Intent) {
        Log.d("BroadcastManager", "sendBroadcast -------------- $intent")
        LocalBroadcastManager.getInstance(application).sendBroadcast(intent)
    }

    // 接收广播的
    fun registerReceiver(action: String, callback: (Intent, BroadcastReceiver) -> Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                Log.d("BroadcastManager", "registerReceiver onReceive -------------- $intent")
                intent?.let { callback(it, this) }
            }
        }
        LocalBroadcastManager.getInstance(application)
            .registerReceiver(receiver, IntentFilter(action))
    }

    // 取消注册广播
    fun unregisterReceiver(receiver: BroadcastReceiver) {
        LocalBroadcastManager.getInstance(application).unregisterReceiver(receiver)
    }

    
    companion object {

        // 定义广播的action
        const val ACTION_RING_CONNECTED = "com.example.yongxin_ring.ACTION_RING_CONNECTED"
        const val ACTION_RING_DISCONNECTED = "com.example.yongxin_ring.ACTION_RING_DISCONNECTED"

        const val ACTION_RING_BATTERY = "com.example.yongxin_ring.ACTION_RING_BATTERY"  // 电量
        const val ACTION_RING_SET_COLLECTION =
            "com.example.yongxin_ring.ACTION_RING_SET_COLLECTION"  // 设置采集周期
        const val ACTION_RING_GET_COLLECTION =
            "com.example.yongxin_ring.ACTION_RING_GET_COLLECTION"  // 读取采集周期
        const val ACTION_RING_STEPS = "com.example.yongxin_ring.ACTION_RING_STEPS"  // 步数
        const val ACTION_RING_SYNC_TIME = "com.example.yongxin_ring.ACTION_RING_SYNC_TIME"  // 同步时间
        const val ACTION_RING_GET_VERSION = "com.example.yongxin_ring.ACTION_RING_VERSION"  // 版本号

        const val ACTION_INSTRUCT_TIMEOUT = "com.example.yongxin_ring.ACTION_INSTRUCT_TIMEOUT" // 指令超时
        const val ACTION_BATTERY_PUSH = "com.example.yongxin_ring.ACTION_BATTERY_PUSH" // 电量推送
        const val ACTION_APP_CONNECT = "com.example.yongxin_ring.ACTION_APP_CONNECT" // 复合指令回调
    }
}