package com.example.yongxin_ring

import android.app.Application
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.lm.sdk.LmAPI
import com.lm.sdk.inter.IHistoryListener
import com.lm.sdk.inter.IWebHistoryResult
import com.lm.sdk.utils.BLEUtils

/** Owns every LmAPI history read across Flutter engines; never registers a null listener. */
internal object YongxinHistorySdk {
    private const val CANCELLED = -1002
    private const val READ_TIMEOUT_MS = 120_000L
    private val handler = Handler(Looper.getMainLooper())
    private val reads = HistoryReadCoordinator(
        post = { action -> handler.post { action() } },
        onLog = { Log.w("YongxinHistorySdk", it) }
    )
    private lateinit var application: Application
    private val noUpload = object : IWebHistoryResult {
        override fun updateHistoryFinish() = Unit
        override fun serviceError(message: String?) = Unit
    }

    val activeOperation: String? get() = reads.activeOperation

    fun initialize(application: Application) {
        this.application = application
        // Install before LmAPI.init/addWLSCmdListener enables incoming history callbacks.
        LmAPI.READ_HISTORY_AUTO(reads)
    }

    fun start(
        owner: Any,
        operation: String,
        listener: IHistoryListener,
        timeoutMillis: Long? = READ_TIMEOUT_MS,
        command: (IHistoryListener) -> Unit
    ): Long {
        check(Looper.myLooper() == Looper.getMainLooper())
        val token = reads.begin(owner, operation, listener)
        try {
            command(reads)
        } catch (error: Exception) {
            cancel(token, "start failed: $operation", notify = false)
            throw error
        }
        if (timeoutMillis != null) {
            handler.postDelayed({ cancel(token, "read timeout: $operation") }, timeoutMillis)
        }
        return token
    }

    fun prepareAutoRead(
        listener: IHistoryListener,
        mac: String?,
        webListener: IWebHistoryResult? = null
    ) {
        // This only sets listeners/MAC and clears the upload buffer. Configure it BEFORE
        // receiving data, not inside success(). Empty MAC disables stale automatic uploads.
        LmAPI.READ_HISTORY_AUTO_UPDATE_TO_SERVER(
            if (webListener != null) mac.orEmpty() else "",
            listener,
            webListener ?: noUpload
        )
    }

    fun cancelOwner(owner: Any, reason: String) {
        reads.tokenFor(owner)?.let { cancel(it, reason) }
    }

    fun cancel(token: Long, reason: String, notify: Boolean = true) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { cancel(token, reason, notify) }
            return
        }
        if (!reads.cancel(token, CANCELLED, notify)) return
        Log.w("YongxinHistorySdk", "Cancelling history read: $reason")
        try {
            BLEUtils.disconnectBLE(application)
        } catch (error: Exception) {
            Log.e("YongxinHistorySdk", "History transport disconnect failed", error)
        }
        handler.postDelayed({
            if (reads.isCurrent(token) && !BLEUtils.isConnected()) onDisconnected()
        }, 2_000L)
    }

    fun onDisconnected() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { onDisconnected() }
            return
        }
        // stopRepeatingTask() in 1.3.0 leaves runnable non-null and can stall the next read.
        // Let the scheduled task observe the empty queue instead.
        LmAPI.dataDeque.clear()
        reads.disconnected(CANCELLED)
    }
}
