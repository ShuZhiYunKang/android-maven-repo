package com.example.yongxin_ring

import com.lm.sdk.inter.IHistoryListener
import com.lm.sdk.mode.HistoryDataBean

/** One process-wide SDK listener. All calls are confined to the Android main thread. */
internal class HistoryReadCoordinator(
    private val post: (() -> Unit) -> Unit,
    private val onLog: (String) -> Unit
) : IHistoryListener {
    private sealed class Terminal {
        object Success : Terminal()
        object Empty : Terminal()
        data class Error(val code: Int) : Terminal()
    }

    private class Read(
        val token: Long,
        val owner: Any,
        val operation: String,
        var listener: IHistoryListener?,
        var draining: Boolean = false,
        var terminal: Terminal? = null,
        var finishPosted: Boolean = false,
        var transportClosed: Boolean = false
    )

    private var tokenSeed = 0L
    private var active: Read? = null
    private var idleCallbackLogged = false

    val activeOperation: String? get() = active?.operation

    fun begin(owner: Any, operation: String, listener: IHistoryListener): Long {
        check(active == null) { "History read still active: ${active?.operation}" }
        val token = ++tokenSeed
        active = Read(token, owner, operation, listener)
        idleCallbackLogged = false
        return token
    }

    fun isCurrent(token: Long): Boolean = active?.token == token

    fun tokenFor(owner: Any): Long? = active?.takeIf { it.owner === owner }?.token

    /** Fail the consumer now, but keep the gate until the requested disconnect is confirmed. */
    fun cancel(token: Long, code: Int, notify: Boolean = true): Boolean {
        val read = active?.takeIf { it.token == token && !it.draining } ?: return false
        read.draining = true
        val listener = read.listener
        read.listener = null
        if (notify) post { listener?.error(code) }
        return true
    }

    /** Only call after the BLE transport closed and its queued SDK packets were cleared. */
    fun disconnected(code: Int) {
        val read = active ?: return
        cancel(read.token, code)
        read.transportClosed = true
        complete(Terminal.Error(code))
    }

    override fun progress(progress: Double, historyDataBean: HistoryDataBean) {
        val read = active
        if (read == null) {
            logIdleCallback()
            return
        }
        if (!read.draining && read.terminal == null) {
            read.listener?.progress(progress, historyDataBean)
        }
    }

    override fun success() = complete(Terminal.Success)

    override fun noNewDataAvailable() = complete(Terminal.Empty)

    override fun error(code: Int) = complete(Terminal.Error(code))

    private fun complete(terminal: Terminal) {
        val read = active
        if (read == null) {
            logIdleCallback()
            return
        }
        // SDK sends success() followed immediately by noNewDataAvailable() for an empty read.
        if (read.terminal == null || terminal is Terminal.Error ||
            (read.terminal is Terminal.Success && terminal is Terminal.Empty)) {
            read.terminal = terminal
        }
        if (read.finishPosted || (read.draining && !read.transportClosed)) return
        read.finishPosted = true
        post {
            read.finishPosted = false
            if (active !== read) return@post
            // A terminal packet can beat the disconnect broadcast. Releasing now would let
            // the next read start on a connection that our cancellation is about to close.
            if (read.draining && !read.transportClosed) return@post
            // success() precedes SDK upload submission and DB insertion. Do not start the
            // next read or finish the consumer reentrantly inside that SDK callback.
            active = null
            val listener = read.listener
            read.listener = null
            when (val result = read.terminal) {
                is Terminal.Success -> listener?.success()
                is Terminal.Empty -> listener?.noNewDataAvailable()
                is Terminal.Error -> listener?.error(result.code)
                null -> Unit
            }
        }
    }

    private fun logIdleCallback() {
        if (idleCallbackLogged) return
        idleCallbackLogged = true
        // SDK still persists these packets; a later normal read/backfill can recover them.
        onLog("History callback without an active read; retaining SDK listener and local data")
    }
}
