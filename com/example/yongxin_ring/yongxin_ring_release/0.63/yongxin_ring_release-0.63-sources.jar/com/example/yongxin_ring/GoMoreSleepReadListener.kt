package com.example.yongxin_ring

import com.lm.sdk.inter.IGoMoreListener
import com.lm.sdk.mode.GoMoreSleep

/** Collect one SDK read while its owning attempt controls cancellation and completion. */
internal class GoMoreSleepReadListener(
    private val isActive: () -> Boolean,
    private val isCollecting: () -> Boolean,
    private val serialize: (GoMoreSleep?) -> Map<String, Any>,
    private val onProgress: (phase: String, count: Int, terminal: Boolean) -> Unit,
    private val onComplete: (phase: String, models: List<Map<String, Any>>) -> Unit,
    private val onLog: (String) -> Unit
) : IGoMoreListener {
    private val sleepList = ArrayList<Map<String, Any>>()

    override fun overviewOfSleep(goMoreSleep: GoMoreSleep?) = collect("overview", goMoreSleep)

    override fun sleepStaging(goMoreSleep: GoMoreSleep?) = collect("staging", goMoreSleep)

    private fun collect(phase: String, sleep: GoMoreSleep?) {
        if (!isCollecting()) return
        val model = serialize(sleep)
        val count = synchronized(sleepList) {
            if (!isCollecting()) return
            sleepList.add(model)
            sleepList.size
        }
        emitProgress(phase, count, terminal = false)
    }

    override fun dataUploadFinish() {
        if (!isActive()) {
            onLog("ignore stale finish")
            return
        }
        val models = synchronized(sleepList) { ArrayList(sleepList) }
        emitProgress("finish", models.size, terminal = true)
        onComplete("finish", models)
    }

    override fun noSleepData() {
        if (!isActive()) {
            onLog("ignore stale noSleepData")
            return
        }
        val count = synchronized(sleepList) { sleepList.size }
        // The SDK can report an empty sleep segment after overview/staging packets,
        // then send more packets or dataUploadFinish. It does not erase earlier data.
        if (count > 0) {
            emitProgress("noSleepData", count, terminal = false)
            onLog("noSleepData with collected models count=$count; waiting for finish")
            return
        }
        emitProgress("noSleepData", 0, terminal = true)
        onComplete("noSleepData", emptyList())
    }

    private fun emitProgress(phase: String, count: Int, terminal: Boolean) {
        if (isCollecting()) onProgress(phase, count, terminal)
    }
}
