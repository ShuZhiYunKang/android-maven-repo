package com.example.yongxin_ring

import android.R.attr.version
import android.app.Activity
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothAdapter.LeScanCallback
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.lm.sdk.DataApi
import com.lm.sdk.LmAPI
import com.lm.sdk.LogicalApi
import com.lm.sdk.OtaApi
import com.lm.sdk.inter.I6axisListener
import com.lm.sdk.inter.ICreateToken
import com.lm.sdk.inter.IHeartListener
import com.lm.sdk.inter.IHistoryListener
import com.lm.sdk.inter.IQ2Listener
import com.lm.sdk.inter.IShiMiListener
import com.lm.sdk.inter.ITempListener
import com.lm.sdk.inter.LmOtaProgressListener
import com.lm.sdk.inter.VersionCallback
import com.lm.sdk.library.constant.Constant
import com.lm.sdk.library.utils.PreferencesUtils
import com.lm.sdk.mode.BleDeviceInfo
import com.lm.sdk.mode.HistoryDataBean
import com.lm.sdk.utils.BLEUtils
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.EventChannel.EventSink
import io.flutter.plugin.common.EventChannel.StreamHandler
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
//import com.lm.sdk.inter.IWebFirmwareListResult
//import com.lm.sdk.mode.Firmware
import com.lm.sdk.mode.VersionBean
import com.tenmeter.smlibrary.utils.SMGameClient
import com.tenmeter.smlibrary.entity.SMGameInfo
import com.tenmeter.smlibrary.entity.SMGameSensor
import com.tenmeter.smlibrary.listener.IGameGSensor
import com.tenmeter.smlibrary.listener.IGameListCallback
import com.tenmeter.smlibrary.listener.IGameOpenListener

class YongxinChannelHandler(private val application: Application) : MethodCallHandler,
    StreamHandler {
    private var eventSink: EventSink? = null

    private val broadcastManager: BroadcastManager = BroadcastManager(application)
    private val devicesMap = HashMap<String, BleDeviceInfo>()
    private var connectedDevice: BleDeviceInfo? = null
    private var directConnectedMac: String? = null

    private var readDatasSuccess = false
    
    // 游戏相关变量
    private var recentPlayedGame: SMGameInfo? = null
    private var recentGameStartTime: Long = 0
    private var gameActivity: Activity? = null
    private var gameDebugEnabled: Boolean = false

    private var axisListener: IShiMiListener = object : IShiMiListener {
        override fun startPlay6Zhou(
            state: Int,
            sszx: Int,
            ssfy: Int,
            sssd: Int,
            sjzx: Int,
            sjfy: Int,
            zzjsd: Int,
            js: Int,
            xzjsd: Int,
            yzjsd: Int
        ) {
            // 如果有游戏正在运行，自动发送传感器数据到游戏
            if (recentPlayedGame != null) {
                try {
                    val gameSensorData = SMGameSensor(
                        sszx, ssfy, sssd, sjzx, sjfy, zzjsd, js, xzjsd, yzjsd
                    )
                    SMGameClient.getInstance().movePlayer(1, gameSensorData)
                } catch (e: Exception) {
                    Log.e("YongxinChannelHandler", "发送游戏传感器数据失败", e)
                }
            }
        }

        override fun startPlay3Zhou(state: Int, zzjsd: Int, xzjsd: Int, yzjsd: Int) {
            Log.e(
                "YongxinChannelHandler",
                "3轴数据"
            )
        }

        override fun stopPlay(success: Boolean) {
            Log.e(
                "YongxinChannelHandler",
                "停止游戏 "
            )
        }

        override fun acceleration(success: Boolean) {
            Log.e(
                "YongxinChannelHandler",
                "acceleration"
            )
        }

    }
    // Computed property作为connectedDevice的替代
    private val currentConnectedDevice: BleDeviceInfo?
        get() {
            return connectedDevice ?: directConnectedMac?.let { mac ->
                val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
                bluetoothAdapter?.getRemoteDevice(mac)?.let { device ->
                    // 创建一个临时的BleDeviceInfo对象
                    // 由于无法直接创建BleDeviceInfo，我们返回null并在使用时单独处理
                    null
                }
            }
        }

    // 获取当前连接设备的MAC地址
    private val currentDeviceMac: String?
        get() = connectedDevice?.device?.address ?: directConnectedMac

    // 获取当前连接设备的RSSI
    private val currentDeviceRssi: Int
        get() = connectedDevice?.rssi ?: -50

    // 获取当前连接设备的名称
    private val currentDeviceName: String
        get() = connectedDevice?.device?.name ?: "Unknown Ring"

    // 通用的测量错误处理方法
    private fun handleMeasurementError(eventName: String, errorCode: Int) {
        // 将Android SDK的错误码映射到Flutter端的RingErrorEnum枚举值
        val mappedErrorCode = when (errorCode) {
            0 -> 4   // noWear (未佩戴)
            2 -> 5   // charging (充电中)
            4 -> 0   // fail (繁忙，不执行 - 映射为失败)
            else -> 0 // fail (未知错误 - 映射为失败)
        }

        val progress = if (errorCode == 0) 1 else 100

        eventSink?.success(
            mapOf(
                "event" to eventName,
                "data" to mapOf(
                    "progress" to progress,
                    "result" to 0,
                    "error" to mappedErrorCode
                )
            )
        )
    }

    init {

        val broadcastReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val action = intent?.action
                // 蓝牙状态改变
                if (action == BluetoothAdapter.ACTION_STATE_CHANGED) {
                    val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    when (state) {
                        BluetoothAdapter.STATE_OFF -> {
                            Log.d("Bluetooth", "系统蓝牙已关闭")
                            eventSink?.success(mapOf("event" to "connectStateCallback", "data" to false))
                        }
                        BluetoothAdapter.STATE_TURNING_OFF -> Log.d("Bluetooth", "蓝牙正在关闭")
                        BluetoothAdapter.STATE_ON -> Log.d("Bluetooth", "蓝牙已开启")
                        BluetoothAdapter.STATE_TURNING_ON -> Log.d("Bluetooth", "蓝牙正在开启")
                    }
                }
            }
        }
        val intentFilter = IntentFilter()
        intentFilter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        application.registerReceiver(broadcastReceiver, intentFilter)

        val connectStateCallback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
            val action = intent.action
            if (action == BroadcastManager.ACTION_RING_CONNECTED) {
                eventSink?.success(mapOf("event" to "connectStateCallback", "data" to true))
            } else if (action == BroadcastManager.ACTION_RING_DISCONNECTED) {
                connectedDevice = null // 断开连接后，清空连接设备
                eventSink?.success(mapOf("event" to "connectStateCallback", "data" to false))
            }
        }
        broadcastManager.registerReceiver(
            BroadcastManager.ACTION_RING_CONNECTED, connectStateCallback
        )
        broadcastManager.registerReceiver(
            BroadcastManager.ACTION_RING_DISCONNECTED, connectStateCallback
        )

        broadcastManager.registerReceiver(
            BroadcastManager.ACTION_BATTERY_PUSH, { intent, receiver ->
                val p0 = intent.getIntExtra("p0", 0)
                println("readBattery============ $p0")
                eventSink?.success(mapOf("event" to "batteryPush", "data" to p0))
            }
        )
        
        broadcastManager.registerReceiver(
            BroadcastManager.ACTION_INSTRUCT_TIMEOUT, { intent, receiver ->
                eventSink?.success(
                    mapOf(
                        "event" to "instructTimeout", "data" to mapOf(
                            "connectedDevice" to (if (connectedDevice == null) null else true),
                        )
                    )
                )
            }
        )
    }

    @RequiresApi(Build.VERSION_CODES.ECLAIR)
    private val leScanCallback =
        LeScanCallback { device, rssi, bytes ->
            if (device == null || TextUtils.isEmpty(device.name)) return@LeScanCallback
            //是否符合条件，符合条件，会返回戒指设备信息
            val bleDeviceInfo =
                LogicalApi.getBleDeviceInfoWhenBleScan(device, rssi, bytes, false)
                    ?: return@LeScanCallback
            if (!devicesMap.containsKey(device.address)) {
                devicesMap[device.address] = bleDeviceInfo
                eventSink?.success(
                    mapOf(
                        "event" to "scanResult",
                        "data" to devicesMap.values.map {
                            mapOf(
                                "mac" to it.device.address,
                                "rssi" to it.rssi,
                                "peripheralName" to it.device.name
                            )
                        }
                    )
                )
            }
        }

    private fun setResult(
        call: MethodCall,
        result: Result,
        boolResultHasBeenSet: Boolean,
        success: Any?
    ): Boolean {
        Log.d(
            "YongxinChannelHandler",
            "call.method: ${call.method}, boolResultHasBeenSet: $boolResultHasBeenSet, setResult -------------- setResult $success"
        )
        if (!boolResultHasBeenSet) {
            result.success(success)
        }
        return true;
    }

    override fun onMethodCall(call: MethodCall, result: Result) {
        var boolResultHasBeenSet = false;
        val args = call.arguments as? Map<String, Any>

        val failed_callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
            Log.e(
                "YongxinChannelHandler",
                "Bluetooth connection failed"
            )
            if (!boolResultHasBeenSet && (call.method != "connectDeviceDirectly" || call.method != "connectDevice")) {
                //result.error("Bluetooth connection failed", "Bluetooth connection failed", null)
                boolResultHasBeenSet = true
            }
            broadcastManager.unregisterReceiver(receiver)
        }

        broadcastManager.registerReceiver(
            BroadcastManager.ACTION_RING_DISCONNECTED, failed_callback
        )

        when (call.method) {
            "startScan" -> {
                Log.d("YongxinChannelHandler", "startScan -------------- startScan")
                devicesMap.clear()
                BLEUtils.startLeScan(application, leScanCallback)
                boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
            }

            "stopScan" -> {
                Log.d("YongxinChannelHandler", "stopScan -------------- stopScan")
                BLEUtils.stopLeScan(application, leScanCallback)
                boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
            }

            "connectDevice" -> {
                BLEUtils.stopLeScan(application, leScanCallback)
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    Log.d(
                        "YongxinChannelHandler",
                        "connectDevice callback --------------========== "
                    )
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(BroadcastManager.ACTION_RING_CONNECTED, callback)
                val mac = args?.get("mac") as? String
                if (mac != null) {
                    val deviceInfo = devicesMap[mac]
                    if (deviceInfo != null) {
                        BLEUtils.connectLockByBLE(application, deviceInfo.device)
                        connectedDevice = deviceInfo
                    } else {
                        boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                    }

                } else {
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                }
            }

            "currentDevice" -> {
                val mac = currentDeviceMac
                if (mac != null) {
                    boolResultHasBeenSet = setResult(
                        call, result, boolResultHasBeenSet,
                        mapOf(
                            "mac" to mac,
                            "rssi" to currentDeviceRssi,
                            "peripheralName" to currentDeviceName
                        )
                    )
                } else {
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, null)
                }
            }

            "disconnectConnect" -> {
                BLEUtils.disconnectBLE(application)

                // 清理设备映射和连接状态
                devicesMap.clear()
                connectedDevice = null
                directConnectedMac = null
                readDatasSuccess = false
                BLEUtils.setConnecting(false);
                boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
            }

            "readBattery" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val p0 = intent.getIntExtra("p0", 0)
                    val p1 = intent.getIntExtra("p1", 0)
                    println("readBattery============ $p1")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, p1)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(BroadcastManager.ACTION_RING_BATTERY, callback)
                LmAPI.GET_BATTERY(0x00.toByte()) // 0x00获取电量，0x01获取充电状态
            }

            "readHeartRate" -> {
                var duration = args?.get("duration") as? Int
                // 如果持续时间为null就默认30s
                if (duration == null) {
                    duration = 0x30
                }
                // waveForm：是否配置波形 0不上传 1上传
                // acqTime：采集时间 （byte）30是正常时间,0为一直采集
                var tempHeart = 0
                LmAPI.GET_HEART_ROTA(0x01.toByte(), duration.toByte(), object : IHeartListener {
                    override fun progress(progress: Int) {
                        println("readHeartRate============progress  $progress")
                        eventSink?.success(
                            mapOf(
                                "event" to "heartRateResult", "data" to mapOf(
                                    "progress" to progress, "result" to tempHeart, "error" to null
                                )
                            )
                        )
                    }

                    override fun resultDataSHOUSHI(heart: Int, bloodOxygen: Int) {
                        Log.d("Yongxin", "心率: $heart, 血氧: $bloodOxygen")
                    }

                    // 心率，心率变异性，压力，温度
                    override fun resultData(heart: Int, heartRota: Int, stress: Int, temp: Int) {
                        println("readHeartRate============resultData  $heart $heartRota $stress $temp")
                        tempHeart = heart
                    }

                    override fun waveformData(
                        seq: Byte,
                        number: Byte,
                        waveData: String
                    ) {
                    } // 心率返回波形图数据分析：waveData

                    override fun rriData(seq: Byte, number: Byte, data: String) {} // 心率测量中的RR间期值
                    override fun error(value: Int) {
                        handleMeasurementError("heartRateResult", value)
                    }

                    override fun success() {
                        eventSink?.success(
                            mapOf(
                                "event" to "heartRateResult",
                                "data" to mapOf(
                                    "progress" to 100,
                                    "result" to tempHeart,
                                    "error" to null
                                )
                            )
                        )
                    }

                    override fun stop() {
                        Log.d("Yongxin", "停止心率检查")
                    }
                })
                boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
            }

            "readHRV" -> {
                boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
            }

            "readTemperature" -> {
                LmAPI.READ_TEMP(object : ITempListener {
                    override fun resultData(p0: Int) {
                        boolResultHasBeenSet =
                            setResult(call, result, boolResultHasBeenSet, p0 / 100)
                    }

                    override fun testing(p0: Int) {}
                    override fun error(p0: Int) {}
                })
            }

            "readO2" -> {
                var tempO2 = 0
                LmAPI.GET_HEART_Q2(0x01.toByte(), object : IQ2Listener {
                    override fun progress(progress: Int) {
                        eventSink?.success(
                            mapOf(
                                "event" to "O2Result",
                                "data" to mapOf(
                                    "progress" to progress,
                                    "result" to 0,
                                    "error" to null
                                )
                            )
                        )
                    }

                    override fun resultData(heart: Int, o2: Int, temperature: Int) {
                        tempO2 = o2
                    }

                    override fun waveformData(p0: Byte, p1: Byte, p2: String?) {}
                    override fun error(value: Int) {
                        handleMeasurementError("O2Result", value)
                    }

                    override fun success() {
                        eventSink?.success(
                            mapOf(
                                "event" to "O2Result",
                                "data" to mapOf(
                                    "progress" to 100,
                                    "result" to tempO2,
                                    "error" to null
                                )
                            )
                        )
                    }
                })
                boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
            }

            "readDatas" -> {
                val rawTimestamp = args?.get("timestamp")
                val timestamp = when (rawTimestamp) {
                    is Int -> rawTimestamp.toLong()
                    is Long -> rawTimestamp
                    else -> 0L
                }
                readDatasSuccess = false
                LmAPI.READ_HISTORY(
                    // if (readAll) 0x01.toByte() else 0x00.toByte(),
                    0x01.toByte(),
                    timestamp, // todo 时间戳
                    object : IHistoryListener {
                        override fun error(code: Int) {}
                        override fun success() {

                            if (!readDatasSuccess) {
                                boolResultHasBeenSet =
                                    setResult(call, result, boolResultHasBeenSet, true)
                            }
                            readDatasSuccess = true
                        }

                        override fun progress(progress: Double, historyDataBean: HistoryDataBean) {}
                        override fun noNewDataAvailable() {}
                    },
                )
            }

            "getObjectsFrom" -> {
                val timestamp = args?.get("time") as? Int
                val mac = currentDeviceMac
                println("getObjectsFrom timestamp: $timestamp mac: $mac")
                if (timestamp != null && mac != null) {
                    val currentTime = System.currentTimeMillis() / 1000

                    val objects =
                        DataApi.instance.queryHistoryData(timestamp.toLong(), currentTime, mac)
                    boolResultHasBeenSet = setResult(
                        call,
                        result,
                        boolResultHasBeenSet,
                        objects.map { ringDataToMap(it) })
                } else {
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, null)
                }
            }

            "getObjectsOf" -> {
                val timestamp = args?.get("time") as? Int
                val mac = currentDeviceMac
                if (timestamp != null && mac != null) {
                    val calendar = Calendar.getInstance()
                    calendar.timeInMillis = timestamp.toLong() * 1000
                    calendar.set(Calendar.HOUR_OF_DAY, 0)
                    calendar.set(Calendar.MINUTE, 0)
                    calendar.set(Calendar.SECOND, 0)
                    calendar.set(Calendar.MILLISECOND, 0)
                    val startTime = calendar.timeInMillis / 1000

                    calendar.set(Calendar.HOUR_OF_DAY, 23)
                    calendar.set(Calendar.MINUTE, 59)
                    calendar.set(Calendar.SECOND, 59)
                    calendar.set(Calendar.MILLISECOND, 999)
                    val endTime = calendar.timeInMillis / 1000
                    val objects = DataApi.instance.queryHistoryData(startTime, endTime, mac)

                    boolResultHasBeenSet = setResult(
                        call,
                        result,
                        boolResultHasBeenSet,
                        objects.map { ringDataToMap(it) })
                } else {
                    boolResultHasBeenSet =
                        setResult(call, result, boolResultHasBeenSet, listOf<Any>())
                }
            }

            "getLatestObject" -> {
                TODO("先不实现")
            }

            "setFrequency" -> {
                val frequency = args?.get("frequency") as? Int
                if (frequency != null) {
                    val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                        boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                        broadcastManager.unregisterReceiver(receiver)
                    }
                    broadcastManager.registerReceiver(
                        BroadcastManager.ACTION_RING_SET_COLLECTION, callback
                    )
                    LmAPI.SET_COLLECTION(frequency)
                } else {
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                }

            }

            "readFrequency" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val data = intent.getIntExtra("p0", 0)
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, data)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_GET_COLLECTION, callback
                )
                LmAPI.GET_COLLECTION()
            }

            "readSteps" -> {
                println("========0000000000000000000----readSteps21111111111111111111111111111111111111")
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val step = intent.getIntExtra("p0", 0)
                    println("========0000000000000000000----readSteps $step")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, step)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_STEPS, callback
                )
                LmAPI.STEP_COUNTING()
            }

            "isDidConnect" -> {
                boolResultHasBeenSet =
                    setResult(call, result, boolResultHasBeenSet, BLEUtils.isConnecting())
            }

            "readTime" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val timeStamp = intent.getLongExtra("p1", 0L)
                    boolResultHasBeenSet =
                        setResult(call, result, boolResultHasBeenSet, timeStamp.toDouble())
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(BroadcastManager.ACTION_RING_SYNC_TIME, callback)
                LmAPI.READ_TIME()
            }

            "syncTime" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                    broadcastManager.unregisterReceiver(receiver)
                }

                broadcastManager.registerReceiver(BroadcastManager.ACTION_RING_SYNC_TIME, callback)
                val offset = getTimeZone()
                LmAPI.SYNC_TIME_ZONE(offset)
            }

            "readAppVersion" -> {
                // 固件版本号 0x00获取固件版本，0x01获取硬件版本
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val version: String? = intent.getStringExtra("p1")
                    Log.d("YongxinChannelHandler", "readAppVersion -------------- $version")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, version)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_GET_VERSION, callback
                )
                LmAPI.GET_VERSION(0x00.toByte())
            }

            "readHardWareVersion" -> {
                // 硬件版本号 0x00获取固件版本，0x01获取硬件版本
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val version: String? = intent.getStringExtra("p1")
                    Log.d("YongxinChannelHandler", "readHardWareVersion -------------- $version")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, version)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_GET_VERSION, callback
                )
                LmAPI.GET_VERSION(0x01.toByte())
            }

            "calculateSleep" -> {
                val timestamp = args?.get("time") as? Int
                println("========0000000000000000000----calculateSleep------------------------------- $timestamp")
                if (timestamp != null) {
                    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    sdf.timeZone = TimeZone.getDefault()
                    val date = Date(timestamp.toLong() * 1000)
                    val formattedDate = sdf.format(date)
                    val mac = currentDeviceMac
                    val sleep = LogicalApi.calculateSleep(formattedDate, mac, 0)
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, mapOf(
                        "hours" to sleep.hours,
                        "minutes" to sleep.minutes,
                        "allHours" to sleep.allHours,
                        "allMinutes" to sleep.allMinutes,
                        "sleepHours" to sleep.sleepHours,
                        "sleepMinutes" to sleep.sleepMinutes,
                        "highTime" to sleep.highTime,
                        "lowTime" to sleep.lowTime,
                        "ydTime" to sleep.ydTime,
                        "qxTime" to sleep.qxTime,
                        "start_time" to sleep.startTime,
                        "end_time" to sleep.endTime,
                        "sleepDataList" to sleep.historyDataBeanList.map { ringDataToMap(it) }
                    ))
                } else {
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, null)
                }
            }

            "createToken" -> {
                LogicalApi.createToken(
                    "9380f98857b04cf1a1e806c07b660820",
                    "1046078572@qq.com",
                    object : ICreateToken {
                        override fun getTokenSuccess() {
                            println("getTokenSuccess")
                            boolResultHasBeenSet =
                                setResult(call, result, boolResultHasBeenSet, true)
                        }

                        override fun error(msg: String?) {
                            boolResultHasBeenSet =
                                setResult(call, result, boolResultHasBeenSet, null)
                        }
                    })
            }

            "getFirmwareVersionList" -> {
//                LogicalApi.firmwareList("Z3R", object : IWebFirmwareListResult {
//                    override fun firmwareListResult(firmwareList: MutableList<Firmware>?) {
//                        val mappedList = firmwareList?.map { firmware ->
//                            mapOf(
//                                "fileName" to firmware.fileName,
//                                "filePath" to firmware.filePath,
//                                "fileUrl" to firmware.fileUrl
//                            )
//                        }
//                        boolResultHasBeenSet =
//                            setResult(call, result, boolResultHasBeenSet, mappedList)
//                    }
//
//                    override fun serviceError(message: String?) {
//                        boolResultHasBeenSet =
//                            setResult(call, result, boolResultHasBeenSet, null)
//                    }
//                })

            }

            "firmwareDownload" -> {
                val version = args?.get("version") as? String
                val fileUrl = args?.get("fileUrl") as? String

                val versionBean = VersionBean()
                versionBean.download = fileUrl
                versionBean.fileName = version
                versionBean.version = version

//                OtaApi.downloadFile(versionBean, object : VersionCallback {
//                    override fun success(version: String?) {
//
//                    }
//
//                    override fun error() {
//
//                    }
//                }, YongxinRingPlugin.activity)
            }

            "checkDeviceVersion" -> {
                val version = args?.get("version") as String
                OtaApi.checkVersion(version, object : VersionCallback {
                    override fun success(newVersion: String?) {
                        boolResultHasBeenSet =
                            setResult(call, result, boolResultHasBeenSet, newVersion)
                    }

                    override fun error() {
                        boolResultHasBeenSet =
                            setResult(call, result, boolResultHasBeenSet, null)
                    }
                }, YongxinRingPlugin.activity);
            }


            "startApolloOTA" -> {
                val version = args?.get("version") as? String
                val fileUrl = args?.get("fileUrl") as? String

                val device = connectedDevice?.device ?: currentDeviceMac?.let { mac ->
                    BluetoothAdapter.getDefaultAdapter()?.getRemoteDevice(mac)
                }
                val rssi = currentDeviceRssi

                if (device != null && version != null) {
                    OtaApi.otaUpdateWithVersion(
                        version,
                        device,
                        rssi,
                        YongxinRingPlugin.activity,
                        object : LmOtaProgressListener {
                            override fun error(message: String) {
                                println("OTAerror============ $message")
                                Handler(Looper.getMainLooper()).post {
                                    eventSink?.success(
                                        mapOf(
                                            "event" to "ringOtaProgress",
                                            "data" to -1
                                        )
                                    )
                                }
                            }

                            override fun onProgress(i: Int) {
                                println("OTAonProgress============ $i")
                                Handler(Looper.getMainLooper()).post {
                                    eventSink?.success(
                                        mapOf(
                                            "event" to "ringOtaProgress",
                                            "data" to i
                                        )
                                    )
                                }
                            }

                            override fun onComplete() {
                                println("OTAonComplete============ 101")
                                Handler(Looper.getMainLooper()).post {
                                    eventSink?.success(
                                        mapOf(
                                            "event" to "ringOtaProgress",
                                            "data" to 101
                                        )
                                    )
                                }
                            }

                            override fun isLatestVersion() {
                                println("OTAisLatestVersion============ 100")
                                Handler(Looper.getMainLooper()).post {
                                    eventSink?.success(
                                        mapOf(
                                            "event" to "ringOtaProgress",
                                            "data" to 101
                                        )
                                    )
                                }
                            }
                        }
                    )
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                } else {
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                }
            }

            "getBluetoothRSSI" -> {
                boolResultHasBeenSet =
                    setResult(call, result, boolResultHasBeenSet, currentDeviceRssi)
            }

            "connectDeviceDirectly" -> {
                // BLEUtils.stopLeScan(application, leScanCallback)

                if (BLEUtils.isConnecting()) {
                    Log.w(
                        "YongxinChannelHandler",
                        "SDK still in connecting state, force disconnect first"
                    )
                    BLEUtils.setConnected(false);
                    BLEUtils.setGetToken(false);
                    BLEUtils.disconnectBLE(application);
                    Thread.sleep(500)
                }

                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    Log.w(
                        "YongxinChannelHandler",
                        "connectDeviceDirectly callback --------------========== "
                    )
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_CONNECTED,
                    callback
                )
                val mac = args?.get("mac") as? String
                if (mac != null) {
                    Log.w(
                        "YongxinChannelHandler",
                        "Attempting direct connection with MAC: $mac"
                    )
                    val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
                    if (bluetoothAdapter != null) {
                        try {
                            Log.w(
                                "YongxinChannelHandler",
                                "connectDeviceDirectly bluetoothAdapter: $bluetoothAdapter"
                            )
                            val device = bluetoothAdapter.getRemoteDevice(mac)
                            if (device != null) {
                                Log.w(
                                    "YongxinChannelHandler",
                                    "connectDeviceDirectly device: $device"
                                )
                                BLEUtils.connectLockByBLE(application, device)
                                // 尝试创建临时的BleDeviceInfo，如果失败就保存MAC地址作为备用
                                Log.w(
                                    "YongxinChannelHandler",
                                    "connectDeviceDirectly getBleDeviceInfoWhenBleScan"
                                )
                                val tempDeviceInfo = LogicalApi.getBleDeviceInfoWhenBleScan(
                                    device,
                                    -50,
                                    ByteArray(0),
                                    false
                                )
                                if (tempDeviceInfo != null) {
                                    Log.w(
                                        "YongxinChannelHandler",
                                        "connectDeviceDirectly tempDeviceInfo: $tempDeviceInfo"
                                    )
                                    connectedDevice = tempDeviceInfo
                                    directConnectedMac = null
                                    // boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)

                                } else {
                                    // 如果LogicalApi创建失败，保存MAC地址作为备用
                                    Log.w(
                                        "YongxinChannelHandler",
                                        "Failed to create BleDeviceInfo in connectDevice, using fallback MAC: $mac"
                                    )
                                    connectedDevice = null
                                    directConnectedMac = mac
                                    // boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                                }
                            } else {
                                Log.w(
                                    "YongxinChannelHandler",
                                    "Failed to get device in connectDeviceDirectly"
                                )
                                boolResultHasBeenSet =
                                    setResult(call, result, boolResultHasBeenSet, false)
                            }
                        } catch (e: Exception) {
                            Log.e(
                                "YongxinChannelHandler",
                                "Failed to connect directly with MAC: $mac",
                                e
                            )
                            boolResultHasBeenSet =
                                setResult(call, result, boolResultHasBeenSet, false)
                        }
                    } else {
                        Log.e(
                            "YongxinChannelHandler",
                            "Failed to get BluetoothAdapter in connectDeviceDirectly"
                        )
                        boolResultHasBeenSet =
                            setResult(call, result, boolResultHasBeenSet, false)
                    }
                } else {
                    Log.e("YongxinChannelHandler", "Failed to get mac in connectDeviceDirectly")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                }
            }
            
            // 游戏相关方法
            "initGame" -> {
                try {


                    val userId = args?.get("userId") as? String
                    val userName = args?.get("userName") as? String ?: ""
                    val portrait = args?.get("portrait") as? String ?: ""
                    val language = args?.get("language") as? String ?: "en"
                    val isRelease = args?.get("isRelease") as? Boolean ?: false
                    gameDebugEnabled = args?.get("gameDebugEnabled") as? Boolean ?: false


                    // 测试key,不能用来打正式包，否则获取不到游戏列表
                    val testApiKey = "hUm1ScVVsWndVRlp0TVZOalJscDBaRWhrVDFKc2NIcFhhMUpUWVZVeFYxWnFVbGhoTVhCeVZqQmtTMk50VGtkaFJuQlhVbFJXVlZkWGNFZFdNbEpHVGSkZOWEJWYlhoMlpERmtjMaFVtMVNjVlZzV25kVlJscD"
                    // 正式key
                    val apiKey = "RmhoTVVwVVdWWlZlRll4V25GVmJHaG9UVmhDZVZacVFtdFRNazUwVkd0a2FGSnVRbGhWYkZKWFZsWmtXR05GWkZkTmJFcEhWR3hhWVZaWFNrWk9XRUpXWWxob01scEVSbXRqTVZwMFQxZG9UbUV4Y0ZsV1ZFa3h"
                    SMGameClient.init(application, if (isRelease) apiKey else testApiKey , "快康")


                    if (userId.isNullOrEmpty()) {
                        result.error("INVALID_ARGUMENT", "用户ID不能为空", null)
                        return
                    }
                    
                    SMGameClient.getInstance().language = language
                    SMGameClient.getInstance().setUserInfo(userId, userName, portrait)
                    SMGameClient.getInstance().setGameGSensorListener(object : IGameGSensor {
                        override fun openGSensor(p0: Int) {
                        }

                        override fun closeGSensor(p0: Int) {

                        }

                        override fun closeGame() {
                            handleGameClose()
                        }

                        override fun jsVirtualKeys(p0: Int) {
                            Log.d("YongxinChannelHandler", "虚拟按键事件: $p0")
                        }
                    })
                    result.success(true)
                } catch (e: Exception) {
                    Log.e("YongxinChannelHandler", "初始化游戏用户信息失败", e)
                    result.error("INIT_USER_INFO_ERROR", "初始化用户信息失败: ${e.message}", null)
                }
            }
            
            "getGameList" -> {
                try {
                    SMGameClient.getInstance().getGameList(object : IGameListCallback {
                        override fun onSuccessFul(datas: List<SMGameInfo>) {
                            val gameMapList = ArrayList<HashMap<String, Any>>()
                            
                            for (game in datas) {
                                val gameMap = HashMap<String, Any>()
                                gameMap["id"] = game.gid
                                gameMap["name"] = game.gname
                                gameMap["iconUrl"] = game.urls
                                gameMap["title"] = game.title
                                gameMap["background"] = game.background
                                gameMap["needVip"] = game.needVip==1
                                gameMapList.add(gameMap)
                            }
                            
                            android.os.Handler(android.os.Looper.getMainLooper()).post {
                                result.success(gameMapList)
                            }
                        }
                        
                        override fun onError(message: String) {
                            android.os.Handler(android.os.Looper.getMainLooper()).post {
                                result.error("GET_GAMES_ERROR", "获取游戏列表失败: $message", null)
                            }
                        }
                    })
                } catch (e: Exception) {
                    Log.e("YongxinChannelHandler", "获取游戏列表异常", e)
                    result.error("GET_GAMES_ERROR", "获取游戏列表异常: ${e.message}", null)
                }
            }
            
            "openGame" -> {
                try {
                    val gameId = args?.get("gameId") as? Int
                    if (gameId == null) {
                        result.error("INVALID_ARGUMENT", "游戏ID不能为空", null)
                        return
                    }
                    
                    if (gameActivity == null) {
                        gameActivity = YongxinRingPlugin.activity
                    }
                    
                    if (gameActivity == null) {
                        result.error("NO_ACTIVITY", "无法获取Activity实例", null)
                        return
                    }
                    
                    // 先获取游戏列表，找到对应ID的游戏信息
                    SMGameClient.getInstance().getGameList(object : IGameListCallback {
                        override fun onSuccessFul(datas: List<SMGameInfo>) {
                            val gameInfo = datas.find { it.gid == gameId }
                            
                            if (gameInfo == null) {
                                android.os.Handler(android.os.Looper.getMainLooper()).post {
                                    result.error("GAME_NOT_FOUND", "未找到ID为${gameId}的游戏", null)
                                }
                                return
                            }
                            
                            recentPlayedGame = gameInfo
                            recentGameStartTime = System.currentTimeMillis()
                            Log.d("YongxinChannelHandler", "准备启动游戏: ${gameInfo.gname}, gid: ${gameInfo.gid}")
                            
                            gameActivity?.let { activity ->
                                val listener = object : IGameOpenListener {
                                    override fun openResult(success: Boolean) {
                                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                                            if (success) {
                                                Log.d("YongxinChannelHandler", "游戏加载成功: ${gameInfo.gname}")
                                                
                                                // 游戏启动成功后开始读取传感器数据
                                                try {

                                                    // 注册6轴传感器监听器，用于游戏控制
                                                    LmAPI.READ_6_AXIS_SENSORS_SHIMI(axisListener)
                                                    
                                                    Log.d("YongxinChannelHandler", "已启动传感器数据读取")
                                                } catch (e: Exception) {
                                                    Log.e("YongxinChannelHandler", "启动传感器失败", e)
                                                }
                                                
                                                val gameData = HashMap<String, Any>()
                                                gameData["gameId"] = gameInfo.gid
                                                gameData["gameName"] = gameInfo.gname
                                                gameData["startTime"] = recentGameStartTime
                                                eventSink?.success(mapOf(
                                                    "event" to "onWillOpenGame",
                                                    "data" to gameData
                                                ))
                                                result.success(true)
                                            } else {
                                                Log.e("YongxinChannelHandler", "游戏加载失败: ${gameInfo.gname}")
                                                result.error("OPEN_GAME_ERROR", "游戏加载失败", null)
                                            }
                                        }
                                    }
                                }
                                
                                SMGameClient.getInstance().startGame(gameInfo, activity, listener)
                            }
                        }
                        
                        override fun onError(message: String) {
                            android.os.Handler(android.os.Looper.getMainLooper()).post {
                                result.error("OPEN_GAME_ERROR", "获取游戏列表失败: $message", null)
                            }
                        }
                    })
                } catch (e: Exception) {
                    Log.e("YongxinChannelHandler", "打开游戏失败", e)
                    result.error("OPEN_GAME_ERROR", "打开游戏失败: ${e.message}", null)
                }
            }
            

            "moveGamePlayer" -> {
                try {
                    val axisRealTurn = (args?.get("axisRealTurn") as? Number)?.toInt() ?: 0
                    val axisRealPitch = (args?.get("axisRealPitch") as? Number)?.toInt() ?: 0
                    val realSpeed = (args?.get("realSpeed") as? Number)?.toInt() ?: 0
                    val instantTurn = (args?.get("instantTurn") as? Number)?.toInt() ?: 0
                    val instantPitch = (args?.get("instantPitch") as? Number)?.toInt() ?: 0
                    val xAxisAccelerometer = (args?.get("xAxisAccelerometer") as? Number)?.toInt() ?: 0
                    val yAxisAccelerometer = (args?.get("yAxisAccelerometer") as? Number)?.toInt() ?: 0
                    val zAxisAccelerometer = (args?.get("zAxisAccelerometer") as? Number)?.toInt() ?: 0
                    val count = (args?.get("count") as? Number)?.toInt() ?: 0
                    
                    val sensorData = SMGameSensor(
                        axisRealTurn, axisRealPitch, realSpeed,
                        instantTurn, instantPitch, zAxisAccelerometer,
                        count, xAxisAccelerometer, yAxisAccelerometer
                    )
                    
                    SMGameClient.getInstance().movePlayer(1, sensorData)
                    result.success(true)
                } catch (e: Exception) {
                    Log.e("YongxinChannelHandler", "移动角色失败", e)
                    result.error("MOVE_PLAYER_ERROR", "移动角色失败: ${e.message}", null)
                }
            }

            else -> result.notImplemented()
        }
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
    }

    private fun getTimeZone(): Byte {
        // 获取当前系统时区的偏移量(单位:小时)
        val offsetSeconds = TimeZone.getDefault().rawOffset / 1000 // 获取系统默认时区偏移里(毫秒转为秒)
        return (offsetSeconds / 3600).toByte() // 转换为小时并返回
    }

    private fun ringDataToMap(ringData: HistoryDataBean): Map<String, Any> {
        val rrValues = mutableListOf<Int>()
        val rrsData = ringData.rrBytes
        if (rrsData != null && rrsData.size >= 2) {
            for (i in rrsData.indices step 2) {
                if (i + 1 < rrsData.size) {
                    val lowByte = rrsData[i].toInt() and 0xFF
                    val highByte = rrsData[i + 1].toInt() and 0xFF
                    val value = lowByte or (highByte shl 8)
                    rrValues.add(value)
                }
            }
        }


        return mapOf(
            "total" to ringData.totalNumber,
            "serialNum" to ringData.indexNumber,
            "timestamp" to ringData.time,
            "steps" to ringData.stepCount,
            "rate" to ringData.heartRate,
            "o2" to ringData.bloodOxygen,
            "hrv" to ringData.heartRateVariability,
            "stress" to ringData.stressIndex,
            "temp" to ringData.temperature.toDouble() / 100,
            "sleep_type" to ringData.sleepType,
            "rr_nums" to ringData.rrCount,
            "rrs" to rrValues,
            "reserve_battery" to ringData.reserve,
            "sport" to ringData.exerciseIntensity,
            "is_wear" to ringData.measurementMarker
        )
    }
    

    
    // 处理游戏关闭事件
    private fun handleGameClose() {
        try {
            val game = recentPlayedGame
            val startTime = recentGameStartTime
            
            Log.d("YongxinChannelHandler", "游戏SDK回调关闭事件触发, 游戏: ${game?.gname ?: "null"}")
            
            // 停止传感器数据读取
            try {
                LmAPI.STOP_PLAY_SHIMMI(axisListener)
                Log.d("YongxinChannelHandler", "游戏关闭回调：已停止传感器数据读取")
            } catch (e: Exception) {
                Log.e("YongxinChannelHandler", "游戏关闭回调：停止传感器失败", e)
            }
            
            if (game != null && startTime != 0L) {
                val endTime = System.currentTimeMillis()
                val duration = (endTime - startTime) / 1000
                
                val gameInfo = HashMap<String, Any>()
                gameInfo["gameId"] = game.gid
                gameInfo["gameName"] = game.gname
                gameInfo["startTime"] = startTime / 1000.0
                gameInfo["endTime"] = endTime / 1000.0
                gameInfo["duration"] = duration
                
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Log.d("YongxinChannelHandler", "发送游戏关闭事件到Flutter")
                    eventSink?.success(mapOf(
                        "event" to "onWillCloseGame",
                        "data" to gameInfo
                    ))
                }
                Log.d("YongxinChannelHandler", "游戏将要关闭: ${game.gname}, 游戏时长: ${duration}秒")
                
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    Log.d("YongxinChannelHandler", "清除游戏记录")
                    recentPlayedGame = null
                    recentGameStartTime = 0
                }, 500)
            }
        } catch (e: Exception) {
            Log.e("YongxinChannelHandler", "处理游戏关闭事件异常", e)
        }
    }
}
