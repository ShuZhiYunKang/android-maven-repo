package com.example.yongxin_ring

import android.R.attr.version
import android.app.Activity
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothAdapter.LeScanCallback
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.lm.sdk.DataApi
import com.lm.sdk.LmAPI
import com.lm.sdk.LogicalApi
import com.lm.sdk.OtaApi
import com.lm.sdk.inter.I6axisListener
import com.lm.sdk.inter.ICreateToken
import com.lm.sdk.inter.IHeartListener
import com.lm.sdk.inter.IHistoryListener
import com.lm.sdk.inter.IQ2Listener
import com.lm.sdk.inter.IShiMiListener
import com.lm.sdk.inter.ITempListener
import com.lm.sdk.inter.IGoMoreUserListener
import com.lm.sdk.mode.GoMoreSleep
import com.lm.sdk.utils.GoMoreUtils
import com.lm.sdk.inter.LmOtaProgressListener
import com.lm.sdk.inter.VersionCallback
import com.lm.sdk.library.constant.Constant
import com.lm.sdk.library.utils.PreferencesUtils
import com.lm.sdk.mode.BleDeviceInfo
import com.lm.sdk.mode.HistoryDataBean
import com.lm.sdk.mode.SystemControlBean
import com.lm.sdk.utils.BLEUtils
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.EventChannel.EventSink
import io.flutter.plugin.common.EventChannel.StreamHandler
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.lang.reflect.Proxy
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
//import com.lm.sdk.inter.IWebFirmwareListResult
//import com.lm.sdk.mode.Firmware
import com.lm.sdk.mode.VersionBean
import com.tenmeter.smlibrary.utils.SMGameClient
import com.tenmeter.smlibrary.entity.SMGameInfo
import com.tenmeter.smlibrary.entity.SMGameSensor
import com.tenmeter.smlibrary.listener.IGameGSensor
import com.tenmeter.smlibrary.listener.IGameListCallback
import com.tenmeter.smlibrary.listener.IGameOpenListener
import java.util.concurrent.atomic.AtomicInteger

/** 与 Flutter RingChannel.waitForAppConnectSyncPayload(120s) 对齐，避免本地读未完成即误杀 */
private const val READ_HISTORY_AUTO_LISTENER_TIMEOUT_MS = 120_000L
/** GoMore 授权 SDK 偶发不回调，native 侧必须兜底释放 MethodChannel */
private const val GOMORE_AUTHORIZATION_TIMEOUT_MS = 35_000L
class YongxinChannelHandler(private val application: Application) : MethodCallHandler,
    StreamHandler {
    private var eventSink: EventSink? = null

    private data class ProtocolV2SyncInFlight(
        val token: Long,
        val mac: String,
        val sinceTimestampSeconds: Long,
        val historyType: Byte,
        val waiters: MutableList<Result> = mutableListOf()
    )

    private data class ProtocolV2SyncRegistration(
        val token: Long,
        val joinedExisting: Boolean,
        val activeSinceTimestampSeconds: Long
    )

    private val broadcastManager: BroadcastManager = BroadcastManager(application)
    private val devicesMap = HashMap<String, BleDeviceInfo>()
    private var connectedDevice: BleDeviceInfo? = null
    private var directConnectedMac: String? = null

    private var readDatasSuccess = false
    
    // 用于跟踪数据同步进度，避免频繁发送日志
    private var lastSentPercent = -1
    
    // 用于跟踪扫描 ID，避免旧的扫描回调影响新的连接流程
    private var currentScanId: String = ""

    // 游戏相关变量
    private var recentPlayedGame: SMGameInfo? = null
    private var recentGameStartTime: Long = 0
    private var gameActivity: Activity? = null
    private var gameDebugEnabled: Boolean = false

    // 连接状态监控定时器
    private var connectionMonitorHandler: Handler? = null
    private var connectionMonitorRunnable: Runnable? = null
    private val latestAppConnectPayload = HashMap<String, Any?>()
    private val latestGoMoreUserInfo = HashMap<String, Int>()
    private var factoryLocalOtaWatchdogHandler: Handler? = null
    private var factoryLocalOtaWatchdogRunnable: Runnable? = null
    private var factoryLocalOtaWatchdogActive = false
    private val protocolV2SyncLock = Any()
    private var protocolV2SyncTokenSeed = 0L
    private var protocolV2SyncInFlight: ProtocolV2SyncInFlight? = null
    
    private var axisListener: IShiMiListener = object : IShiMiListener {
        override fun startPlay6Zhou(
            state: Int,
            sszx: Int,
            ssfy: Int,
            sssd: Int,
            sjzx: Int,
            sjfy: Int,
            zzjsd: Int,
            js: Int,
            xzjsd: Int,
            yzjsd: Int
        ) {
            // 如果有游戏正在运行，自动发送传感器数据到游戏
            if (recentPlayedGame != null) {
                try {
                    if (gameDebugEnabled) {
                        sendLogToFlutter("游戏传感器数据: sszx=$sszx, ssfy=$ssfy, sssd=$sssd")
                    }
                    
                    // 发送传感器数据事件到Flutter（用于游戏事件追踪）
                    val sensorData = mapOf(
                        "axisRealTurn" to sszx,
                        "axisRealPitch" to ssfy,
                        "realSpeed" to sssd,
                        "instantTurn" to sjzx,
                        "instantPitch" to sjfy,
                        "count" to js,
                        "xAxisAccelerometer" to xzjsd,
                        "yAxisAccelerometer" to yzjsd,
                        "zAxisAccelerometer" to zzjsd
                    )
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        eventSink?.success(mapOf(
                            "event" to "onSixAxis",
                            "data" to sensorData
                        ))
                    }
                    
                    val gameSensorData = SMGameSensor(
                        sszx, ssfy, sssd, sjzx, sjfy, zzjsd, js, xzjsd, yzjsd
                    )
                    SMGameClient.getInstance().movePlayer(1, gameSensorData)
                } catch (e: Exception) {
                    Log.e("YongxinChannelHandler", "发送游戏传感器数据失败", e)
                    sendLogToFlutter("发送游戏传感器数据失败: ${e.message}")
                }
            }
        }

        override fun startPlay3Zhou(state: Int, zzjsd: Int, xzjsd: Int, yzjsd: Int) {
            Log.e(
                "YongxinChannelHandler",
                "3轴数据"
            )
        }

        override fun stopPlay(success: Boolean) {
            Log.e(
                "YongxinChannelHandler",
                "停止游戏 "
            )
        }

        override fun acceleration(success: Boolean) {
            Log.e(
                "YongxinChannelHandler",
                "acceleration"
            )
        }

    }
    // Computed property作为connectedDevice的替代
    private val currentConnectedDevice: BleDeviceInfo?
        get() {
            return connectedDevice ?: directConnectedMac?.let { mac ->
                val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
                bluetoothAdapter?.getRemoteDevice(mac)?.let { device ->
                    // 创建一个临时的BleDeviceInfo对象
                    // 由于无法直接创建BleDeviceInfo，我们返回null并在使用时单独处理
                    null
                }
            }
        }

    // 获取当前连接设备的MAC地址
    private val currentDeviceMac: String?
        get() = connectedDevice?.device?.address ?: directConnectedMac

    // 获取当前连接设备的RSSI
    private val currentDeviceRssi: Int
        get() = connectedDevice?.rssi ?: -50

    // 获取当前连接设备的名称
    private val currentDeviceName: String
        get() = connectedDevice?.device?.name ?: "Unknown Ring"

    // 通用的测量错误处理方法
    private fun handleMeasurementError(eventName: String, errorCode: Int) {
        // 将Android SDK的错误码映射到Flutter端的RingErrorEnum枚举值
        val mappedErrorCode = when (errorCode) {
            0 -> 4   // noWear (未佩戴)
            2 -> 5   // charging (充电中)
            4 -> 0   // fail (繁忙，不执行 - 映射为失败)
            else -> 0 // fail (未知错误 - 映射为失败)
        }

        val progress = if (errorCode == 0) 1 else 100

        eventSink?.success(
            mapOf(
                "event" to eventName,
                "data" to mapOf(
                    "progress" to progress,
                    "result" to 0,
                    "error" to mappedErrorCode
                )
            )
        )
    }

    init {

        val broadcastReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val action = intent?.action
                // 蓝牙状态改变
                if (action == BluetoothAdapter.ACTION_STATE_CHANGED) {
                    val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    when (state) {
                        BluetoothAdapter.STATE_OFF -> {
                            Log.d("Bluetooth", "系统蓝牙已关闭")
                            eventSink?.success(mapOf("event" to "connectStateCallback", "data" to false))
                        }
                        BluetoothAdapter.STATE_TURNING_OFF -> Log.d("Bluetooth", "蓝牙正在关闭")
                        BluetoothAdapter.STATE_ON -> Log.d("Bluetooth", "蓝牙已开启")
                        BluetoothAdapter.STATE_TURNING_ON -> Log.d("Bluetooth", "蓝牙正在开启")
                    }
                }
            }
        }
        val intentFilter = IntentFilter()
        intentFilter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        application.registerReceiver(broadcastReceiver, intentFilter)

        val connectStateCallback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
            val action = intent.action
            val threadName = Thread.currentThread().name
            val sinkAlive = eventSink != null
            sendLogToFlutter("📡 [广播接收] 收到连接状态广播: $action thread=$threadName eventSinkAlive=$sinkAlive")

            if (action == BroadcastManager.ACTION_RING_CONNECTED) {
                sendLogToFlutter("✅ [广播接收] ACTION_RING_CONNECTED 设备连接成功 connectedDeviceMac=${connectedDevice?.device?.address} directConnectedMac=$directConnectedMac")
                stopConnectionMonitor() // 停止连接监控
                sendLogToFlutter("✅ [广播接收] 准备发送 connectStateCallback 事件: true")
                try {
                    eventSink?.success(mapOf("event" to "connectStateCallback", "data" to true))
                    sendLogToFlutter("✅ [广播接收] connectStateCallback 事件已发送 (sinkWasNull=${!sinkAlive})")
                } catch (e: Throwable) {
                    Log.e("YongxinChannelHandler", "❌ [广播接收] eventSink.success(true) 异常: ${e.message}", e)
                    sendLogToFlutter("❌ [广播接收] eventSink.success(true) 异常: ${e.message}")
                }
            } else if (action == BroadcastManager.ACTION_RING_DISCONNECTED) {
                connectedDevice = null // 断开连接后，清空连接设备
                sendLogToFlutter("❌ [广播接收] ACTION_RING_DISCONNECTED 设备断开连接")
                stopConnectionMonitor() // 停止连接监控
                sendLogToFlutter("❌ [广播接收] 准备发送 connectStateCallback 事件: false")
                try {
                    eventSink?.success(mapOf("event" to "connectStateCallback", "data" to false))
                    sendLogToFlutter("❌ [广播接收] connectStateCallback 事件已发送 (sinkWasNull=${!sinkAlive})")
                } catch (e: Throwable) {
                    Log.e("YongxinChannelHandler", "❌ [广播接收] eventSink.success(false) 异常: ${e.message}", e)
                    sendLogToFlutter("❌ [广播接收] eventSink.success(false) 异常: ${e.message}")
                }
            }
        }
        broadcastManager.registerReceiver(
            BroadcastManager.ACTION_RING_CONNECTED, connectStateCallback
        )
        broadcastManager.registerReceiver(
            BroadcastManager.ACTION_RING_DISCONNECTED, connectStateCallback
        )

        broadcastManager.registerReceiver(
            BroadcastManager.ACTION_BATTERY_PUSH, { intent, receiver ->
                val p0 = intent.getIntExtra("p0", 0)
                println("readBattery============ $p0")
                eventSink?.success(mapOf("event" to "batteryPush", "data" to p0))
            }
        )
        
        broadcastManager.registerReceiver(
            BroadcastManager.ACTION_INSTRUCT_TIMEOUT, { intent, receiver ->
                eventSink?.success(
                    mapOf(
                        "event" to "instructTimeout", "data" to mapOf(
                            "connectedDevice" to (if (connectedDevice == null) null else true),
                        )
                    )
                )
            }
        )
    }

  @RequiresApi(Build.VERSION_CODES.ECLAIR)
  private val leScanCallback =
      LeScanCallback { device, rssi, bytes ->
          val scanId = currentScanId
          if (device == null) {
              sendLogToFlutter("[Scan #$scanId] RAW onLeScan: device is null")
              return@LeScanCallback
          }
          sendLogToFlutter(
              "[Scan #$scanId] RAW onLeScan: address=${device.address}, name=${device.name ?: ""}, " +
                  "rssi=$rssi, rawLen=${bytes?.size ?: -1}, rawHead=${bytesToHex(bytes, 32)}"
          )
          //是否符合条件，符合条件，会返回戒指设备信息
          val bleDeviceInfo =
              LogicalApi.getBleDeviceInfoWhenBleScan(device, rssi, bytes, false)
                  ?: run {
                      sendLogToFlutter(
                          "[Scan #$scanId] FILTERED by LmSDK: getBleDeviceInfoWhenBleScan 返回 null " +
                              "(设备未被识别为勇芯戒指/协议不匹配)"
                      )
                      return@LeScanCallback
                  }
          if (!devicesMap.containsKey(device.address)) {
              val connectedStatus = if (bleDeviceInfo.device.bondState == 12) "CONNECTED" else "not_connected"
              val bindingIndicatorBit = readBleDeviceInfoInt(bleDeviceInfo, "bindingIndicatorBit")
              val hidDevice = readBleDeviceInfoInt(bleDeviceInfo, "hidDevice")
              sendLogToFlutter(
                  "[Scan #$scanId] Found device: ${device.address} ${device.name ?: ""} " +
                      "[status=$connectedStatus hidDevice=$hidDevice bindingIndicatorBit=$bindingIndicatorBit]"
              )
              devicesMap[device.address] = bleDeviceInfo
              eventSink?.success(
                  mapOf(
                      "event" to "scanResult",
                      "data" to devicesMap.values.map { bleDeviceInfoToScanMap(it) }
                  )
              )
          }
      }

    private fun readBleDeviceInfoInt(source: BleDeviceInfo?, vararg names: String): Int? {
        if (source == null) return null
        for (name in names) {
            try {
                val getterName = "get" + name.replaceFirstChar { it.uppercase() }
                val method = source.javaClass.methods.firstOrNull {
                    it.name.equals(getterName, ignoreCase = true) && it.parameterCount == 0
                }
                if (method != null) {
                    val value = method.invoke(source)
                    if (value is Number) return value.toInt()
                }
            } catch (_: Exception) {
            }
            try {
                val field = source.javaClass.declaredFields.firstOrNull {
                    it.name.equals(name, ignoreCase = true)
                }
                if (field != null) {
                    field.isAccessible = true
                    val value = field.get(source)
                    if (value is Number) return value.toInt()
                }
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun bleDeviceInfoToScanMap(bleDeviceInfo: BleDeviceInfo): Map<String, Any?> {
        val hidDevice = readBleDeviceInfoInt(bleDeviceInfo, "hidDevice")
        val bindingIndicatorBit = readBleDeviceInfoInt(bleDeviceInfo, "bindingIndicatorBit")
        val communicationProtocolVersion =
            readBleDeviceInfoInt(bleDeviceInfo, "communicationProtocolVersion")
        val chargingIndicator = readBleDeviceInfoInt(bleDeviceInfo, "chargingIndicator")
        val stepAccumulation = readBleDeviceInfoInt(bleDeviceInfo, "stepAccumulation")
        return mapOf(
            "mac" to bleDeviceInfo.device.address,
            "rssi" to bleDeviceInfo.rssi,
            "peripheralName" to bleDeviceInfo.device.name,
            "hidDevice" to hidDevice,
            "communicationProtocolVersion" to communicationProtocolVersion,
            "bindingIndicatorBit" to bindingIndicatorBit,
            "chargingIndicator" to chargingIndicator,
            "stepAccumulation" to stepAccumulation,
        )
    }

    private fun applyHidConnectionMode(
        bleDeviceInfo: BleDeviceInfo?,
        source: String
    ) {
        val bindingIndicatorBit = readBleDeviceInfoInt(bleDeviceInfo, "bindingIndicatorBit")
        val isHidDevice = bindingIndicatorBit == 1
        BLEUtils.isHIDDevice = isHidDevice
        sendLogToFlutter(
            "[$source] BLEUtils.isHIDDevice=$isHidDevice bindingIndicatorBit=$bindingIndicatorBit"
        )
    }

    private fun applyHidConnectionModeForMac(mac: String?, source: String) {
        if (mac.isNullOrEmpty()) {
            applyHidConnectionMode(null, source)
            return
        }
        val cached = devicesMap[mac] ?: connectedDevice?.takeIf {
            it.device.address.equals(mac, ignoreCase = true)
        }
        if (cached != null) {
            applyHidConnectionMode(cached, source)
        } else {
            BLEUtils.isHIDDevice = false
            sendLogToFlutter(
                "[$source] BLEUtils.isHIDDevice=false (no cached BleDeviceInfo for mac=$mac)"
            )
        }
    }

    private fun isLikelyOurBondedRingDevice(device: BluetoothDevice): Boolean {
        val name = try {
            device.name ?: ""
        } catch (e: Exception) {
            ""
        }
        val normalizedName = name.lowercase(Locale.US)
        return normalizedName.contains("omni ring") ||
            normalizedName.contains("kkring")
    }

    private fun bytesToHex(bytes: ByteArray?, maxLen: Int): String {
        if (bytes == null) {
            return "null"
        }
        if (bytes.isEmpty()) {
            return ""
        }
        val len = kotlin.math.min(maxLen, bytes.size)
        val builder = StringBuilder()
        for (i in 0 until len) {
            builder.append(String.format("%02X", bytes[i].toInt() and 0xFF))
            if (i < len - 1) {
                builder.append(" ")
            }
        }
        if (bytes.size > len) {
            builder.append(" ...")
        }
        return builder.toString()
    }

    private fun setResult(
        call: MethodCall,
        result: Result,
        boolResultHasBeenSet: Boolean,
        success: Any?
    ): Boolean {
        Log.d(
            "YongxinChannelHandler",
            "call.method: ${call.method}, boolResultHasBeenSet: $boolResultHasBeenSet, setResult -------------- setResult $success"
        )
        if (!boolResultHasBeenSet) {
            result.success(success)
        }
        return true;
    }

    private fun registerProtocolV2SyncWaiter(
        mac: String,
        sinceTimestampSeconds: Long,
        historyType: Byte,
        result: Result
    ): ProtocolV2SyncRegistration {
        synchronized(protocolV2SyncLock) {
            val inFlight = protocolV2SyncInFlight
            if (inFlight != null) {
                inFlight.waiters.add(result)
                return ProtocolV2SyncRegistration(
                    token = inFlight.token,
                    joinedExisting = true,
                    activeSinceTimestampSeconds = inFlight.sinceTimestampSeconds
                )
            }

            val token = ++protocolV2SyncTokenSeed
            protocolV2SyncInFlight = ProtocolV2SyncInFlight(
                token = token,
                mac = mac,
                sinceTimestampSeconds = sinceTimestampSeconds,
                historyType = historyType,
                waiters = mutableListOf(result)
            )
            return ProtocolV2SyncRegistration(
                token = token,
                joinedExisting = false,
                activeSinceTimestampSeconds = sinceTimestampSeconds
            )
        }
    }

    private fun takeProtocolV2SyncWaiters(token: Long): List<Result> {
        synchronized(protocolV2SyncLock) {
            val inFlight = protocolV2SyncInFlight ?: return emptyList()
            if (inFlight.token != token) return emptyList()
            protocolV2SyncInFlight = null
            return inFlight.waiters.toList()
        }
    }

    private fun finishProtocolV2SyncSuccess(token: Long) {
        val waiters = takeProtocolV2SyncWaiters(token)
        if (waiters.isEmpty()) return
        runOnMainThread {
            waiters.forEach { it.success(true) }
        }
    }

    private fun finishProtocolV2SyncError(
        token: Long,
        code: String,
        message: String,
        details: Any?
    ) {
        val waiters = takeProtocolV2SyncWaiters(token)
        if (waiters.isEmpty()) return
        runOnMainThread {
            waiters.forEach { it.error(code, message, details) }
        }
    }

    private fun runOnMainThread(action: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            action()
        } else {
            Handler(Looper.getMainLooper()).post { action() }
        }
    }

    // 向Flutter端发送日志
    private fun sendLogToFlutter(message: String) {
        val data = mapOf(
            "event" to "nativeLog",
            "data" to mapOf(
                "message" to message,
                "timestamp" to System.currentTimeMillis() / 1000.0
            )
        )
        runOnMainThread { eventSink?.success(data) }
    }

    private fun emitRingOtaProgress(progress: Int) {
        if (factoryLocalOtaWatchdogActive) {
            // 本地 OTA 一旦收到了进度或结束事件，就停止超时兜底
            stopFactoryLocalOtaWatchdog()
        }
        runOnMainThread {
            eventSink?.success(
                mapOf(
                    "event" to "ringOtaProgress",
                    "data" to progress
                )
            )
        }
    }

    private fun startFactoryLocalOtaWatchdog(timeoutMs: Long = 5000L) {
        stopFactoryLocalOtaWatchdog()
        factoryLocalOtaWatchdogActive = true
        val handler = Handler(Looper.getMainLooper())
        val runnable = Runnable {
            if (!factoryLocalOtaWatchdogActive) return@Runnable
            sendLogToFlutter("OTA(工厂): 本地OTA超时未收到回调，判定失败（可能缺少OTA服务或固件格式不匹配）")
            emitRingOtaProgress(-1)
            stopFactoryLocalOtaWatchdog()
        }
        factoryLocalOtaWatchdogHandler = handler
        factoryLocalOtaWatchdogRunnable = runnable
        handler.postDelayed(runnable, timeoutMs)
    }

    private fun stopFactoryLocalOtaWatchdog() {
        factoryLocalOtaWatchdogActive = false
        factoryLocalOtaWatchdogRunnable?.let { runnable ->
            factoryLocalOtaWatchdogHandler?.removeCallbacks(runnable)
        }
        factoryLocalOtaWatchdogRunnable = null
        factoryLocalOtaWatchdogHandler = null
    }

    private fun createFactoryOtaProgressListener(): LmOtaProgressListener {
        return object : LmOtaProgressListener {
            override fun error(message: String) {
                sendLogToFlutter("OTA(工厂): 升级失败 - $message")
                emitRingOtaProgress(-1)
            }

            override fun onProgress(i: Int) {
                sendLogToFlutter("OTA(工厂): 升级进度 $i%")
                emitRingOtaProgress(i)
            }

            override fun onComplete() {
                sendLogToFlutter("OTA(工厂): 固件传输成功")
                emitRingOtaProgress(101)
            }

            override fun isLatestVersion() {
                sendLogToFlutter("OTA(工厂): 已是最新版本")
                emitRingOtaProgress(101)
            }
        }
    }

    private fun startFactoryOtaWithCloudVersion(
        version: String,
        device: BluetoothDevice,
        rssi: Int
    ) {
        OtaApi.otaUpdateWithVersion(
            version,
            device,
            rssi,
            YongxinRingPlugin.activity,
            createFactoryOtaProgressListener()
        )
    }

    private fun startFactoryOtaFromLocalFile(
        filePath: String,
        device: BluetoothDevice,
        rssi: Int
    ): Boolean {
        val file = File(filePath)
        if (!file.exists() || !file.isFile || file.length() <= 0) {
            sendLogToFlutter("OTA(工厂): 本地文件不可用 path=$filePath")
            return false
        }

        // 1) 先尝试 OtaApi.setUpdateFile(...) 注入本地固件路径
        val setUpdateFileMethod = OtaApi::class.java.methods.firstOrNull { method ->
            method.name == "setUpdateFile" && method.parameterTypes.size == 1
        } ?: run {
            sendLogToFlutter("OTA(工厂): SDK未找到 setUpdateFile，无法走本地文件OTA")
            return false
        }

        try {
            val setArg = when (setUpdateFileMethod.parameterTypes[0]) {
                String::class.java, CharSequence::class.java -> filePath
                File::class.java -> file
                else -> {
                    sendLogToFlutter("OTA(工厂): setUpdateFile参数类型不支持=${setUpdateFileMethod.parameterTypes[0].name}")
                    return false
                }
            }
            setUpdateFileMethod.invoke(null, setArg)
            sendLogToFlutter("OTA(工厂): 已设置本地固件文件 path=$filePath")
        } catch (e: Exception) {
            sendLogToFlutter("OTA(工厂): setUpdateFile调用失败 ${e.message}")
            return false
        }

        // 2) 通过反射调用 startUpdate(...)，兼容不同 SDK 版本签名
        val callbackListener = createFactoryOtaProgressListener()
        val callbackProxyCache = HashMap<Class<*>, Any>()
        val startUpdateMethods = OtaApi::class.java.methods.filter { it.name == "startUpdate" }
        if (startUpdateMethods.isEmpty()) {
            sendLogToFlutter("OTA(工厂): SDK未找到 startUpdate，无法执行本地OTA")
            return false
        }

        for (method in startUpdateMethods.sortedBy { it.parameterTypes.size }) {
            try {
                val args = ArrayList<Any?>()
                var supported = true
                for (paramType in method.parameterTypes) {
                    when {
                        BluetoothDevice::class.java.isAssignableFrom(paramType) -> args.add(device)
                        paramType == Int::class.javaPrimitiveType || paramType == Int::class.javaObjectType -> args.add(rssi)
                        Activity::class.java.isAssignableFrom(paramType) -> args.add(YongxinRingPlugin.activity)
                        Context::class.java.isAssignableFrom(paramType) -> args.add(application)
                        paramType.isInterface && paramType.isInstance(callbackListener) -> args.add(callbackListener)
                        paramType.isInterface -> {
                            val proxy = callbackProxyCache.getOrPut(paramType) {
                                buildInterfaceProxy(paramType) { callbackName, callbackArgs ->
                                    when (callbackName) {
                                        "error", "onError", "failed" -> {
                                            val msg = callbackArgs?.firstOrNull()?.toString() ?: "unknown"
                                            sendLogToFlutter("OTA(工厂): 本地升级失败 - $msg")
                                            emitRingOtaProgress(-1)
                                        }

                                        "onProgress", "progress" -> {
                                            val numbers = callbackArgs
                                                ?.mapNotNull { it as? Number }
                                                ?: emptyList()
                                            val rawProgress = when {
                                                numbers.size >= 2 && numbers[1].toDouble() > 0.0 -> {
                                                    ((numbers[0].toDouble() / numbers[1].toDouble()) * 100.0).toInt()
                                                }
                                                numbers.isNotEmpty() -> numbers[0].toInt()
                                                else -> -1
                                            }
                                            if (rawProgress >= 0) {
                                                val progress = rawProgress.coerceIn(0, 100)
                                                sendLogToFlutter("OTA(工厂): 本地升级进度 $progress%")
                                                emitRingOtaProgress(progress)
                                            }
                                        }

                                        "onComplete", "success", "completed", "finish" -> {
                                            sendLogToFlutter("OTA(工厂): 本地固件传输成功")
                                            emitRingOtaProgress(101)
                                        }

                                        "isLatestVersion" -> {
                                            sendLogToFlutter("OTA(工厂): 本地OTA已是最新版本")
                                            emitRingOtaProgress(101)
                                        }

                                        "onDeviceStateChange", "deviceStateChange" -> {
                                            val state = callbackArgs?.firstOrNull()
                                            val stateDetails = callbackArgs
                                                ?.joinToString(prefix = "[", postfix = "]") { it?.toString() ?: "null" }
                                                ?: "[]"
                                            sendLogToFlutter("OTA(工厂): 设备状态变化 state=$state details=$stateDetails")
                                            val lower = stateDetails.lowercase()
                                            if (lower.contains("otaservicenotfound") ||
                                                lower.contains("service not found") ||
                                                lower.contains("service_not_found")
                                            ) {
                                                sendLogToFlutter("OTA(工厂): 检测到OTA服务缺失，立即判定失败")
                                                emitRingOtaProgress(-1)
                                            }
                                        }
                                    }
                                }
                            }
                            args.add(proxy)
                        }
                        else -> {
                            supported = false
                            break
                        }
                    }
                }

                if (!supported) continue
                method.invoke(null, *args.toTypedArray())
                sendLogToFlutter("OTA(工厂): 已启动本地文件OTA，method=${method.toGenericString()}")
                return true
            } catch (e: Exception) {
                sendLogToFlutter("OTA(工厂): 尝试本地OTA方法失败 method=${method.name}, err=${e.message}")
            }
        }

        sendLogToFlutter("OTA(工厂): 所有startUpdate签名尝试失败")
        return false
    }

    private fun collectAndroidSdkLogFiles(): List<File> {
        val files = LinkedHashSet<File>()
        val appExternalRoot = application.getExternalFilesDir(null)
        val externalStorageRoot = Environment.getExternalStorageDirectory()
        val downloadsRoot =
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

        // SDK Logger 通过 ImageSaverUtil 写 operationLog 到 LM 目录
        // 观察到文件名可能是 "LMoperationLog.txt"（目录名前缀 + 文件名）
        val candidatePaths = listOf(
            appExternalRoot?.let { File(it, "LM/LMoperationLog.txt") },
            appExternalRoot?.let { File(it, "LM/operationLog.txt") },
            downloadsRoot?.let { File(it, "LM/LMoperationLog.txt") },
            downloadsRoot?.let { File(it, "LM/operationLog.txt") },
            // SDK FileUtil.putTxt 会把 commandLog 写到 /sdcard/LMCache/commandLog.txt
            externalStorageRoot?.let { File(it, "LMCache/commandLog.txt") },
        )

        candidatePaths.forEach { file ->
            if (file != null && file.exists() && file.isFile && file.length() > 0) {
                files.add(file)
            }
        }
        return files.toList()
    }

    private fun exportAndroidSdkLogsZip(): String? {
        return try {
            val logsDir = File(application.cacheDir, "yongxin_logs")
            if (!logsDir.exists()) {
                logsDir.mkdirs()
            }
            val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val zipFile = File(logsDir, "yongxin_android_sdk_logs_$ts.zip")
            val sdkLogFiles = collectAndroidSdkLogFiles()

            if (sdkLogFiles.isEmpty()) {
                sendLogToFlutter("未找到 Android 勇芯 SDK 日志文件")
                return null
            }

            ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
                sdkLogFiles.forEach { logFile ->
                    FileInputStream(logFile).use { fis ->
                        val entryName = "sdk_logs/${logFile.name}"
                        zos.putNextEntry(ZipEntry(entryName))
                        fis.copyTo(zos)
                        zos.closeEntry()
                    }
                }
            }
            sendLogToFlutter(
                "找到 ${sdkLogFiles.size} 个 SDK 日志文件: ${
                    sdkLogFiles.joinToString { it.absolutePath }
                }"
            )
            zipFile.absolutePath
        } catch (e: Exception) {
            sendLogToFlutter("导出 Android 勇芯日志失败: ${e.message}")
            null
        }
    }

    private fun parseIntExtra(intent: Intent, key: String): Int? {
        if (!intent.hasExtra(key)) return null
        val value = intent.getIntExtra(key, Int.MIN_VALUE)
        return if (value == Int.MIN_VALUE || value < 0) null else value
    }

    private fun normalizeGoMoreSupport(value: Int?): Int? {
        if (value == null) return null
        return if (value > 0) 1 else 0
    }

    private fun updateGoMoreCacheFromComposite(payload: Map<String, Any?>) {
        fun putIfExists(cacheKey: String, payloadKey: String) {
            val value = (payload[payloadKey] as? Number)?.toInt()
            if (value != null && value >= 0) {
                latestGoMoreUserInfo[cacheKey] = value
            }
        }
        putIfExists("age", "gomoreUserAge")
        putIfExists("gender", "gomoreUserGender")
        putIfExists("height", "gomoreUserHeight")
        putIfExists("weight", "gomoreUserWeight")
        putIfExists("maxHeartRate", "gomoreMaxHeartRate")
        putIfExists("normalHeartRate", "gomoreRestingHeartRate")
        putIfExists("maxOxygenUptake", "gomoreMaxOxygenUptake")
    }

    private fun buildCompositePayload(intent: Intent, timeMillis: Long): HashMap<String, Any?> {
        val payload = HashMap<String, Any?>()
        payload["success"] = true
        payload["timeMillis"] = timeMillis
        payload["raw"] = intent.getStringExtra("raw") ?: ""
        payload["firmwareVersion"] = intent.getStringExtra("firmwareVersion")
        payload["hardwareVersion"] = intent.getStringExtra("hardwareVersion")
        payload["battery"] = parseIntExtra(intent, "battery")
        payload["chargingStatus"] = parseIntExtra(intent, "chargingStatus")
        payload["stepCounting"] = parseIntExtra(intent, "stepCounting")
        payload["collectionInterval"] = parseIntExtra(intent, "collectionInterval")
        payload["gomoreSleep"] = normalizeGoMoreSupport(parseIntExtra(intent, "gomoreSleep"))
        payload["gomoreUserAge"] = parseIntExtra(intent, "gomoreUserAge")
        payload["gomoreUserGender"] = parseIntExtra(intent, "gomoreUserGender")
        payload["gomoreUserHeight"] = parseIntExtra(intent, "gomoreUserHeight")
        payload["gomoreUserWeight"] = parseIntExtra(intent, "gomoreUserWeight")
        payload["gomoreMaxHeartRate"] = parseIntExtra(intent, "gomoreMaxHeartRate")
        payload["gomoreRestingHeartRate"] = parseIntExtra(intent, "gomoreRestingHeartRate")
        payload["gomoreMaxOxygenUptake"] = parseIntExtra(intent, "gomoreMaxOxygenUptake")
        // 兼容文档/旧 SDK 命名，Dart 侧可直接按任一别名解析
        payload["gomoreAge"] = payload["gomoreUserAge"]
        payload["gomoreSex"] = payload["gomoreUserGender"]
        payload["gomoreHeight"] = payload["gomoreUserHeight"]
        payload["gomoreWeight"] = payload["gomoreUserWeight"]
        payload["gomoreNormalHeartRate"] = payload["gomoreRestingHeartRate"]
        payload["gomoreOxygen"] = payload["gomoreMaxOxygenUptake"]
        updateGoMoreCacheFromComposite(payload)
        latestAppConnectPayload.clear()
        latestAppConnectPayload.putAll(payload)
        return payload
    }

    private fun getterValue(source: Any?, vararg names: String): Any? {
        if (source == null) return null
        for (name in names) {
            val getterCandidates = listOf(
                "get" + name.replaceFirstChar { it.uppercase() },
                "is" + name.replaceFirstChar { it.uppercase() },
                name
            )
            for (getter in getterCandidates) {
                try {
                    val method = source.javaClass.methods.firstOrNull {
                        it.name.equals(getter, ignoreCase = true) && it.parameterCount == 0
                    }
                    if (method != null) {
                        return method.invoke(source)
                    }
                } catch (_: Exception) {
                }
            }
            try {
                val field = source.javaClass.declaredFields.firstOrNull {
                    it.name.equals(name, ignoreCase = true)
                }
                if (field != null) {
                    field.isAccessible = true
                    return field.get(source)
                }
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun toIntValue(value: Any?): Int? = when (value) {
        is Number -> value.toInt()
        is String -> value.toIntOrNull()
        else -> null
    }

    private fun toLongValue(value: Any?): Long? = when (value) {
        is Number -> value.toLong()
        is String -> value.toLongOrNull()
        else -> null
    }

    private fun toDoubleValue(value: Any?): Double? = when (value) {
        is Number -> value.toDouble()
        is String -> value.toDoubleOrNull()
        else -> null
    }

    private fun formatDateBySeconds(seconds: Long): String {
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return formatter.format(Date(seconds * 1000))
    }

    private fun mapSleepTypeFromStage(stage: Int): Int {
        return when (stage) {
            0 -> 1
            1 -> 4
            2 -> 2
            3 -> 3
            else -> 0
        }
    }

    private fun goMoreSleepObjectToMap(source: Any?): Map<String, Any?> {
        if (source == null) return emptyMap()
        val map = HashMap<String, Any?>()
        // 基本标识
        map["resType"] = toIntValue(getterValue(source, "resType"))
        map["type"] = toIntValue(getterValue(source, "type"))
        map["startTs"] = toLongValue(getterValue(source, "startTs", "startTime"))
        map["endTs"] = toLongValue(getterValue(source, "endTs", "endTime"))
        // 睡眠统计字段（GoMoreSleep 完整字段集，避免上传/序列化时丢失）
        map["numEpochs"] = toIntValue(getterValue(source, "numEpochs"))
        map["latency"] = toIntValue(getterValue(source, "latency"))
        map["wakeTimes"] = toIntValue(getterValue(source, "wakeTimes"))
        map["totalSleepTime"] = toIntValue(getterValue(source, "totalSleepTime"))
        map["waso"] = toIntValue(getterValue(source, "waso"))
        map["sleepPeriod"] = toIntValue(getterValue(source, "sleepPeriod"))
        map["efficiency"] = toIntValue(getterValue(source, "efficiency"))
        map["wakeRatio"] = toIntValue(getterValue(source, "wakeRatio"))
        map["remRatio"] = toIntValue(getterValue(source, "remRatio"))
        map["lightRatio"] = toIntValue(getterValue(source, "lightRatio"))
        map["deepRatio"] = toIntValue(getterValue(source, "deepRatio"))
        map["wakeNumMinutes"] = toIntValue(getterValue(source, "wakeNumMinutes"))
        map["remNumMinutes"] = toIntValue(getterValue(source, "remNumMinutes"))
        map["lightNumMinutes"] = toIntValue(getterValue(source, "lightNumMinutes"))
        map["deepNumMinutes"] = toIntValue(getterValue(source, "deepNumMinutes"))
        map["score"] = toIntValue(getterValue(source, "score"))
        map["stageNum"] = toIntValue(getterValue(source, "stageNum"))
        // 分包字段
        map["packNo"] = toIntValue(getterValue(source, "packNo"))
        map["packNum"] = toIntValue(getterValue(source, "packNum"))
        // 睡眠分期数组
        val stages = getterValue(source, "stages")
        when (stages) {
            is ShortArray -> map["stages"] = stages.map { it.toInt() }
            is IntArray -> map["stages"] = stages.toList()
            is Array<*> -> map["stages"] = stages.mapNotNull { toIntValue(it) }
            is List<*> -> map["stages"] = stages.mapNotNull { toIntValue(it) }
        }
        return map
    }

    private fun setPropertyIfPresent(target: Any, name: String, value: Any?) {
        if (value == null) return
        try {
            val setterName = "set" + name.replaceFirstChar { it.uppercase() }
            val methods = target.javaClass.methods.filter {
                it.name.equals(setterName, ignoreCase = true) && it.parameterTypes.size == 1
            }
            if (methods.isEmpty()) return
            for (method in methods) {
                val parameterType = method.parameterTypes[0]
                val converted: Any? = when {
                    parameterType == Int::class.javaPrimitiveType || parameterType == Int::class.java ->
                        toIntValue(value)
                    parameterType == Long::class.javaPrimitiveType || parameterType == Long::class.java ->
                        toLongValue(value)
                    parameterType == Short::class.javaPrimitiveType || parameterType == Short::class.java ->
                        toIntValue(value)?.toShort()
                    parameterType == Double::class.javaPrimitiveType || parameterType == Double::class.java ->
                        toDoubleValue(value)
                    parameterType == Float::class.javaPrimitiveType || parameterType == Float::class.java ->
                        toDoubleValue(value)?.toFloat()
                    parameterType == String::class.java -> value.toString()
                    parameterType.isArray && parameterType.componentType == Short::class.javaPrimitiveType -> {
                        val list = value as? List<*> ?: emptyList<Any>()
                        ShortArray(list.size) { index -> toIntValue(list[index])?.toShort() ?: 0 }
                    }
                    List::class.java.isAssignableFrom(parameterType) -> {
                        val list = value as? List<*> ?: emptyList<Any>()
                        list.mapNotNull { toIntValue(it)?.toShort() }
                    }
                    else -> null
                }
                if (converted != null) {
                    method.invoke(target, converted)
                    return
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun goMoreSleepMapToSdkObject(map: Map<String, Any?>): Any? {
        return try {
            val clazz = Class.forName("com.lm.sdk.mode.GoMoreSleep")
            val instance = clazz.getDeclaredConstructor().newInstance()
            setPropertyIfPresent(instance, "resType", map["resType"])
            setPropertyIfPresent(instance, "type", map["type"])
            setPropertyIfPresent(instance, "startTs", map["startTs"] ?: map["startTime"])
            setPropertyIfPresent(instance, "endTs", map["endTs"] ?: map["endTime"])
            setPropertyIfPresent(instance, "numEpochs", map["numEpochs"])
            setPropertyIfPresent(instance, "latency", map["latency"])
            setPropertyIfPresent(instance, "wakeTimes", map["wakeTimes"])
            setPropertyIfPresent(instance, "totalSleepTime", map["totalSleepTime"])
            setPropertyIfPresent(instance, "waso", map["waso"])
            setPropertyIfPresent(instance, "sleepPeriod", map["sleepPeriod"])
            setPropertyIfPresent(instance, "efficiency", map["efficiency"])
            setPropertyIfPresent(instance, "wakeRatio", map["wakeRatio"])
            setPropertyIfPresent(instance, "remRatio", map["remRatio"])
            setPropertyIfPresent(instance, "lightRatio", map["lightRatio"])
            setPropertyIfPresent(instance, "deepRatio", map["deepRatio"])
            setPropertyIfPresent(instance, "wakeNumMinutes", map["wakeNumMinutes"])
            setPropertyIfPresent(instance, "remNumMinutes", map["remNumMinutes"])
            setPropertyIfPresent(instance, "lightNumMinutes", map["lightNumMinutes"])
            setPropertyIfPresent(instance, "deepNumMinutes", map["deepNumMinutes"])
            setPropertyIfPresent(instance, "score", map["score"])
            setPropertyIfPresent(instance, "stageNum", map["stageNum"])
            setPropertyIfPresent(instance, "packNo", map["packNo"])
            setPropertyIfPresent(instance, "packNum", map["packNum"])
            setPropertyIfPresent(instance, "stages", map["stages"])
            instance
        } catch (e: Exception) {
            sendLogToFlutter("goMoreSleepMapToSdkObject failed: ${e.message}")
            null
        }
    }

    private fun historyDataListToMapList(anyList: Any?): List<Map<String, Any>> {
        if (anyList !is List<*>) return emptyList()
        val mapped = ArrayList<Map<String, Any>>()
        for (item in anyList) {
            when (item) {
                is HistoryDataBean -> mapped.add(ringDataToMap(item))
                else -> {
                    val timestamp = toLongValue(getterValue(item, "time", "timestamp")) ?: continue
                    val sleepType = toIntValue(getterValue(item, "sleepType", "sleep_type")) ?: 0
                    mapped.add(
                        mapOf(
                            "timestamp" to timestamp,
                            "sleepType" to sleepType
                        )
                    )
                }
            }
        }
        return mapped
    }

    private fun sleepBeanToMap(bean: Any): Map<String, Any?> {
        val result = HashMap<String, Any?>()
        result["startTime"] = toLongValue(getterValue(bean, "startTime"))
        result["endTime"] = toLongValue(getterValue(bean, "endTime"))
        result["sleepTime"] = toLongValue(getterValue(bean, "sleepTime"))
        result["seconds"] = toLongValue(getterValue(bean, "seconds"))
        result["deepTime"] = toLongValue(getterValue(bean, "deepTime"))
        result["lowTime"] = toLongValue(getterValue(bean, "lowTime"))
        result["ydTime"] = toLongValue(getterValue(bean, "ydTime"))
        result["qxTime"] = toLongValue(getterValue(bean, "qxTime"))
        result["sjTime"] = toLongValue(getterValue(bean, "sjTime"))
        result["hours"] = toIntValue(getterValue(bean, "hours"))
        result["minutes"] = toIntValue(getterValue(bean, "minutes"))
        result["wakeupCount"] = toIntValue(getterValue(bean, "wakeupCount"))
        result["waso"] = toIntValue(getterValue(bean, "waso"))
        result["sleepDataType"] = toIntValue(getterValue(bean, "sleepDataType"))
        result["score"] = toIntValue(getterValue(bean, "score"))
        result["resultTemperture"] = toDoubleValue(getterValue(bean, "resultTemperture"))
        val sleepDataBeanList = historyDataListToMapList(getterValue(bean, "sleepDataBeanList", "sleepDataList"))
        if (sleepDataBeanList.isNotEmpty()) {
            result["sleepDataBeanList"] = sleepDataBeanList.map {
                mapOf("sleepType" to (it["sleepType"] ?: it["sleep_type"] ?: 0))
            }
            result["historyBeanList"] = sleepDataBeanList
        }
        return result
    }

    private fun sleepBatchBeanToMap(bean: Any): Map<String, Any?> {
        return mapOf(
            "dayString" to getterValue(bean, "dayString"),
            "highCount" to toLongValue(getterValue(bean, "highCount")),
            "lowCount" to toLongValue(getterValue(bean, "lowCount")),
            "ksCount" to toLongValue(getterValue(bean, "ksCount")),
            "qxCount" to toLongValue(getterValue(bean, "qxCount")),
            "dayCount" to toLongValue(getterValue(bean, "dayCount")),
            "time" to toLongValue(getterValue(bean, "time")),
        )
    }

    private fun buildInterfaceProxy(
        interfaceType: Class<*>,
        handler: (String, Array<out Any?>?) -> Unit
    ): Any {
        return Proxy.newProxyInstance(
            interfaceType.classLoader,
            arrayOf(interfaceType)
        ) { _, method, args ->
            handler(method.name, args)
            null
        }
    }

    /**
     * 按文档要求：APP_CONNECT/APP_REFRESH 会自动上传历史数据，必须先设置历史监听，
     * 否则 SDK 内部可能出现 IHistoryListener 空指针。
     */
    private fun attachCompositeHistoryAutoListener(timeMillis: Long, sessionId: String): Boolean {
        try {
            data class AutoHistoryMethodBinding(
                val method: java.lang.reflect.Method,
                val methodName: String,
                val ownerName: String
            )

            fun resolveAutoHistoryMethod(
                targetMethodName: String,
                parameterCount: Int
            ): AutoHistoryMethodBinding? {
                // appConnectComposite 当前实际走的是 LmAPI.APP_CONNECT(long)，
                // 因此必须优先给 LmAPI 注册自动历史监听，否则 SDK 内部的
                // IHistoryListener 仍可能为空并在自动同步时崩溃。
                val apiMethod = LmAPI::class.java.methods.firstOrNull {
                    it.name == targetMethodName && it.parameterTypes.size == parameterCount
                }
                if (apiMethod != null) {
                    return AutoHistoryMethodBinding(
                        method = apiMethod,
                        methodName = targetMethodName,
                        ownerName = "LmAPI"
                    )
                }

                val liteMethod = com.lm.sdk.LmAPILite::class.java.methods.firstOrNull {
                    it.name == targetMethodName && it.parameterTypes.size == parameterCount
                }
                if (liteMethod != null) {
                    return AutoHistoryMethodBinding(
                        method = liteMethod,
                        methodName = targetMethodName,
                        ownerName = "LmAPILite"
                    )
                }
                return null
            }

            // 第一步：READ_HISTORY_AUTO（1参数）—— 从戒指读历史数据写入 SDK 本地 DB。
            // 第二步：READ_HISTORY_AUTO_UPDATE_TO_SERVER（3参数）—— 将本地 DB 数据上传勇芯服务端。
            // 必须先完成第一步再做第二步，保证 getObjectsFrom 能拿到数据的同时服务端也有记录。
            // 第二步失败/不支持不影响 appConnectSyncDone 的正常下发。
            val localBinding = resolveAutoHistoryMethod("READ_HISTORY_AUTO", 1)
            if (localBinding == null) {
                sendLogToFlutter(
                    "No auto history listener method found (READ_HISTORY_AUTO)"
                )
                return false
            }
            val uploadBinding = resolveAutoHistoryMethod("READ_HISTORY_AUTO_UPDATE_TO_SERVER", 3)

            val mac = currentDeviceMac
            val models = ArrayList<Map<String, Any>>()
            val completed = AtomicBoolean(false)
            // SDK progress(double) 按文档为 0–100%；每 5% 打一条日志便于对照 n/(n+1) 节流行
            val lastLoggedSdkProgressBucket = AtomicInteger(-1)
            val lastPartialEmitCount = AtomicInteger(0)
            val timeoutHandler = Handler(Looper.getMainLooper())
            // Flutter compositeSync 看门狗依赖 nativeLog 子串 syncing: X/Y（见 ring_channel 正则）
            val lastReadHistorySyncingLogMs = AtomicLong(0L)
            val readHistorySyncingMinIntervalMs = 300L
            fun maybeEmitReadHistorySyncingProgress() {
                val now = SystemClock.elapsedRealtime()
                var prev = lastReadHistorySyncingLogMs.get()
                while (true) {
                    if (now - prev < readHistorySyncingMinIntervalMs) return
                    if (lastReadHistorySyncingLogMs.compareAndSet(prev, now)) break
                    prev = lastReadHistorySyncingLogMs.get()
                }
                val n = models.size
                val denom = if (n <= 0) 1 else n + 1
                sendLogToFlutter(
                    "READ_HISTORY_AUTO syncing: $n/$denom sessionId=$sessionId"
                )
            }

            fun mergeModelsWithLocalDb(): List<Map<String, Any>> {
                val deduped = linkedMapOf<Long, Map<String, Any>>()
                for (model in models) {
                    val timestamp = (model["timestamp"] as? Number)?.toLong()
                    if (timestamp != null) {
                        deduped[timestamp] = model
                    }
                }

                if (mac.isNullOrEmpty()) return deduped.values.toList()
                return try {
                    val currentTime = System.currentTimeMillis() / 1000
                    val localObjects =
                        DataApi.instance.queryHistoryData(timeMillis, currentTime, mac)
                    for (item in localObjects) {
                        val mapped = ringDataToMap(item)
                        val timestamp = (mapped["timestamp"] as? Number)?.toLong()
                        if (timestamp != null) {
                            deduped[timestamp] = mapped
                        }
                    }
                    if (localObjects.isNotEmpty()) {
                        sendLogToFlutter(
                            "READ_HISTORY_AUTO local DB fallback merged callback=${models.size} db=${localObjects.size} total=${deduped.size} sessionId=$sessionId"
                        )
                    }
                    deduped.values.toList()
                } catch (e: Exception) {
                    sendLogToFlutter("READ_HISTORY_AUTO local DB fallback failed: ${e.message}")
                    deduped.values.toList()
                }
            }

            fun emitHistoryPartial(force: Boolean = false, isFinal: Boolean = false) {
                val count = models.size
                if (count <= 0) return
                val lastCount = lastPartialEmitCount.get()
                if (lastCount >= count) return
                if (!force && count - lastCount < 50) return
                val payloadModels =
                    ArrayList<Map<String, Any>>(models.subList(lastCount, count))
                lastPartialEmitCount.set(count)
                if (payloadModels.isEmpty()) return
                runOnMainThread {
                    eventSink?.success(
                        mapOf(
                            "event" to "ringHistorySyncPartial",
                            "data" to mapOf(
                                "sessionId" to sessionId,
                                "source" to "READ_HISTORY_AUTO",
                                "mac" to (mac ?: ""),
                                "count" to count,
                                "deltaCount" to payloadModels.size,
                                "models" to payloadModels,
                                "isFinal" to isFinal,
                                "isDelta" to true,
                                "timeMillis" to timeMillis
                            )
                        )
                    )
                }
            }

            val emitCompletion = fun(success: Boolean, errorCode: Int?, errorMessage: String?) {
                val finalModels = mergeModelsWithLocalDb()
                // removeCallbacksAndMessages 必须在主线程调用
                runOnMainThread {
                    timeoutHandler.removeCallbacksAndMessages(null)
                    eventSink?.success(
                        mapOf(
                            "event" to "appConnectSyncDone",
                            "data" to mapOf(
                                "sessionId" to sessionId,
                                "success" to success,
                                "count" to finalModels.size,
                                "models" to finalModels,
                                "errorCode" to errorCode,
                                "error" to errorMessage,
                                "timeMillis" to timeMillis
                            )
                        )
                    )
                }
            }

            val finish = fun(success: Boolean, errorCode: Int?, errorMessage: String?) {
                if (!completed.compareAndSet(false, true)) return
                emitCompletion(success, errorCode, errorMessage)
            }

            // 第二步：本地读取完成后上传服务端。
            // 真正的后台 fire-and-forget：UI 已在第一步读完后放行（finish 已发 appConnectSyncDone），
            // 这里只负责把本地 DB 历史推到服务端，全程不再调用 finish、不 gate UI。
            val startUploadToServer = fun() {
                if (uploadBinding == null || mac.isNullOrEmpty()) {
                    sendLogToFlutter(
                        "READ_HISTORY_AUTO_UPDATE_TO_SERVER skip: uploadBinding=${uploadBinding != null} mac=${mac ?: "null"}"
                    )
                    return
                }
                var uploadTimeoutRunnable: Runnable? = null
                try {
                    val uploadMethod = uploadBinding.method
                    val uploadListenerType = uploadMethod.parameterTypes[1]
                    val uploadWebListenerType = uploadMethod.parameterTypes[2]
                    // 后台超时仅记录日志（提示本次上传未在 15s 内确认），不影响 UI。
                    val timeoutRunnable = Runnable {
                        sendLogToFlutter("READ_HISTORY_AUTO_UPDATE_TO_SERVER background not confirmed in 15s (UI 不受影响) sessionId=$sessionId")
                    }
                    uploadTimeoutRunnable = timeoutRunnable
                    val uploadListener = buildInterfaceProxy(uploadListenerType) { callbackName, _ ->
                        when (callbackName) {
                            "noNewDataAvailable", "clearHistory" -> {
                                timeoutHandler.removeCallbacks(timeoutRunnable)
                                sendLogToFlutter("READ_HISTORY_AUTO_UPDATE_TO_SERVER localListener $callbackName (background done)")
                            }
                            "success", "updateHistoryFinish" -> {
                                sendLogToFlutter("READ_HISTORY_AUTO_UPDATE_TO_SERVER localListener $callbackName, waiting for webListener (background)")
                            }
                            "error", "serviceError" -> {
                                timeoutHandler.removeCallbacks(timeoutRunnable)
                                sendLogToFlutter("READ_HISTORY_AUTO_UPDATE_TO_SERVER localListener error=$callbackName (background)")
                            }
                            else -> sendLogToFlutter("READ_HISTORY_AUTO_UPDATE_TO_SERVER localListener $callbackName")
                        }
                    }
                    val uploadWebListener = buildInterfaceProxy(uploadWebListenerType) { callbackName, callbackArgs ->
                        when (callbackName) {
                            "updateHistoryFinish" -> {
                                timeoutHandler.removeCallbacks(timeoutRunnable)
                                sendLogToFlutter("READ_HISTORY_AUTO_UPDATE_TO_SERVER webListener updateHistoryFinish (background done)")
                            }
                            "serviceError", "error" -> {
                                timeoutHandler.removeCallbacks(timeoutRunnable)
                                val msg = callbackArgs?.getOrNull(0)?.toString() ?: callbackName
                                sendLogToFlutter("READ_HISTORY_AUTO_UPDATE_TO_SERVER webListener error=$msg (background)")
                            }
                            else -> sendLogToFlutter("READ_HISTORY_AUTO_UPDATE_TO_SERVER webListener $callbackName")
                        }
                    }
                    timeoutHandler.postDelayed(timeoutRunnable, 15000)
                    sendLogToFlutter("READ_HISTORY_AUTO_UPDATE_TO_SERVER start (background) mac=$mac sessionId=$sessionId")
                    uploadMethod.invoke(null, mac, uploadListener, uploadWebListener)
                } catch (e: Exception) {
                    uploadTimeoutRunnable?.let { timeoutHandler.removeCallbacks(it) }
                    sendLogToFlutter("READ_HISTORY_AUTO_UPDATE_TO_SERVER invoke failed (background): ${e.message}")
                }
            }

            // 第一步：READ_HISTORY_AUTO —— 写本地 DB
            val localMethod = localBinding.method
            val localListenerType = localMethod.parameterTypes[0]
            val localTimeoutRunnable = Runnable {
                if (!completed.compareAndSet(false, true)) {
                    return@Runnable
                }
                sendLogToFlutter(
                    "READ_HISTORY_AUTO listener timeout, force finish count=${models.size}, sessionId=$sessionId"
                )
                // 发送进度日志信号给 Flutter watchdog，告知同步已结束（虽然无数据）
                // 格式 "syncing: X/Y" 会被 Flutter 的 compositeSyncProgressStream 正则解析
                sendLogToFlutter("syncing: 0/0")
                // 先发送明确的历史读取失败终态，再立即断开 BLE。两类事件都从主线程
                // EventChannel 发出，确保 Flutter 不会先把这次超时误判成普通断连。
                emitCompletion(false, -1001, "READ_HISTORY_AUTO timeout")

                // SDK 没有公开取消 READ_HISTORY_AUTO 的接口，迟到回调由 completed 统一丢弃。
                try {
                    BLEUtils.disconnectBLE(application)
                    BLEUtils.setConnecting(false)
                    BLEUtils.setConnected(false)
                    BLEUtils.setGetToken(false)
                    connectedDevice = null
                    directConnectedMac = null
                    readDatasSuccess = false
                    lastSentPercent = -1
                    sendLogToFlutter(
                        "READ_HISTORY_AUTO timeout requested BLE disconnect sessionId=$sessionId"
                    )
                } catch (e: Exception) {
                    sendLogToFlutter(
                        "READ_HISTORY_AUTO timeout disconnectBLE failed: ${e.message} sessionId=$sessionId"
                    )
                }
            }
            val localListener = buildInterfaceProxy(localListenerType) listener@{ callbackName, callbackArgs ->
                if (completed.get()) {
                    if (callbackName != "progress") {
                        sendLogToFlutter(
                            "READ_HISTORY_AUTO ignore late callback=$callbackName sessionId=$sessionId"
                        )
                    }
                    return@listener
                }
                when (callbackName) {
                    "progress" -> {
                        val bean = callbackArgs?.getOrNull(1) as? HistoryDataBean
                        if (bean != null) {
                            models.add(ringDataToMap(bean))
                            emitHistoryPartial()
                        }
                        val sdkProgress = (callbackArgs?.getOrNull(0) as? Number)?.toDouble()
                        if (sdkProgress != null) {
                            val pct = sdkProgress.toInt().coerceIn(0, 100)
                            val bucket = pct / 5
                            val prevBucket = lastLoggedSdkProgressBucket.get()
                            if (bucket != prevBucket) {
                                lastLoggedSdkProgressBucket.set(bucket)
                                sendLogToFlutter(
                                    "READ_HISTORY_AUTO sdkProgress=" +
                                        String.format(Locale.US, "%.1f", sdkProgress) +
                                        "% collected=${models.size} sessionId=$sessionId"
                                )
                            }
                        }
                        // 节流上报，刷新 Flutter 侧无进度看门狗（与 iOS appConnectComposite syncing 对齐）
                        maybeEmitReadHistorySyncingProgress()
                    }
                    "success", "noNewDataAvailable", "clearHistory", "updateHistoryFinish" -> {
                        timeoutHandler.removeCallbacks(localTimeoutRunnable)
                        sendLogToFlutter("READ_HISTORY_AUTO $callbackName count=${models.size}, data ready -> notify Flutter, upload in background sessionId=$sessionId")
                        emitHistoryPartial(force = true, isFinal = true)
                        // 数据已写入本地 DB / models，立即放行 Flutter（发 appConnectSyncDone）。
                        // 不再等待"上传服务端"——该步在 test/弱网下必然 15s 超时，正是拉数据卡顿 ~28s 的根因。
                        finish(true, null, null)
                        // 上传服务端转为真正的后台 fire-and-forget，不再 gate UI。
                        runOnMainThread { startUploadToServer() }
                    }
                    "error", "serviceError" -> {
                        timeoutHandler.removeCallbacks(localTimeoutRunnable)
                        val code = (callbackArgs?.getOrNull(0) as? Number)?.toInt()
                        val errorMessage = callbackArgs?.getOrNull(0)?.toString()
                        sendLogToFlutter("READ_HISTORY_AUTO error=$callbackName code=$code")
                        finish(false, code, errorMessage)
                    }
                    else -> {
                        sendLogToFlutter("READ_HISTORY_AUTO callback=$callbackName")
                    }
                }
            }
            localMethod.invoke(null, localListener)
            sendLogToFlutter(
                "READ_HISTORY_AUTO listener attached owner=${localBinding.ownerName} uploadSupported=${uploadBinding != null} mac=${mac ?: "null"} sessionId=$sessionId"
            )
            // 首包进度：避免 SDK 首条 progress 晚于 Flutter 看门狗窗口
            sendLogToFlutter("READ_HISTORY_AUTO syncing: 0/1 sessionId=$sessionId")
            lastReadHistorySyncingLogMs.set(SystemClock.elapsedRealtime())
            timeoutHandler.postDelayed(localTimeoutRunnable, READ_HISTORY_AUTO_LISTENER_TIMEOUT_MS)
            return true
        } catch (e: Exception) {
            sendLogToFlutter("attach auto history listener failed: ${e.message}")
            return false
        }
    }

    private fun uploadGoMoreSleepViaServerApi(
        sleepModels: List<*>,
        resultHandler: Result,
        call: MethodCall,
        boolResultHasBeenSet: Boolean
    ): Boolean {
        val uploadMethod = LogicalApi::class.java.methods.firstOrNull {
            it.name == "insertGomoreSleepList" && it.parameterTypes.size == 2
        } ?: return false

        val mapped = ArrayList<Any>()
        sleepModels.forEach { item ->
            val map = item as? Map<*, *> ?: return@forEach
            val normalized = HashMap<String, Any?>()
            map.forEach { (k, v) ->
                if (k != null) normalized[k.toString()] = v
            }
            val sdkObj = goMoreSleepMapToSdkObject(normalized)
            if (sdkObj != null) mapped.add(sdkObj)
        }

        if (mapped.isEmpty()) return false

        val listenerType = uploadMethod.parameterTypes[1]
        val completed = AtomicBoolean(false)
        val timeoutHandler = Handler(Looper.getMainLooper())
        val timeoutRunnable = Runnable {
            if (completed.compareAndSet(false, true)) {
                resultHandler.error("UPLOAD_TIMEOUT", "insertGomoreSleepList 超时", null)
            }
        }
        val listener = buildInterfaceProxy(listenerType) { callbackName, callbackArgs ->
            val lower = callbackName.lowercase()
            when {
                lower.contains("error") || lower.contains("fail") -> {
                    if (completed.compareAndSet(false, true)) {
                        timeoutHandler.removeCallbacks(timeoutRunnable)
                        val msg = callbackArgs?.getOrNull(0)?.toString() ?: callbackName
                        resultHandler.error("UPLOAD_SERVICE_ERROR", msg, null)
                    }
                }
                lower.contains("success") || lower.contains("finish") || lower == "result" -> {
                    if (completed.compareAndSet(false, true)) {
                        timeoutHandler.removeCallbacks(timeoutRunnable)
                        setResult(call, resultHandler, boolResultHasBeenSet, true)
                    }
                }
            }
        }

        return try {
            uploadMethod.invoke(null, mapped, listener)
            timeoutHandler.postDelayed(timeoutRunnable, 15000)
            true
        } catch (e: Exception) {
            timeoutHandler.removeCallbacks(timeoutRunnable)
            sendLogToFlutter("insertGomoreSleepList invoke failed: ${e.message}")
            false
        }
    }

    override fun onMethodCall(call: MethodCall, result: Result) {
        sendLogToFlutter("执行方法${call.method}")
        
        var boolResultHasBeenSet = false;
        var disconnectWatcherReceiver: BroadcastReceiver? = null
        val args = call.arguments as? Map<String, Any>
        val shouldWatchDisconnect =
            call.method == "connectDevice" ||
                call.method == "connectDeviceDirectly" ||
                call.method == "appConnectComposite"

        fun unregisterDisconnectWatcher(fallbackReceiver: BroadcastReceiver? = null) {
            val receiver = disconnectWatcherReceiver ?: fallbackReceiver ?: return
            runCatching {
                broadcastManager.unregisterReceiver(receiver)
            }.onFailure {
                sendLogToFlutter("unregister disconnect watcher failed: ${it.message}")
            }
            disconnectWatcherReceiver = null
        }

        val failed_callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
            Log.e(
                "YongxinChannelHandler",
                "Bluetooth connection failed"
            )
            if (!boolResultHasBeenSet && (call.method != "connectDeviceDirectly" && call.method != "connectDevice")) {
                //result.error("Bluetooth connection failed", "Bluetooth connection failed", null)
                boolResultHasBeenSet = true
            }
            unregisterDisconnectWatcher(receiver)
        }

        if (shouldWatchDisconnect) {
            disconnectWatcherReceiver = broadcastManager.registerReceiver(
                BroadcastManager.ACTION_RING_DISCONNECTED, failed_callback
            )
        }

        when (call.method) {
            // ============ GoMore 相关 ============
            "checkAndAuthorizeGoMore" -> {
                val mac = currentDeviceMac
                val companyKey = args?.get("companyKey") as? String
                if (mac == null || companyKey.isNullOrEmpty()) {
                    result.error("INVALID_ARGUMENTS", "缺少mac或companyKey", null)
                    return
                }
                val companyKeyPrefix = if (companyKey.length >= 8) {
                    companyKey.substring(0, 8)
                } else {
                    companyKey
                }
                val hasConnectedDevice = connectedDevice != null
                val isConnecting = BLEUtils.isConnecting()
                val callbackCompleted = AtomicBoolean(false)
                val timeoutHandler = Handler(Looper.getMainLooper())
                val timeoutRunnable = Runnable {
                    if (callbackCompleted.compareAndSet(false, true)) {
                        sendLogToFlutter(
                            "checkAndAuthorizeGoMore native timeout " +
                                "(${GOMORE_AUTHORIZATION_TIMEOUT_MS / 1000}s) " +
                                "mac=$mac hasConnectedDevice=$hasConnectedDevice isConnecting=$isConnecting"
                        )
                        eventSink?.success(mapOf(
                            "event" to "goMoreAuthProgress",
                            "data" to mapOf(
                                "step" to -1,
                                "desc" to "授权超时(native)",
                                "ts" to (System.currentTimeMillis() / 1000.0)
                            )
                        ))
                        boolResultHasBeenSet = true
                        result.error(
                            "GOMORE_AUTH_TIMEOUT",
                            "GoMore授权超时",
                            mapOf(
                                "mac" to mac,
                                "sdkCallback" to "timeout",
                                "timeoutMs" to GOMORE_AUTHORIZATION_TIMEOUT_MS,
                                "hasConnectedDevice" to hasConnectedDevice,
                                "isConnecting" to isConnecting
                            )
                        )
                    }
                }
                sendLogToFlutter(
                    "checkAndAuthorizeGoMore start mac=$mac keyPrefix=$companyKeyPrefix " +
                        "hasConnectedDevice=$hasConnectedDevice isConnecting=$isConnecting"
                )
                try {
                    timeoutHandler.postDelayed(timeoutRunnable, GOMORE_AUTHORIZATION_TIMEOUT_MS)
                    // Android SDK提供：LogicalApi.goMoreAuthorizationKey(mac, companyApiKey, listener)
                    LogicalApi.goMoreAuthorizationKey(mac, companyKey, object : GoMoreUtils.IGomoreListener {
                        override fun authorization() {
                            if (!callbackCompleted.compareAndSet(false, true)) {
                                sendLogToFlutter("checkAndAuthorizeGoMore authorization duplicated callback ignored")
                                return
                            }
                            timeoutHandler.removeCallbacks(timeoutRunnable)
                            // 授权成功回调
                            sendLogToFlutter("checkAndAuthorizeGoMore authorization success")
                            eventSink?.success(mapOf(
                                "event" to "goMoreAuthProgress",
                                "data" to mapOf(
                                    "step" to 100,
                                    "desc" to "授权成功",
                                    "ts" to (System.currentTimeMillis() / 1000.0)
                                )
                            ))
                            
                            boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, mapOf(
                                "success" to true,
                                "isAuthorized" to true,
                                "deviceId" to (mac ?: ""),
                                "macAddress" to (mac ?: ""),
                                "isNewlyAuthorized" to true
                            ))
                        }
                        
                        override fun unauthorization() {
                            if (!callbackCompleted.compareAndSet(false, true)) {
                                sendLogToFlutter("checkAndAuthorizeGoMore unauthorization duplicated callback ignored")
                                return
                            }
                            timeoutHandler.removeCallbacks(timeoutRunnable)
                            // 授权失败回调
                            sendLogToFlutter(
                                "checkAndAuthorizeGoMore authorization failed " +
                                    "mac=$mac hasConnectedDevice=$hasConnectedDevice isConnecting=$isConnecting"
                            )
                            eventSink?.success(mapOf(
                                "event" to "goMoreAuthProgress",
                                "data" to mapOf(
                                    "step" to -1,
                                    "desc" to "授权失败(unauthorization)",
                                    "ts" to (System.currentTimeMillis() / 1000.0)
                                )
                            ))

                            result.error(
                                "GOMORE_AUTH_FAIL",
                                "GoMore授权失败",
                                mapOf(
                                    "mac" to mac,
                                    "sdkCallback" to "unauthorization",
                                    "hasConnectedDevice" to hasConnectedDevice,
                                    "isConnecting" to isConnecting
                                )
                            )
                        }

                        override fun error(code: Int, msg: String?) {
                            if (!callbackCompleted.compareAndSet(false, true)) {
                                sendLogToFlutter("checkAndAuthorizeGoMore error duplicated callback ignored")
                                return
                            }
                            timeoutHandler.removeCallbacks(timeoutRunnable)
                            // SDK侧错误回调
                            sendLogToFlutter("checkAndAuthorizeGoMore error code=$code msg=${msg ?: ""}")
                            eventSink?.success(mapOf(
                                "event" to "goMoreAuthProgress",
                                "data" to mapOf(
                                    "step" to -1,
                                    "desc" to "授权错误 code=$code msg=${msg ?: ""}",
                                    "ts" to (System.currentTimeMillis() / 1000.0)
                                )
                            ))
                            result.error(
                                "GOMORE_AUTH_ERROR",
                                msg ?: "GoMore授权error",
                                mapOf(
                                    "mac" to mac,
                                    "sdkCallback" to "error",
                                    "errorCode" to code,
                                    "errorMsg" to (msg ?: ""),
                                    "hasConnectedDevice" to hasConnectedDevice,
                                    "isConnecting" to isConnecting
                                )
                            )
                        }
                    })
                } catch (e: Exception) {
                    timeoutHandler.removeCallbacks(timeoutRunnable)
                    if (callbackCompleted.compareAndSet(false, true)) {
                        sendLogToFlutter("checkAndAuthorizeGoMore exception: ${e.message}")
                        boolResultHasBeenSet = true
                        result.error("GOMORE_AUTH_EXCEPTION", e.message, null)
                    } else {
                        sendLogToFlutter("checkAndAuthorizeGoMore exception after completed ignored: ${e.message}")
                    }
                }
            }

            "goMoreGetPersonalInformation" -> {
                val payload = hashMapOf<String, Any>(
                    "age" to (latestGoMoreUserInfo["age"] ?: 0),
                    "gender" to (latestGoMoreUserInfo["gender"] ?: 0),
                    "height" to (latestGoMoreUserInfo["height"] ?: 0),
                    "weight" to (latestGoMoreUserInfo["weight"] ?: 0),
                    "maxHeartRate" to (latestGoMoreUserInfo["maxHeartRate"] ?: -1),
                    "normalHeartRate" to (latestGoMoreUserInfo["normalHeartRate"] ?: -1),
                    "maxOxygenUptake" to (latestGoMoreUserInfo["maxOxygenUptake"] ?: -1),
                )
                sendLogToFlutter("goMoreGetPersonalInformation payload=$payload")
                boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, payload)
            }

            // ============ 复合指令（Connect/Refresh/Bind）相关 ============
            "appConnectComposite" -> {
                var timeMillis = ((args?.get("timeMillis") as? Number)?.toLong() ?: 0L) / 1000L
                val sessionId = args?.get("sessionId") as? String ?: UUID.randomUUID().toString()
                // 这里确实是要传秒，而不是毫秒；
                sendLogToFlutter("appConnectComposite timeMillis=$timeMillis sessionId=$sessionId")

                val completed = AtomicBoolean(false)
                val timeoutHandler = Handler(Looper.getMainLooper())
                val timeoutRunnable = Runnable {
                    if (completed.compareAndSet(false, true)) {
                        val fallbackPayload = HashMap<String, Any?>()
                        fallbackPayload["success"] = true
                        fallbackPayload["timeMillis"] = timeMillis
                        fallbackPayload.putAll(latestAppConnectPayload)
                        sendLogToFlutter("appConnectComposite timeout, fallback payload=$fallbackPayload")
                        boolResultHasBeenSet =
                            setResult(call, result, boolResultHasBeenSet, fallbackPayload)
                    }
                }

                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    if (!completed.compareAndSet(false, true)) {
                        broadcastManager.unregisterReceiver(receiver)
                    } else {
                        timeoutHandler.removeCallbacks(timeoutRunnable)
                        val payload = buildCompositePayload(intent, timeMillis)
                        sendLogToFlutter("appConnectComposite callback payload=$payload")
                        boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, payload)
                    }
                    broadcastManager.unregisterReceiver(receiver)
                }

                try {
                    // 文档要求：复合指令前先注册历史监听，避免 SDK 内部空指针
                    if (!attachCompositeHistoryAutoListener(timeMillis, sessionId)) {
                        boolResultHasBeenSet = true
                        unregisterDisconnectWatcher()
                        result.error(
                            "APP_CONNECT_HISTORY_LISTENER_MISSING",
                            "APP_CONNECT skipped because READ_HISTORY_AUTO listener was not attached",
                            null
                        )
                        return
                    }

                    broadcastManager.registerReceiver(BroadcastManager.ACTION_APP_CONNECT, callback)
                    // 优先使用带 listener 的新签名：APP_CONNECT(long, listenerLite)
                    // 若当前 SDK 仅提供旧签名，则自动降级到 APP_CONNECT(long)
                    val appConnectWithListener = LmAPI::class.java.methods.firstOrNull {
                        it.name == "APP_CONNECT" && it.parameterTypes.size == 2
                    }
                    if (appConnectWithListener != null) {
                        val listenerType = appConnectWithListener.parameterTypes[1]
                        val listener = buildInterfaceProxy(listenerType) { callbackName, callbackArgs ->
                            when {
                                callbackName.contains("error", ignoreCase = true) -> {
                                    val code = callbackArgs?.getOrNull(0)
                                    sendLogToFlutter("APP_CONNECT listener error=$code")
                                }
                                callbackName.contains("appConnect", ignoreCase = true) -> {
                                    sendLogToFlutter("APP_CONNECT listener callback=$callbackName")
                                }
                            }
                        }
                        appConnectWithListener.invoke(null, timeMillis, listener)
                    } else {
                        LmAPI.APP_CONNECT(timeMillis)
                    }
                    timeoutHandler.postDelayed(timeoutRunnable, 8000)
                } catch (e: Exception) {
                    timeoutHandler.removeCallbacks(timeoutRunnable)
                    boolResultHasBeenSet = true
                    unregisterDisconnectWatcher()
                    sendLogToFlutter("appConnectComposite exception: ${e.message}")
                    result.error("APP_CONNECT_EXCEPTION", e.message, null)
                }
            }

            "goMoreSetPersonalInformation" -> {
                val age = (args?.get("age") as? Number)?.toInt() ?: 0
                val gender = (args?.get("gender") as? Number)?.toInt() ?: 0
                val height = (args?.get("height") as? Number)?.toInt() ?: 0
                val weight = (args?.get("weight") as? Number)?.toInt() ?: 0
                // SDK 对可选参数要求合法正整数或 0（不传），-1 会导致戒指拒绝（result=false）
                val maxHeartRate = (args?.get("maxHeartRate") as? Number)?.toInt()?.takeIf { it > 0 } ?: (220 - age)
                val normalHeartRate = (args?.get("normalHeartRate") as? Number)?.toInt()?.takeIf { it > 0 } ?: 0
                val maxOxygenUptake = (args?.get("maxOxygenUptake") as? Number)?.toInt()?.takeIf { it > 0 } ?: 0

                sendLogToFlutter("goMoreSetPersonalInformation send: age=$age gender=$gender height=$height weight=$weight maxHr=$maxHeartRate restHr=$normalHeartRate maxO2=$maxOxygenUptake")

                // BLE 通知可能触发多次 / 多线程；用 AtomicBoolean 保证只对 result 回复一次，避免 Reply already submitted
                val hasReplied = AtomicBoolean(false)
                
                try {
                    LmAPI.SET_GOMORE_USER(
                        age, gender, height, weight,
                        maxHeartRate, normalHeartRate, maxOxygenUptake,
                        object : IGoMoreUserListener {
                            override fun setUserInfoResult(success: Boolean) {
                                if (!hasReplied.compareAndSet(false, true)) {
                                    sendLogToFlutter("goMoreSetPersonalInformation: duplicate callback ignored, success=$success")
                                    return
                                }
                                sendLogToFlutter("goMoreSetPersonalInformation result=$success")
                                if (success) {
                                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                                } else {
                                    result.error("GOMORE_SET_USER_FAIL", "set user fail", null)
                                }
                            }
                            
                            override fun getUserInfoResult(
                                sex: Int, height: Int, weight: Int, 
                                age: Int, maximumHeartRate: Int, 
                                normalHeartRate: Int, maximalOxygenUptake: Int
                            ) {
                                latestGoMoreUserInfo["gender"] = sex
                                latestGoMoreUserInfo["height"] = height
                                latestGoMoreUserInfo["weight"] = weight
                                latestGoMoreUserInfo["age"] = age
                                latestGoMoreUserInfo["maxHeartRate"] = maximumHeartRate
                                latestGoMoreUserInfo["normalHeartRate"] = normalHeartRate
                                latestGoMoreUserInfo["maxOxygenUptake"] = maximalOxygenUptake
                                sendLogToFlutter(
                                    "goMoreGetPersonalInformation callback cache updated: " +
                                        "sex=$sex, height=$height, weight=$weight, age=$age"
                                )
                            }
                        }
                    )
                } catch (e: Exception) {
                    if (hasReplied.compareAndSet(false, true)) {
                        sendLogToFlutter("goMoreSetPersonalInformation exception: ${e.message}")
                        result.error("GOMORE_SET_USER_EXCEPTION", e.message, null)
                    }
                }
            }

            "readGoMoreSleepData" -> {
                try {
                    val sleepList = ArrayList<Map<String, Any>>()
                    val readStartMs = SystemClock.elapsedRealtime()
                    fun emitProgress(phase: String, terminal: Boolean = false) {
                        val count = sleepList.size
                        val elapsedMs = SystemClock.elapsedRealtime() - readStartMs
                        runOnMainThread {
                            eventSink?.success(mapOf(
                                "event" to "gomoreSleepReadProgress",
                                "data" to mapOf(
                                    "phase" to phase,
                                    "count" to count,
                                    "elapsedMs" to elapsedMs,
                                    "terminal" to terminal
                                )
                            ))
                        }
                    }
                    com.lm.sdk.LmAPILite.GET_GOMORE_SLEEP(object : com.lm.sdk.inter.IGoMoreListener {
                        override fun overviewOfSleep(goMoreSleep: com.lm.sdk.mode.GoMoreSleep?) {
                            val item = HashMap<String, Any>()
                            item.putAll(goMoreSleepObjectToMap(goMoreSleep).filterValues { it != null }
                                .mapValues { it.value as Any })
                            item["type"] = item["type"] ?: 0
                            sleepList.add(item)
                            emitProgress("overview")
                        }

                        override fun sleepStaging(goMoreSleep: com.lm.sdk.mode.GoMoreSleep?) {
                            val item = HashMap<String, Any>()
                            item.putAll(goMoreSleepObjectToMap(goMoreSleep).filterValues { it != null }
                                .mapValues { it.value as Any })
                            item["type"] = item["type"] ?: 0
                            sleepList.add(item)
                            emitProgress("staging")
                        }

                        override fun dataUploadFinish() {
                            emitProgress("finish", terminal = true)
                            sendLogToFlutter("readGoMoreSleepData finish count=${sleepList.size}")
                            boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, mapOf(
                                "count" to sleepList.size,
                                "sleepModels" to sleepList
                            ))
                        }

                        override fun noSleepData() {
                            emitProgress("noSleepData", terminal = true)
                            sendLogToFlutter("readGoMoreSleepData noSleepData")
                            boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, mapOf(
                                "count" to 0,
                                "sleepModels" to emptyList<Map<String, Any>>()
                            ))
                        }
                    })
                } catch (e: Exception) {
                    sendLogToFlutter("readGoMoreSleepData exception: ${e.message}")
                    result.error("GOMORE_SLEEP_EXCEPTION", e.message, null)
                }
            }

            "getGoMoreSleepData" -> {
                val time = (args?.get("time") as? Number)?.toLong()
                if (time == null) {
                    result.error("INVALID_ARGUMENTS", "getGoMoreSleepData 缺少 time", null)
                    return
                }
                val dayString = formatDateBySeconds(time)
                sendLogToFlutter("getGoMoreSleepData request day=$dayString")
                val methodNames = listOf("getSleepFromServiceWithGomore", "getSleepDataFromService")
                var invoked = false
                for (methodName in methodNames) {
                    val method = LogicalApi::class.java.methods.firstOrNull {
                        it.name == methodName && it.parameterTypes.size == 2
                    } ?: continue
                    val callbackType = method.parameterTypes[1]
                    val callback = buildInterfaceProxy(callbackType) { callbackName, callbackArgs ->
                        when (callbackName) {
                            "sleepDataSuccess" -> {
                                val bean = callbackArgs?.getOrNull(0) ?: return@buildInterfaceProxy
                                val payload = sleepBeanToMap(bean)
                                sendLogToFlutter("getGoMoreSleepData success payload=$payload")
                                boolResultHasBeenSet =
                                    setResult(call, result, boolResultHasBeenSet, payload)
                            }
                            "error", "serviceError" -> {
                                val message = callbackArgs?.getOrNull(0)?.toString() ?: "unknown"
                                sendLogToFlutter("getGoMoreSleepData error=$message")
                                result.error("GOMORE_SLEEP_SERVICE_ERROR", message, null)
                            }
                        }
                    }
                    try {
                        method.invoke(null, dayString, callback)
                        invoked = true
                        break
                    } catch (e: Exception) {
                        sendLogToFlutter("getGoMoreSleepData invoke $methodName failed: ${e.message}")
                    }
                }
                if (!invoked) {
                    result.error("NOT_SUPPORTED", "Android SDK 未找到 GoMore 睡眠详情接口", null)
                }
            }

            "getProtocolV2SleepData" -> {
                val time = (args?.get("time") as? Number)?.toLong()
                if (time == null) {
                    result.error("INVALID_ARGUMENTS", "getProtocolV2SleepData 缺少 time", null)
                    return
                }
                val dayString = formatDateBySeconds(time)
                sendLogToFlutter("getProtocolV2SleepData request day=$dayString")
                val methodNames = listOf("getSleepFromServiceWithGomore", "getSleepDataFromService")
                var invoked = false
                for (methodName in methodNames) {
                    val method = LogicalApi::class.java.methods.firstOrNull {
                        it.name == methodName && it.parameterTypes.size == 2
                    } ?: continue
                    val callbackType = method.parameterTypes[1]
                    val callback = buildInterfaceProxy(callbackType) { callbackName, callbackArgs ->
                        when (callbackName) {
                            "sleepDataSuccess" -> {
                                val bean = callbackArgs?.getOrNull(0) ?: return@buildInterfaceProxy
                                val payload = sleepBeanToMap(bean)
                                sendLogToFlutter("getProtocolV2SleepData success via=$methodName payload=$payload")
                                boolResultHasBeenSet =
                                    setResult(call, result, boolResultHasBeenSet, payload)
                            }
                            "error", "serviceError" -> {
                                val message = callbackArgs?.getOrNull(0)?.toString() ?: "unknown"
                                sendLogToFlutter("getProtocolV2SleepData error via=$methodName message=$message")
                                result.error("PROTOCOL_V2_SLEEP_SERVICE_ERROR", message, null)
                            }
                        }
                    }
                    try {
                        method.invoke(null, dayString, callback)
                        sendLogToFlutter("getProtocolV2SleepData invoke=$methodName")
                        invoked = true
                        break
                    } catch (e: Exception) {
                        sendLogToFlutter("getProtocolV2SleepData invoke $methodName failed: ${e.message}")
                    }
                }
                if (!invoked) {
                    result.error("NOT_SUPPORTED", "Android SDK 未找到二代协议睡眠服务接口", null)
                }
            }

            "getGoMoreSleepDataBatch" -> {
                val dates = (args?.get("dates") as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList()
                if (dates.isEmpty()) {
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, emptyList<Map<String, Any?>>())
                    return
                }
                sendLogToFlutter("getGoMoreSleepDataBatch request dates=$dates")
                val methodNames = listOf("getSleepDataWithGoMoreBatch", "getSleepDataBatchFromService")
                var invoked = false
                for (methodName in methodNames) {
                    val method = LogicalApi::class.java.methods.firstOrNull {
                        it.name == methodName && it.parameterTypes.size == 2
                    } ?: continue
                    val callbackType = method.parameterTypes[1]
                    val callback = buildInterfaceProxy(callbackType) { callbackName, callbackArgs ->
                        when (callbackName) {
                            "sleepDataBatchSuccess" -> {
                                val list = callbackArgs?.getOrNull(0) as? List<*> ?: emptyList<Any>()
                                val payload = list.map { bean ->
                                    if (bean != null) sleepBatchBeanToMap(bean) else emptyMap()
                                }
                                sendLogToFlutter("getGoMoreSleepDataBatch success count=${payload.size}")
                                boolResultHasBeenSet =
                                    setResult(call, result, boolResultHasBeenSet, payload)
                            }
                            "error", "serviceError" -> {
                                val message = callbackArgs?.getOrNull(0)?.toString() ?: "unknown"
                                result.error("GOMORE_SLEEP_BATCH_ERROR", message, null)
                            }
                        }
                    }
                    try {
                        method.invoke(null, dates, callback)
                        invoked = true
                        break
                    } catch (e: Exception) {
                        sendLogToFlutter("getGoMoreSleepDataBatch invoke $methodName failed: ${e.message}")
                    }
                }
                if (!invoked) {
                    result.error("NOT_SUPPORTED", "Android SDK 未找到 GoMore 睡眠批量接口", null)
                }
            }

            "uploadGoMoreSleepData" -> {
                val mac = currentDeviceMac
                if (mac.isNullOrEmpty()) {
                    result.error("NO_DEVICE", "uploadGoMoreSleepData 失败：未连接戒指", null)
                    return
                }
                val sleepModels = args?.get("sleepModels") as? List<*> ?: emptyList<Any>()
                sendLogToFlutter("uploadGoMoreSleepData start mac=$mac models=${sleepModels.size}")

                // 优先对齐 demo：直接上传 GoMore 数据集到服务端
                // LogicalApi.insertGomoreSleepList(List<GoMoreSleep>, IWebCommonListener)
                val serverUploadStarted = uploadGoMoreSleepViaServerApi(
                    sleepModels = sleepModels,
                    resultHandler = result,
                    call = call,
                    boolResultHasBeenSet = boolResultHasBeenSet
                )
                if (serverUploadStarted) {
                    return
                }

                // 兜底方案：触发历史数据上传到服务端（兼容低版本 SDK）
                sendLogToFlutter("uploadGoMoreSleepData fallback to READ_HISTORY_UPDATE_TO_SERVER")
                val methodName = "READ_HISTORY_UPDATE_TO_SERVER"
                val method = com.lm.sdk.LmAPILite::class.java.methods.firstOrNull {
                    it.name == methodName && it.parameterTypes.size == 5
                } ?: LmAPI::class.java.methods.firstOrNull {
                    it.name == methodName && it.parameterTypes.size == 5
                }
                if (method == null) {
                    result.error("NOT_SUPPORTED", "Android SDK 未找到 READ_HISTORY_UPDATE_TO_SERVER", null)
                    return
                }
                val completed = AtomicBoolean(false)
                val timeoutHandler = Handler(Looper.getMainLooper())
                val timeoutRunnable = Runnable {
                    if (completed.compareAndSet(false, true)) {
                        result.error("UPLOAD_TIMEOUT", "uploadGoMoreSleepData 超时", null)
                    }
                }
                try {
                    val historyListenerType = method.parameterTypes[3]
                    val webListenerType = method.parameterTypes[4]
                    val historyListener = buildInterfaceProxy(historyListenerType) { callbackName, callbackArgs ->
                        when (callbackName) {
                            "error" -> {
                                if (completed.compareAndSet(false, true)) {
                                    val code = callbackArgs?.getOrNull(0)?.toString() ?: "unknown"
                                    timeoutHandler.removeCallbacks(timeoutRunnable)
                                    result.error("UPLOAD_HISTORY_ERROR", "history error=$code", null)
                                }
                            }
                            "noNewDataAvailable", "success" -> {
                                sendLogToFlutter("uploadGoMoreSleepData history callback=$callbackName")
                            }
                        }
                    }
                    val webListener = buildInterfaceProxy(webListenerType) { callbackName, callbackArgs ->
                        when (callbackName) {
                            "updateHistoryFinish" -> {
                                if (completed.compareAndSet(false, true)) {
                                    timeoutHandler.removeCallbacks(timeoutRunnable)
                                    sendLogToFlutter("uploadGoMoreSleepData updateHistoryFinish")
                                    boolResultHasBeenSet =
                                        setResult(call, result, boolResultHasBeenSet, true)
                                }
                            }
                            "serviceError", "error" -> {
                                if (completed.compareAndSet(false, true)) {
                                    val msg = callbackArgs?.getOrNull(0)?.toString() ?: "serviceError"
                                    timeoutHandler.removeCallbacks(timeoutRunnable)
                                    result.error("UPLOAD_SERVICE_ERROR", msg, null)
                                }
                            }
                        }
                    }
                    method.invoke(null, 0.toByte(), 0L, mac, historyListener, webListener)
                    timeoutHandler.postDelayed(timeoutRunnable, 25000)
                } catch (e: Exception) {
                    timeoutHandler.removeCallbacks(timeoutRunnable)
                    result.error("UPLOAD_EXCEPTION", e.message, null)
                }
            }

            "loadUserLatestHistory" -> {
                val method = LogicalApi::class.java.methods.firstOrNull {
                    it.name == "loadUserLatestHistory" && it.parameterTypes.size == 1
                }
                if (method == null) {
                    result.error("NOT_SUPPORTED", "Android SDK 未找到 loadUserLatestHistory", null)
                    return
                }
                val callbackType = method.parameterTypes[0]
                val callback = buildInterfaceProxy(callbackType) { callbackName, callbackArgs ->
                    when (callbackName) {
                        "userLastHistoryTime" -> {
                            val time = callbackArgs?.getOrNull(0)?.let { toLongValue(it) } ?: 0L
                            sendLogToFlutter("loadUserLatestHistory success time=$time")
                            boolResultHasBeenSet =
                                setResult(call, result, boolResultHasBeenSet, time.toInt())
                        }
                        "error", "serviceError" -> {
                            val message = callbackArgs?.getOrNull(0)?.toString() ?: "unknown"
                            result.error("LOAD_USER_LATEST_HISTORY_ERROR", message, null)
                        }
                    }
                }
                try {
                    method.invoke(null, callback)
                } catch (e: Exception) {
                    result.error("LOAD_USER_LATEST_HISTORY_EXCEPTION", e.message, null)
                }
            }

            "syncProtocolV2HistoryToServer" -> {
                val mac = currentDeviceMac
                if (mac.isNullOrEmpty()) {
                    result.error("NO_DEVICE", "syncProtocolV2HistoryToServer 失败：未连接戒指", null)
                    return
                }
                val sinceTimestampSeconds =
                    (args?.get("sinceTimestampSeconds") as? Number)?.toLong() ?: 0L
                val historyType: Byte = if (sinceTimestampSeconds > 0) 0.toByte() else 1.toByte()
                val methodName = "READ_HISTORY_UPDATE_TO_SERVER"
                val method = com.lm.sdk.LmAPILite::class.java.methods.firstOrNull {
                    it.name == methodName && it.parameterTypes.size == 5
                } ?: LmAPI::class.java.methods.firstOrNull {
                    it.name == methodName && it.parameterTypes.size == 5
                }
                if (method == null) {
                    result.error("NOT_SUPPORTED", "Android SDK 未找到 READ_HISTORY_UPDATE_TO_SERVER", null)
                    return
                }
                val syncRegistration = registerProtocolV2SyncWaiter(
                    mac = mac,
                    sinceTimestampSeconds = sinceTimestampSeconds,
                    historyType = historyType,
                    result = result
                )
                if (syncRegistration.joinedExisting) {
                    sendLogToFlutter(
                        "syncProtocolV2HistoryToServer join existing token=${syncRegistration.token} " +
                            "incomingSince=$sinceTimestampSeconds activeSince=${syncRegistration.activeSinceTimestampSeconds}"
                    )
                    return
                }
                val syncToken = syncRegistration.token
                val completed = AtomicBoolean(false)
                val historyReadCompleted = AtomicBoolean(false)
                val timeoutHandler = Handler(Looper.getMainLooper())
                lateinit var timeoutRunnable: Runnable
                lateinit var historySuccessGraceRunnable: Runnable
                historySuccessGraceRunnable = Runnable {
                    if (completed.compareAndSet(false, true)) {
                        timeoutHandler.removeCallbacks(timeoutRunnable)
                        sendLogToFlutter(
                            "syncProtocolV2HistoryToServer finish by history success grace token=$syncToken"
                        )
                        finishProtocolV2SyncSuccess(syncToken)
                    }
                }
                timeoutRunnable = Runnable {
                    if (completed.compareAndSet(false, true)) {
                        timeoutHandler.removeCallbacks(historySuccessGraceRunnable)
                        sendLogToFlutter(
                            "syncProtocolV2HistoryToServer timeout token=$syncToken historyRead=${historyReadCompleted.get()}"
                        )
                        finishProtocolV2SyncError(
                            syncToken,
                            "SYNC_PROTOCOL_V2_TIMEOUT",
                            "syncProtocolV2HistoryToServer 超时",
                            null
                        )
                    }
                }
                try {
                    val historyListenerType = method.parameterTypes[3]
                    val webListenerType = method.parameterTypes[4]
                    fun finishSuccess(reason: String) {
                        if (completed.compareAndSet(false, true)) {
                            timeoutHandler.removeCallbacks(timeoutRunnable)
                            timeoutHandler.removeCallbacks(historySuccessGraceRunnable)
                            sendLogToFlutter(
                                "syncProtocolV2HistoryToServer finish reason=$reason token=$syncToken"
                            )
                            finishProtocolV2SyncSuccess(syncToken)
                        }
                    }

                    fun finishError(code: String, message: String) {
                        if (completed.compareAndSet(false, true)) {
                            timeoutHandler.removeCallbacks(timeoutRunnable)
                            timeoutHandler.removeCallbacks(historySuccessGraceRunnable)
                            sendLogToFlutter(
                                "syncProtocolV2HistoryToServer error code=$code message=$message token=$syncToken"
                            )
                            finishProtocolV2SyncError(syncToken, code, message, null)
                        }
                    }

                    val historyListener = buildInterfaceProxy(historyListenerType) { callbackName, callbackArgs ->
                        when (callbackName) {
                            "error" -> {
                                val code = callbackArgs?.getOrNull(0)?.toString() ?: "unknown"
                                finishError("SYNC_PROTOCOL_V2_HISTORY_ERROR", "history error=$code")
                            }
                            "noNewDataAvailable" -> {
                                sendLogToFlutter("syncProtocolV2HistoryToServer noNewDataAvailable")
                                finishSuccess("noNewDataAvailable")
                            }
                            "success" -> {
                                if (historyReadCompleted.compareAndSet(false, true)) {
                                    sendLogToFlutter(
                                        "syncProtocolV2HistoryToServer history success, wait updateHistoryFinish token=$syncToken"
                                    )
                                    timeoutHandler.removeCallbacks(historySuccessGraceRunnable)
                                    timeoutHandler.postDelayed(historySuccessGraceRunnable, 3000)
                                } else {
                                    sendLogToFlutter(
                                        "syncProtocolV2HistoryToServer history success duplicate token=$syncToken"
                                    )
                                }
                            }
                        }
                    }
                    val webListener = buildInterfaceProxy(webListenerType) { callbackName, callbackArgs ->
                        when (callbackName) {
                            "updateHistoryFinish" -> {
                                sendLogToFlutter("syncProtocolV2HistoryToServer updateHistoryFinish")
                                finishSuccess("updateHistoryFinish")
                            }
                            "serviceError", "error" -> {
                                val msg = callbackArgs?.getOrNull(0)?.toString() ?: "serviceError"
                                finishError("SYNC_PROTOCOL_V2_SERVICE_ERROR", msg)
                            }
                        }
                    }
                    sendLogToFlutter(
                        "syncProtocolV2HistoryToServer start mac=$mac since=$sinceTimestampSeconds type=$historyType token=$syncToken"
                    )
                    method.invoke(null, historyType, sinceTimestampSeconds, mac, historyListener, webListener)
                    timeoutHandler.postDelayed(timeoutRunnable, 25000)
                } catch (e: Exception) {
                    timeoutHandler.removeCallbacks(timeoutRunnable)
                    timeoutHandler.removeCallbacks(historySuccessGraceRunnable)
                    finishProtocolV2SyncError(
                        syncToken,
                        "SYNC_PROTOCOL_V2_EXCEPTION",
                        e.message ?: "syncProtocolV2HistoryToServer exception",
                        null
                    )
                }
            }

            // 检查设备是否通过系统蓝牙配对
            "isDeviceSystemPaired" -> {
                val mac = args?.get("mac") as? String
                sendLogToFlutter("[isDeviceSystemPaired] 检查MAC: $mac")
                if (mac != null) {
                    try {
                        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
                        val device = bluetoothAdapter?.getRemoteDevice(mac)
                        // Android bondState: 10=BOND_NONE, 11=BOND_BONDING, 12=BOND_BONDED
                        val bondState = device?.bondState ?: 10
                        val isPaired = bondState == 12 // BOND_BONDED
                        val isSdkConnected = BLEUtils.isGetToken() || BLEUtils.isConnected()
                        val isConnecting = BLEUtils.isConnecting()
                        sendLogToFlutter("[isDeviceSystemPaired] bondState=$bondState, isPaired=$isPaired, isSDKConnected=$isSdkConnected, isConnecting=$isConnecting")
                        boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, mapOf(
                            "isPaired" to isPaired,
                            "isSDKConnected" to isSdkConnected,
                            "availableUUID" to "" // Android 不需要 UUID，直接用 MAC
                        ))
                    } catch (e: Exception) {
                        sendLogToFlutter("[isDeviceSystemPaired] 异常: ${e.message}")
                        boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, mapOf(
                            "isPaired" to false,
                            "isSDKConnected" to false,
                            "availableUUID" to ""
                        ))
                    }
                } else {
                    sendLogToFlutter("[isDeviceSystemPaired] 参数错误：缺少mac")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, mapOf(
                        "isPaired" to false,
                        "isSDKConnected" to false,
                        "availableUUID" to ""
                    ))
                }
            }

            "startScan" -> {
                currentScanId = java.util.UUID.randomUUID().toString()
                val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
                if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
                    sendLogToFlutter("[Scan #$currentScanId] 系统蓝牙未开启或不可用，跳过 startLeScan")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                } else {
                    sendLogToFlutter("[Scan #$currentScanId] Started scanning for devices")
                    devicesMap.clear()
                    BLEUtils.startLeScan(application, leScanCallback)
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                }
            }

            "stopScan" -> {
                sendLogToFlutter("停止扫描设备")
                BLEUtils.stopLeScan(application, leScanCallback)
                boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
            }

            "connectDevice" -> {
                sendLogToFlutter("📍 [connectDevice] 方法开始执行")
                BLEUtils.stopLeScan(application, leScanCallback)
                sendLogToFlutter("📍 [connectDevice] 已停止扫描")
                
                val mac = args?.get("mac") as? String
                sendLogToFlutter("📍 [connectDevice] MAC地址: $mac")
                
                if (mac != null) {
                    val deviceInfo = devicesMap[mac]
                    sendLogToFlutter("📍 [connectDevice] 设备信息: ${if (deviceInfo != null) "存在" else "不存在"}")
                    
                    if (deviceInfo != null) {
                        val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                            sendLogToFlutter("✅ [connectDevice] 收到连接成功广播 thread=${Thread.currentThread().name}")
                            // 连接状态通过 connectStateCallback 事件通道通知，不需要在这里返回结果
                            runCatching { broadcastManager.unregisterReceiver(receiver) }
                                .onFailure {
                                    sendLogToFlutter("❌ [connectDevice] unregisterReceiver 异常: ${it.message}")
                                }
                        }
                        broadcastManager.registerReceiver(BroadcastManager.ACTION_RING_CONNECTED, callback)
                        sendLogToFlutter("📍 [connectDevice] 已注册连接成功广播接收器")

                        applyHidConnectionMode(deviceInfo, "connectDevice")
                        sendLogToFlutter("📍 [connectDevice] 调用 BLEUtils.connectLockByBLE | 设备名称: ${deviceInfo.device.name} | 设备地址: ${deviceInfo.device.address} | 当前 BLEUtils.isConnecting: ${BLEUtils.isConnecting()}")
                        
                        try {
                            // 开始监控连接状态（每2秒输出一次状态）
                            startConnectionMonitor(mac)
                            
                            BLEUtils.connectLockByBLE(application, deviceInfo.device)
                            sendLogToFlutter("✅ [connectDevice] BLEUtils.connectLockByBLE 调用成功")
                        } catch (e: Exception) {
                            sendLogToFlutter("❌ [connectDevice] BLEUtils.connectLockByBLE 抛出异常: ${e.message}，异常堆栈: ${e.stackTraceToString()}")
                            stopConnectionMonitor()
                        }
                        
                        connectedDevice = deviceInfo
                        sendLogToFlutter("📍 [connectDevice] 已设置 connectedDevice")
                        
                        // 立即返回 true，表示连接动作已成功发起
                        // 实际的连接状态会通过 connectStateCallback 事件通道通知
                        boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                        sendLogToFlutter("📍 [connectDevice] 方法执行完成，返回 true")
                    } else {
                        sendLogToFlutter(
                            "❌ [connectDevice] 连接设备失败：设备信息不存在 | " +
                                "devicesMapKeys=${devicesMap.keys.joinToString()} | " +
                                "connectedDevice=${connectedDevice?.device?.address} | directConnectedMac=$directConnectedMac"
                        )
                        boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                    }

                } else {
                    sendLogToFlutter("❌ [connectDevice] 连接设备失败：MAC地址为空")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                }
            }

            "currentDevice" -> {
                val mac = currentDeviceMac
                if (mac != null) {
                    boolResultHasBeenSet = setResult(
                        call, result, boolResultHasBeenSet,
                        mapOf(
                            "mac" to mac,
                            "rssi" to currentDeviceRssi,
                            "peripheralName" to currentDeviceName
                        )
                    )
                } else {
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, null)
                }
            }

            "disconnectConnect" -> {
                sendLogToFlutter("断开连接设备")
                BLEUtils.disconnectBLE(application)
                val clearDevices = args?.get("clearDevices") as? Boolean ?: true

                // 清理设备映射和连接状态
                if (clearDevices) {
                    devicesMap.clear()
                }
                connectedDevice = null
                directConnectedMac = null
                readDatasSuccess = false
                lastSentPercent = -1
                BLEUtils.setConnecting(false);
                boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
            }

            // 解除系统蓝牙配对（解绑时调用，防止系统配对固件下搜索不到戒指）
            "removeBond" -> {
                val mac = args?.get("mac") as? String
                sendLogToFlutter("解除系统蓝牙配对 MAC: $mac")
                try {
                    if (mac != null) {
                        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
                        val device = bluetoothAdapter?.getRemoteDevice(mac)
                        if (device != null) {
                            BLEUtils.removeBond(device)
                            sendLogToFlutter("解除系统蓝牙配对成功 MAC: $mac")
                            boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                        } else {
                            sendLogToFlutter("解除系统蓝牙配对失败：未找到设备 MAC: $mac")
                            boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                        }
                    } else {
                        sendLogToFlutter("解除系统蓝牙配对失败：缺少mac参数")
                        boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                    }
                } catch (e: Exception) {
                    sendLogToFlutter("解除系统蓝牙配对异常: ${e.message}")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                }
            }

            "removeBondedRingDevices" -> {
                sendLogToFlutter("扫描前清理 Android 已配对戒指设备")
                try {
                    val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
                    val bondedDevices = bluetoothAdapter?.bondedDevices ?: emptySet<BluetoothDevice>()
                    val removedDevices = mutableListOf<Map<String, String>>()
                    for (device in bondedDevices) {
                        if (!isLikelyOurBondedRingDevice(device)) continue
                        val address = device.address ?: continue
                        val name = try {
                            device.name ?: ""
                        } catch (e: Exception) {
                            ""
                        }
                        sendLogToFlutter("扫描前发现已配对戒指设备 name=$name MAC=$address，准备解除配对")
                        BLEUtils.removeBond(device)
                        removedDevices.add(
                            mapOf(
                                "mac" to address,
                                "name" to name
                            )
                        )
                    }
                    sendLogToFlutter("扫描前已配对戒指清理完成 count=${removedDevices.size}")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, removedDevices)
                } catch (e: Exception) {
                    sendLogToFlutter("扫描前清理已配对戒指异常: ${e.message}")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, emptyList<Map<String, String>>())
                }
            }

            "readBattery" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val p0 = intent.getIntExtra("p0", 0)
                    val p1 = intent.getIntExtra("p1", 0)
                    sendLogToFlutter("电池电量：$p1")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, p1)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(BroadcastManager.ACTION_RING_BATTERY, callback)
                LmAPI.GET_BATTERY(0x00.toByte())  //0x00获取电量，0x01获取充电状态，0x02电量推送
            }

            // 读取充电状态：0=未充电，1=充电中，2=充满
            "readChargingState" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val p0 = intent.getIntExtra("p0", 0)
                    val p1 = intent.getIntExtra("p1", 0)
                    // p0==1 表示这是充电状态回调，p1: 0=未充电 1=充电中 2=充满
                    if (p0 == 1) {
                        sendLogToFlutter("充电状态：$p1")
                        boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, p1)
                        broadcastManager.unregisterReceiver(receiver)
                    }
                }
                broadcastManager.registerReceiver(BroadcastManager.ACTION_RING_BATTERY, callback)
                LmAPI.GET_BATTERY(0x01.toByte())  //0x01获取充电状态
            }

            "readHeartRate" -> {
                var duration = args?.get("duration") as? Int
                // 如果持续时间为null就默认30s
                if (duration == null) {
                    duration = 0x30
                }
                // waveForm：是否配置波形 0不上传 1上传
                // acqTime：采集时间 （byte）30是正常时间,0为一直采集
                var tempHeart = 0
                LmAPI.GET_HEART_ROTA(0x01.toByte(), duration.toByte(), object : IHeartListener {
                    override fun progress(progress: Int) {
                        sendLogToFlutter("readHeartRate============progress  $progress")
                        eventSink?.success(
                            mapOf(
                                "event" to "heartRateResult", "data" to mapOf(
                                    "progress" to progress, "result" to tempHeart, "error" to null
                                )
                            )
                        )
                    }

                    override fun resultDataSHOUSHI(heart: Int, bloodOxygen: Int) {
                        sendLogToFlutter("心率: $heart, 血氧: $bloodOxygen")    
                    }

                    // 心率，心率变异性，压力，温度
                    override fun resultData(heart: Int, heartRota: Int, stress: Int, temp: Int) {
                        sendLogToFlutter("心率：$heart, HRV：$heartRota, 压力：$stress, 温度：$temp")
                        tempHeart = heart
                    }

                    override fun waveformData(
                        seq: Byte,
                        number: Byte,
                        waveData: String
                    ) {

                    } // 心率返回波形图数据分析：waveData

                    override fun rriData(seq: Byte, number: Byte, data: String) {} // 心率测量中的RR间期值
                    override fun error(value: Int) {
                        sendLogToFlutter("心率=====> 错误：$value")
                        handleMeasurementError("heartRateResult", value)
                    }

                    override fun success() {
                        eventSink?.success(
                            mapOf(
                                "event" to "heartRateResult",
                                "data" to mapOf(
                                    "progress" to 100,
                                    "result" to tempHeart,
                                    "error" to null
                                )
                            )
                        )
                    }

                    override fun stop() {
                        sendLogToFlutter("停止心率检查")
                    }
                })
                boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
            }

            "stopHeartRate" -> {
                val stopMethod = LmAPI::class.java.methods.firstOrNull { method ->
                    method.parameterTypes.isEmpty() &&
                        method.name.contains("STOP", ignoreCase = true) &&
                        method.name.contains("HEART", ignoreCase = true)
                }
                if (stopMethod != null) {
                    stopMethod.invoke(null)
                    sendLogToFlutter("停止心率测量成功：${stopMethod.name}")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                } else {
                    sendLogToFlutter("停止心率测量失败：未找到停止心率SDK方法")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                }
            }

            "readHRV" -> {
                boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
            }

            "readTemperature" -> {
                LmAPI.READ_TEMP(object : ITempListener {
                    override fun resultData(p0: Int) {
                        sendLogToFlutter("温度=====> ${p0 / 100}")
                        boolResultHasBeenSet =
                            setResult(call, result, boolResultHasBeenSet, p0 / 100)
                    }

                    override fun testing(p0: Int) {}
                    override fun error(p0: Int) {
                        sendLogToFlutter("温度=====> 错误：$p0")
                    }
                })
            }

            "readO2" -> {
                var tempO2 = 0
                LmAPI.GET_HEART_Q2(0x01.toByte(), object : IQ2Listener {
                    override fun progress(progress: Int) {
                        sendLogToFlutter("血氧测量进度=====> $progress")
                        eventSink?.success(
                            mapOf(
                                "event" to "O2Result",
                                "data" to mapOf(
                                    "progress" to progress,
                                    "result" to 0,
                                    "error" to null
                                )
                            )
                        )
                    }

                    override fun resultData(heart: Int, o2: Int, temperature: Int) {
                        sendLogToFlutter("血氧=====> $o2")
                        tempO2 = o2
                    }

                    override fun waveformData(p0: Byte, p1: Byte, p2: String?) {}
                    override fun error(value: Int) {
                        sendLogToFlutter("血氧=====> 错误：$value")
                        handleMeasurementError("O2Result", value)
                    }

                    override fun success() {
                        eventSink?.success(
                            mapOf(
                                "event" to "O2Result",
                                "data" to mapOf(
                                    "progress" to 100,
                                    "result" to tempO2,
                                    "error" to null
                                )
                            )
                        )
                    }
                })
                boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
            }

            "readDatas" -> {
                val rawTimestamp = args?.get("timestamp")
                val timestamp = when (rawTimestamp) {
                    is Int -> rawTimestamp.toLong()
                    is Long -> rawTimestamp
                    else -> 0L
                }
                val sessionId = args?.get("sessionId") as? String
                    ?: "readDatas-${System.currentTimeMillis()}"
                val mac = currentDeviceMac ?: ""
                val partialModels = ArrayList<Map<String, Any>>()
                var lastPartialEmitCount = 0
                fun emitReadDatasPartial(force: Boolean = false, isFinal: Boolean = false) {
                    val count = partialModels.size
                    if (count <= 0) return
                    if (lastPartialEmitCount >= count) return
                    if (!force && count - lastPartialEmitCount < 50) return
                    val payloadModels =
                        ArrayList<Map<String, Any>>(partialModels.subList(lastPartialEmitCount, count))
                    lastPartialEmitCount = count
                    if (payloadModels.isEmpty()) return
                    runOnMainThread {
                        eventSink?.success(
                            mapOf(
                                "event" to "ringHistorySyncPartial",
                                "data" to mapOf(
                                    "sessionId" to sessionId,
                                    "source" to "readDatas",
                                    "mac" to mac,
                                    "count" to count,
                                    "deltaCount" to payloadModels.size,
                                    "models" to payloadModels,
                                    "isFinal" to isFinal,
                                    "isDelta" to true,
                                    "timeMillis" to timestamp
                                )
                            )
                        )
                    }
                }
                // 重置进度跟踪变量
                lastSentPercent = -1
                sendLogToFlutter("readDatas 开始同步数据 时间戳：$timestamp")
                readDatasSuccess = false
                LmAPI.READ_HISTORY(
                    // if (readAll) 0x01.toByte() else 0x00.toByte(),
                    0x01.toByte(),
                    timestamp, // todo 时间戳
                    object : IHistoryListener {
                        override fun error(code: Int) {
                            sendLogToFlutter("readDatas 同步数据失败：$code")
                            // 重置状态
                            lastSentPercent = -1
                        }
                        override fun success() {
                            sendLogToFlutter("readDatas 同步数据完成")
                            emitReadDatasPartial(force = true, isFinal = true)
                            // 重置状态
                            lastSentPercent = -1
                            if (!readDatasSuccess) {
                                boolResultHasBeenSet =
                                    setResult(call, result, boolResultHasBeenSet, true)
                            }
                            readDatasSuccess = true
                        }

                        override fun progress(progress: Double, historyDataBean: HistoryDataBean) {
                            partialModels.add(ringDataToMap(historyDataBean))
                            emitReadDatasPartial()
                            val currentPercent = progress.toInt()
                            // 性能优化：只在进度变化超过5%时发送日志，避免频繁的跨端通信
                            // 这样可以减少从几百次通信降低到20次左右，大幅提升性能
                            if (currentPercent % 5 == 0 && currentPercent != lastSentPercent) {
                                sendLogToFlutter("readDatas 📦 进度：$currentPercent%")
                                lastSentPercent = currentPercent
                            }
                            // 已删除：打印具体数据模型的代码严重影响性能，已移除
                            // sendLogToFlutter("readDatas 📄 当前数据模型：${ringDataToMap(historyDataBean)}")
                        }
                        override fun noNewDataAvailable() {
                            sendLogToFlutter("readDatas 没有新数据")
                            // 重置状态
                            lastSentPercent = -1
                        }
                    },
                )
            }

            "getObjectsFrom" -> {
                val timestamp = args?.get("time") as? Int
                val mac = currentDeviceMac
                sendLogToFlutter("getObjectsFrom timestamp: $timestamp mac: $mac")  
                if (timestamp != null && mac != null) {
                    val currentTime = System.currentTimeMillis() / 1000

                    val objects =
                        DataApi.instance.queryHistoryData(timestamp.toLong(), currentTime, mac)
                    boolResultHasBeenSet = setResult(
                        call,
                        result,
                        boolResultHasBeenSet,
                        objects.map { ringDataToMap(it) })
                } else {
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, null)
                }
            }

            "getObjectsOf" -> {
                val timestamp = args?.get("time") as? Int
                sendLogToFlutter("getObjectsOf timestamp: $timestamp")
                val mac = currentDeviceMac
                if (timestamp != null && mac != null) {
                    val calendar = Calendar.getInstance()
                    calendar.timeInMillis = timestamp.toLong() * 1000
                    calendar.set(Calendar.HOUR_OF_DAY, 0)
                    calendar.set(Calendar.MINUTE, 0)
                    calendar.set(Calendar.SECOND, 0)
                    calendar.set(Calendar.MILLISECOND, 0)
                    val startTime = calendar.timeInMillis / 1000

                    calendar.set(Calendar.HOUR_OF_DAY, 23)
                    calendar.set(Calendar.MINUTE, 59)
                    calendar.set(Calendar.SECOND, 59)
                    calendar.set(Calendar.MILLISECOND, 999)
                    val endTime = calendar.timeInMillis / 1000
                    val objects = DataApi.instance.queryHistoryData(startTime, endTime, mac)

                    boolResultHasBeenSet = setResult(
                        call,
                        result,
                        boolResultHasBeenSet,
                        objects.map { ringDataToMap(it) })
                } else {
                    boolResultHasBeenSet =
                        setResult(call, result, boolResultHasBeenSet, listOf<Any>())
                }
            }

            "getLatestObject" -> {
                result.error("UNIMPLEMENTED", "getLatestObject is not implemented", null)
            }

            "deleteHistoryData" -> {
                sendLogToFlutter("deleteHistoryData 清除所有历史数据")
                try {
                    DataApi.instance.deleteHistoryData()
                    sendLogToFlutter("deleteHistoryData 清除所有历史数据成功")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                } catch (e: Exception) {
                    sendLogToFlutter("deleteHistoryData 清除所有历史数据失败: ${e.message}")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                }
            }

            "setFrequency" -> {
                val frequency = args?.get("frequency") as? Int
                if (frequency != null) {
                    val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                        sendLogToFlutter("设置测量频率成功=====> $frequency")
                        boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                        broadcastManager.unregisterReceiver(receiver)
                    }
                    broadcastManager.registerReceiver(
                        BroadcastManager.ACTION_RING_SET_COLLECTION, callback
                    )
                    LmAPI.SET_COLLECTION(frequency)
                } else {
                    sendLogToFlutter("设置测量频率失败：频率值为空")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                }

            }

            "readFrequency" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val data = intent.getIntExtra("p0", 0)
                    sendLogToFlutter("读取测量频率=====> $data")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, data)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_GET_COLLECTION, callback
                )
                LmAPI.GET_COLLECTION()
            }

            "readSteps" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val step = intent.getIntExtra("p0", 0)
                    sendLogToFlutter("步数=====> $step")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, step)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_STEPS, callback
                )
                LmAPI.STEP_COUNTING()
            }

            "isDidConnect" -> {
                boolResultHasBeenSet =
                    setResult(call, result, boolResultHasBeenSet, BLEUtils.isConnecting())
            }

            "readTime" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val timeStamp = intent.getLongExtra("p1", 0L)
                    sendLogToFlutter("时间=====> $timeStamp")
                    boolResultHasBeenSet =
                        setResult(call, result, boolResultHasBeenSet, timeStamp.toDouble())
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(BroadcastManager.ACTION_RING_SYNC_TIME, callback)
                LmAPI.READ_TIME()
            }

            "syncTime" -> {
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    sendLogToFlutter("同步时间成功")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                    broadcastManager.unregisterReceiver(receiver)
                }

                broadcastManager.registerReceiver(BroadcastManager.ACTION_RING_SYNC_TIME, callback)
                val offset = getTimeZone()
                LmAPI.SYNC_TIME_ZONE(offset)
            }

            "readAppVersion" -> {
                // 固件版本号 0x00获取固件版本，0x01获取硬件版本
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val version: String? = intent.getStringExtra("p1")
                    sendLogToFlutter("软件版本=====> $version")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, version)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_GET_VERSION, callback
                )
                LmAPI.GET_VERSION(0x00.toByte())
            }

            "readHardWareVersion" -> {
                // 硬件版本号 0x00获取固件版本，0x01获取硬件版本
                val callback: (Intent, BroadcastReceiver) -> Unit = { intent, receiver ->
                    val version: String? = intent.getStringExtra("p1")
                    sendLogToFlutter("硬件版本=====> $version")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, version)
                    broadcastManager.unregisterReceiver(receiver)
                }
                broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_GET_VERSION, callback
                )
                LmAPI.GET_VERSION(0x01.toByte())
            }

            "calculateSleep" -> {
                val timestamp = args?.get("time") as? Int
                sendLogToFlutter("计算睡眠数据 时间戳：$timestamp")
                if (timestamp != null) {
                    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    sdf.timeZone = TimeZone.getDefault()
                    val date = Date(timestamp.toLong() * 1000)
                    val formattedDate = sdf.format(date)
                    val mac = currentDeviceMac
                    val sleep = LogicalApi.calculateSleep(formattedDate, mac, 0)
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, mapOf(
                        "hours" to sleep.hours,
                        "minutes" to sleep.minutes,
                        "allHours" to sleep.allHours,
                        "allMinutes" to sleep.allMinutes,
                        "sleepHours" to sleep.sleepHours,
                        "sleepMinutes" to sleep.sleepMinutes,
                        "highTime" to sleep.highTime,
                        "lowTime" to sleep.lowTime,
                        "ydTime" to sleep.ydTime,
                        "qxTime" to sleep.qxTime,
                        "start_time" to sleep.startTime,
                        "end_time" to sleep.endTime,
                        "sleepDataList" to sleep.historyDataBeanList.map { ringDataToMap(it) }
                    ))
                } else {
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, null)
                }
            }

            "createToken" -> {
                sendLogToFlutter("=========>获取SDK Token")
                val inputIdentifier = (args?.get("userIdentifier") as? String)?.trim()
                val userIdentifier = when {
                    !inputIdentifier.isNullOrEmpty() -> inputIdentifier
                    !currentDeviceMac.isNullOrEmpty() -> currentDeviceMac
                    else -> null
                }

                if (userIdentifier.isNullOrEmpty()) {
                    sendLogToFlutter("❌ Token获取失败：缺少userIdentifier和当前连接设备MAC")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, null)
                    return
                }

                LogicalApi.createToken(
                    "9380f98857b04cf1a1e806c07b660820",
                    userIdentifier,
                    object : ICreateToken {
                        override fun getTokenSuccess() {
                            sendLogToFlutter("✅ Token获取成功 userIdentifier=$userIdentifier")
                            boolResultHasBeenSet =
                                setResult(call, result, boolResultHasBeenSet, true)
                        }

                        override fun error(msg: String?) {
                            sendLogToFlutter("❌ Token获取失败：$msg")
                            boolResultHasBeenSet =
                                setResult(call, result, boolResultHasBeenSet, null)
                        }
                    })
            }

            "getFirmwareVersionList" -> {
                sendLogToFlutter("=========>获取固件列表")
                try {
                    val firmwareListMethod = LogicalApi::class.java.methods.firstOrNull {
                        it.name == "firmwareList" && it.parameterTypes.size == 2
                    }
                    if (firmwareListMethod == null) {
                        sendLogToFlutter("getFirmwareVersionList: 未找到 LogicalApi.firmwareList(category, callback)")
                        boolResultHasBeenSet =
                            setResult(call, result, boolResultHasBeenSet, null)
                        return
                    }

                    val callbackType = firmwareListMethod.parameterTypes[1]
                    val requestedCategory =
                        (args?.get("category") as? String)?.trim()?.uppercase(Locale.getDefault())
                            ?.takeIf { it.isNotEmpty() }

                    val currentVersion = (latestAppConnectPayload["firmwareVersion"] as? String)
                        ?: Regex("firmwareVersion='([^']+)'")
                            .find(latestAppConnectPayload["raw"]?.toString() ?: "")
                            ?.groupValues
                            ?.getOrNull(1)
                    val inferredCategory = currentVersion
                        ?.let { Regex("(Z[0-9A-Z]+)$").find(it)?.groupValues?.getOrNull(1) }
                        ?.uppercase(Locale.getDefault())

                    val categoryQueue = LinkedHashSet<String>()
                    if (requestedCategory != null) categoryQueue.add(requestedCategory)
                    if (inferredCategory != null) categoryQueue.add(inferredCategory)
                    // 兜底尝试常见类别
                    categoryQueue.add("Z5F")
                    categoryQueue.add("Z5T")
                    categoryQueue.add("Z3R")
                    val categories = categoryQueue.toList()

                    val done = AtomicBoolean(false)

                    fun completeSuccess(mappedList: List<Map<String, String>>) {
                        if (!done.compareAndSet(false, true)) return
                        sendLogToFlutter("getFirmwareVersionList success: count=${mappedList.size}")
                        boolResultHasBeenSet =
                            setResult(call, result, boolResultHasBeenSet, mappedList)
                    }

                    fun completeFail(reason: String) {
                        if (!done.compareAndSet(false, true)) return
                        sendLogToFlutter("getFirmwareVersionList failed: $reason")
                        boolResultHasBeenSet =
                            setResult(call, result, boolResultHasBeenSet, null)
                    }

                    fun mapFirmwareList(rawList: Any?): List<Map<String, String>> {
                        val list = rawList as? Iterable<*> ?: return emptyList()
                        val mapped = mutableListOf<Map<String, String>>()
                        list.forEach { firmware ->
                            if (firmware == null) return@forEach
                            val fileName = getterValue(firmware, "fileName")?.toString()
                            val filePath = getterValue(firmware, "filePath")?.toString()
                            val fileUrl = getterValue(firmware, "fileUrl")?.toString()
                            if (!fileName.isNullOrBlank() &&
                                !filePath.isNullOrBlank() &&
                                !fileUrl.isNullOrBlank()
                            ) {
                                mapped.add(
                                    mapOf(
                                        "fileName" to fileName,
                                        "filePath" to filePath,
                                        "fileUrl" to fileUrl
                                    )
                                )
                            }
                        }
                        return mapped
                    }

                    fun fetchByCategory(index: Int) {
                        if (index >= categories.size) {
                            completeFail("all categories empty: ${categories.joinToString(",")}")
                            return
                        }
                        val category = categories[index]
                        sendLogToFlutter("getFirmwareVersionList request category=$category")
                        val listener = buildInterfaceProxy(callbackType) { callbackName, callbackArgs ->
                            when (callbackName) {
                                "firmwareListResult", "success", "result" -> {
                                    val mapped = mapFirmwareList(callbackArgs?.firstOrNull())
                                    if (mapped.isNotEmpty()) {
                                        completeSuccess(mapped)
                                    } else {
                                        fetchByCategory(index + 1)
                                    }
                                }

                                "serviceError", "error", "fail", "onError" -> {
                                    val msg = callbackArgs?.firstOrNull()?.toString()
                                    sendLogToFlutter(
                                        "getFirmwareVersionList category=$category error=${msg ?: "unknown"}"
                                    )
                                    fetchByCategory(index + 1)
                                }
                            }
                        }
                        try {
                            firmwareListMethod.invoke(null, category, listener)
                        } catch (e: Exception) {
                            sendLogToFlutter("getFirmwareVersionList invoke error category=$category err=${e.message}")
                            fetchByCategory(index + 1)
                        }
                    }

                    fetchByCategory(0)
                } catch (e: Exception) {
                    sendLogToFlutter("getFirmwareVersionList exception: ${e.message}")
                    boolResultHasBeenSet =
                        setResult(call, result, boolResultHasBeenSet, null)
                }
            }

            "firmwareDownload" -> {
                val version = args?.get("version") as? String
                val fileUrl = args?.get("fileUrl") as? String
                val fileName = (args?.get("fileName") as? String)?.trim()

                if (version.isNullOrBlank() || fileUrl.isNullOrBlank()) {
                    sendLogToFlutter("firmwareDownload: 参数缺失 version=$version fileUrl=$fileUrl")
                    boolResultHasBeenSet =
                        setResult(call, result, boolResultHasBeenSet, false)
                } else {
                    val resolvedFileName =
                        if (!fileName.isNullOrBlank()) fileName else version

                    val versionBean = VersionBean()
                    versionBean.download = fileUrl
                    versionBean.fileName = resolvedFileName
                    versionBean.version = version

                    OtaApi.downloadFile(
                        versionBean,
                        object : VersionCallback {
                            override fun success(successVersion: String?) {
                                sendLogToFlutter(
                                    "firmwareDownload success fileName=${versionBean.fileName}, version=$successVersion"
                                )
                                boolResultHasBeenSet =
                                    setResult(call, result, boolResultHasBeenSet, true)
                            }

                            override fun error() {
                                sendLogToFlutter(
                                    "firmwareDownload error version=$version fileName=$resolvedFileName"
                                )
                                boolResultHasBeenSet =
                                    setResult(call, result, boolResultHasBeenSet, false)
                            }
                        },
                        YongxinRingPlugin.activity
                    )
                }

            }

            "checkDeviceVersion" -> {
                sendLogToFlutter("=========>检查固件版本")
                val version = args?.get("version") as String
                OtaApi.checkVersion(version, object : VersionCallback {
                    override fun success(newVersion: String?) {
                        if (newVersion != null) {
                            sendLogToFlutter("✅ 发现新版本：$newVersion")
                        } else {
                            sendLogToFlutter("✅ 当前已是最新版本")
                        }
                        boolResultHasBeenSet =
                            setResult(call, result, boolResultHasBeenSet, newVersion)
                    }

                    override fun error() {
                        sendLogToFlutter("checkDeviceVersion出错")
                        boolResultHasBeenSet =
                            setResult(call, result, boolResultHasBeenSet, null)
                    }
                }, YongxinRingPlugin.activity);
            }


            "startApolloOTA" -> {
                sendLogToFlutter("=========>升级固件")
                val version = args?.get("version") as? String
                val fileUrl = args?.get("fileUrl") as? String

                val device = connectedDevice?.device ?: currentDeviceMac?.let { mac ->
                    BluetoothAdapter.getDefaultAdapter()?.getRemoteDevice(mac)
                }
                val rssi = currentDeviceRssi

                if (device != null && version != null) {
                    OtaApi.otaUpdateWithVersion(
                        version,
                        device,
                        rssi,
                        YongxinRingPlugin.activity,
                        object : LmOtaProgressListener {
                            override fun error(message: String) {
                                sendLogToFlutter("OTA: 升级失败 - $message")
                                Handler(Looper.getMainLooper()).post {
                                    eventSink?.success(
                                        mapOf(
                                            "event" to "ringOtaProgress",
                                            "data" to -1
                                        )
                                    )
                                }
                            }

                            override fun onProgress(i: Int) {
                                sendLogToFlutter("OTA: 升级进度 $i%")
                                Handler(Looper.getMainLooper()).post {
                                    eventSink?.success(
                                        mapOf(
                                            "event" to "ringOtaProgress",
                                            "data" to i
                                        )
                                    )
                                }
                            }

                            override fun onComplete() {
                                sendLogToFlutter("OTA: 固件传输成功")
                                Handler(Looper.getMainLooper()).post {
                                    eventSink?.success(
                                        mapOf(
                                            "event" to "ringOtaProgress",
                                            "data" to 101
                                        )
                                    )
                                }
                            }

                            override fun isLatestVersion() {
                                sendLogToFlutter("OTA: 已是最新版本")
                                Handler(Looper.getMainLooper()).post {
                                    eventSink?.success(
                                        mapOf(
                                            "event" to "ringOtaProgress",
                                            "data" to 101
                                        )
                                    )
                                }
                            }
                        }
                    )
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                } else {
                    sendLogToFlutter("OTA: 升级失败 - 设备或版本信息缺失")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                }
            }

            // 工厂模式：使用本地固件文件刷入
            "startOtaFromLocalFile" -> {
                sendLogToFlutter("=========>工厂模式：本地文件OTA")
                val filePath = args?.get("filePath") as? String
                val version = args?.get("version") as? String

                val device = connectedDevice?.device ?: currentDeviceMac?.let { mac ->
                    BluetoothAdapter.getDefaultAdapter()?.getRemoteDevice(mac)
                }
                val rssi = currentDeviceRssi

                if (device != null && version != null) {
                    sendLogToFlutter("工厂OTA: 版本=$version, 文件=$filePath")

                    val startedByLocal = if (!filePath.isNullOrBlank()) {
                        startFactoryOtaFromLocalFile(filePath, device, rssi)
                    } else {
                        sendLogToFlutter("OTA(工厂): filePath为空，跳过本地OTA")
                        false
                    }

                    if (!startedByLocal) {
                        sendLogToFlutter("OTA(工厂): 回退到云端版本OTA version=$version")
                        startFactoryOtaWithCloudVersion(version, device, rssi)
                    } else {
                        // 防止 SDK 在失败场景不触发任何回调，导致 Flutter 端一直停在 0%
                        startFactoryLocalOtaWatchdog()
                    }

                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                } else {
                    sendLogToFlutter("OTA(工厂): 设备或版本信息缺失 device=$device version=$version")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                }
            }

            // 工厂模式：按版本号从 SDK 服务器下载并刷写（远端OTA）
            "startOtaWithVersion" -> {
                sendLogToFlutter("=========>工厂模式：远端版本OTA")
                val version = args?.get("version") as? String

                val device = connectedDevice?.device ?: currentDeviceMac?.let { mac ->
                    BluetoothAdapter.getDefaultAdapter()?.getRemoteDevice(mac)
                }
                val rssi = currentDeviceRssi

                if (device != null && version != null) {
                    sendLogToFlutter("工厂远端OTA: version=$version")
                    startFactoryOtaWithCloudVersion(version, device, rssi)
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                } else {
                    sendLogToFlutter("工厂远端OTA: 参数缺失 device=$device version=$version")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, false)
                }
            }

            "getBluetoothRSSI" -> {
                sendLogToFlutter("=========>读取蓝牙设备实时RSSI")
                sendLogToFlutter("当前RSSI信号强度：$currentDeviceRssi")
                boolResultHasBeenSet =
                    setResult(call, result, boolResultHasBeenSet, currentDeviceRssi)
            }

            "connectDeviceDirectly" -> {
                // BLEUtils.stopLeScan(application, leScanCallback)

                if (BLEUtils.isConnecting()) {
                    sendLogToFlutter("SDK仍处于连接状态，先强制断开")
                    BLEUtils.setConnected(false);
                    BLEUtils.setGetToken(false);
                    BLEUtils.disconnectBLE(application);
                    Thread.sleep(500)
                }

                val callbackCompleted = AtomicBoolean(false)
                val timeoutHandler = Handler(Looper.getMainLooper())
                val connectTimeoutMs = ((args?.get("timeoutMs") as? Number)?.toLong() ?: 12_000L)
                    .coerceIn(12_000L, 60_000L)
                var connectedReceiver: BroadcastReceiver? = null
                var disconnectedReceiver: BroadcastReceiver? = null

                fun cleanupReceivers() {
                    val connectedHash = connectedReceiver?.let { System.identityHashCode(it) }
                    val disconnectedHash = disconnectedReceiver?.let { System.identityHashCode(it) }
                    sendLogToFlutter("[connectDeviceDirectly] cleanupReceivers connected=$connectedHash disconnected=$disconnectedHash")
                    connectedReceiver?.let { receiver ->
                        runCatching { broadcastManager.unregisterReceiver(receiver) }
                            .onFailure {
                                sendLogToFlutter("[connectDeviceDirectly] unregister connectedReceiver 异常: ${it.message}")
                            }
                    }
                    disconnectedReceiver?.let { receiver ->
                        runCatching { broadcastManager.unregisterReceiver(receiver) }
                            .onFailure {
                                sendLogToFlutter("[connectDeviceDirectly] unregister disconnectedReceiver 异常: ${it.message}")
                            }
                    }
                    connectedReceiver = null
                    disconnectedReceiver = null
                }

                fun finishConnectDirect(success: Boolean, reason: String) {
                    val threadName = Thread.currentThread().name
                    if (!callbackCompleted.compareAndSet(false, true)) {
                        sendLogToFlutter("[connectDeviceDirectly] finishConnectDirect 跳过(已完成) reason=$reason thread=$threadName")
                        return
                    }
                    sendLogToFlutter("[connectDeviceDirectly] finishConnectDirect 开始 success=$success reason=$reason thread=$threadName")
                    timeoutHandler.removeCallbacksAndMessages(null)
                    cleanupReceivers()
                    sendLogToFlutter("connectDeviceDirectly 结束: success=$success, reason=$reason")
                    boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, success)
                }

                connectedReceiver = broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_CONNECTED
                ) { _, _ ->
                    sendLogToFlutter("直接连接设备成功 thread=${Thread.currentThread().name} directConnectedMac=$directConnectedMac")
                    finishConnectDirect(true, "ACTION_RING_CONNECTED")
                }
                disconnectedReceiver = broadcastManager.registerReceiver(
                    BroadcastManager.ACTION_RING_DISCONNECTED
                ) { _, _ ->
                    sendLogToFlutter("直接连接设备失败：收到断开广播 thread=${Thread.currentThread().name}")
                    finishConnectDirect(false, "ACTION_RING_DISCONNECTED")
                }
                timeoutHandler.postDelayed({
                    sendLogToFlutter("直接连接设备失败：超时未收到连接结果(${connectTimeoutMs / 1000}s)")
                    finishConnectDirect(false, "timeout")
                }, connectTimeoutMs)
                val mac = args?.get("mac") as? String
                if (mac != null) {
                    sendLogToFlutter("尝试直接连接设备 MAC: $mac")
                    val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
                    if (bluetoothAdapter != null) {
                        try {
                            sendLogToFlutter("尝试直接连接设备 MAC: $mac")
                            val device = bluetoothAdapter.getRemoteDevice(mac)
                            if (device != null) {
                                val cachedDeviceInfo = devicesMap[mac] ?: connectedDevice?.takeIf {
                                    it.device.address.equals(mac, ignoreCase = true)
                                }
                                val tempDeviceInfo = cachedDeviceInfo ?: run {
                                    sendLogToFlutter("尝试创建临时的BleDeviceInfo")
                                    LogicalApi.getBleDeviceInfoWhenBleScan(
                                        device,
                                        -50,
                                        ByteArray(0),
                                        false
                                    )
                                }
                                val explicitIsHidRing = args?.get("isHidRing") as? Boolean
                                if (tempDeviceInfo != null) {
                                    applyHidConnectionMode(tempDeviceInfo, "connectDeviceDirectly")
                                } else if (explicitIsHidRing == true) {
                                    BLEUtils.isHIDDevice = true
                                    sendLogToFlutter(
                                        "[connectDeviceDirectly] BLEUtils.isHIDDevice=true (explicit isHidRing)"
                                    )
                                } else {
                                    BLEUtils.isHIDDevice = false
                                    sendLogToFlutter(
                                        "[connectDeviceDirectly] BLEUtils.isHIDDevice=false (no scan info, explicit isHidRing=$explicitIsHidRing)"
                                    )
                                }
                                sendLogToFlutter("直接连接设备 MAC: $mac")
                                BLEUtils.connectLockByBLE(application, device)
                                if (tempDeviceInfo != null) {
                                    sendLogToFlutter("创建临时的BleDeviceInfo成功")
                                    connectedDevice = tempDeviceInfo
                                    directConnectedMac = null
                                    // boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)

                                } else {
                                    // 如果LogicalApi创建失败，保存MAC地址作为备用
                                    sendLogToFlutter("无法创建BleDeviceInfo，使用备用MAC: $mac")
                                    connectedDevice = null
                                    directConnectedMac = mac
                                    // boolResultHasBeenSet = setResult(call, result, boolResultHasBeenSet, true)
                                }
                            } else {
                                sendLogToFlutter("直接连接失败：无法获取设备")
                                finishConnectDirect(false, "remote_device_null")
                            }
                        } catch (e: Exception) {
                            sendLogToFlutter("直接连接失败：${e.message}")
                            finishConnectDirect(false, "exception:${e.message}")
                        }
                    } else {
                        sendLogToFlutter("直接连接失败：无法获取蓝牙适配器")
                        finishConnectDirect(false, "bluetooth_adapter_null")
                    }
                } else {
                    sendLogToFlutter("直接连接失败：MAC地址为空")
                    finishConnectDirect(false, "mac_null")
                }
            }
            
            // 游戏相关方法
            "initGame" -> {
                try {


                    val userId = args?.get("userId") as? String
                    val userName = args?.get("userName") as? String ?: ""
                    val portrait = args?.get("portrait") as? String ?: ""
                    val language = args?.get("language") as? String ?: "en"
                    val isRelease = args?.get("isRelease") as? Boolean ?: false
                    gameDebugEnabled = args?.get("gameDebugEnabled") as? Boolean ?: false


                    // 测试key,不能用来打正式包，否则获取不到游戏列表
                    val testApiKey = "hUm1ScVVsWndVRlp0TVZOalJscDBaRWhrVDFKc2NIcFhhMUpUWVZVeFYxWnFVbGhoTVhCeVZqQmtTMk50VGtkaFJuQlhVbFJXVlZkWGNFZFdNbEpHVGSkZOWEJWYlhoMlpERmtjMaFVtMVNjVlZzV25kVlJscD"
                    // 正式key
                    val apiKey = "RmhoTVVwVVdWWlZlRll4V25GVmJHaG9UVmhDZVZacVFtdFRNazUwVkd0a2FGSnVRbGhWYkZKWFZsWmtXR05GWkZkTmJFcEhWR3hhWVZaWFNrWk9XRUpXWWxob01scEVSbXRqTVZwMFQxZG9UbUV4Y0ZsV1ZFa3h"
                    SMGameClient.init(application, if (isRelease) apiKey else testApiKey , "快康")


                    if (userId.isNullOrEmpty()) {
                        result.error("INVALID_ARGUMENT", "用户ID不能为空", null)
                        return
                    }
                    
                    SMGameClient.getInstance().language = language
                    SMGameClient.getInstance().setUserInfo(userId, userName, portrait)
                    SMGameClient.getInstance().setGameGSensorListener(object : IGameGSensor {
                        override fun openGSensor(p0: Int) {
                        }

                        override fun closeGSensor(p0: Int) {

                        }

                        override fun closeGame() {
                            handleGameClose()
                        }

                        override fun jsVirtualKeys(p0: Int) {
                            Log.d("YongxinChannelHandler", "虚拟按键事件: $p0")
                        }
                    })
                    result.success(true)
                } catch (e: Exception) {
                    sendLogToFlutter("初始化游戏用户信息失败: ${e.message}")    
                    result.error("INIT_USER_INFO_ERROR", "初始化用户信息失败: ${e.message}", null)
                }
            }
            
            "getGameList" -> {
                try {
                    SMGameClient.getInstance().getGameList(object : IGameListCallback {
                        override fun onSuccessFul(datas: List<SMGameInfo>) {
                            val gameMapList = ArrayList<HashMap<String, Any>>()
                            
                            for (game in datas) {
                                val gameMap = HashMap<String, Any>()
                                gameMap["id"] = game.gid
                                gameMap["name"] = game.gname
                                gameMap["iconUrl"] = game.urls
                                gameMap["title"] = game.title
                                gameMap["background"] = game.background
                                gameMap["needVip"] = game.needVip==1
                                gameMapList.add(gameMap)
                            }
                            
                            android.os.Handler(android.os.Looper.getMainLooper()).post {
                                result.success(gameMapList)
                            }
                        }
                        
                        override fun onError(message: String) {
                            android.os.Handler(android.os.Looper.getMainLooper()).post {
                                result.error("GET_GAMES_ERROR", "获取游戏列表失败: $message", null)
                            }
                        }
                    })
                } catch (e: Exception) {
                    sendLogToFlutter("获取游戏列表异常: ${e.message}")    

                    result.error("GET_GAMES_ERROR", "获取游戏列表异常: ${e.message}", null)
                }
            }
            
            "openGame" -> {
                try {
                    val gameId = args?.get("gameId") as? Int
                    if (gameId == null) {
                        result.error("INVALID_ARGUMENT", "游戏ID不能为空", null)
                        return
                    }
                    
                    if (gameActivity == null) {
                        gameActivity = YongxinRingPlugin.activity
                    }
                    
                    if (gameActivity == null) {
                        result.error("NO_ACTIVITY", "无法获取Activity实例", null)
                        return
                    }
                    
                    // 先获取游戏列表，找到对应ID的游戏信息
                    SMGameClient.getInstance().getGameList(object : IGameListCallback {
                        override fun onSuccessFul(datas: List<SMGameInfo>) {
                            val gameInfo = datas.find { it.gid == gameId }
                            
                            if (gameInfo == null) {
                                android.os.Handler(android.os.Looper.getMainLooper()).post {
                                    result.error("GAME_NOT_FOUND", "未找到ID为${gameId}的游戏", null)
                                }
                                return
                            }
                            
                            recentPlayedGame = gameInfo
                            recentGameStartTime = System.currentTimeMillis()
                            Log.d("YongxinChannelHandler", "准备启动游戏: ${gameInfo.gname}, gid: ${gameInfo.gid}")
                            
                            gameActivity?.let { activity ->
                                val listener = object : IGameOpenListener {
                                    override fun openResult(success: Boolean) {
                                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                                            if (success) {
                                                sendLogToFlutter("游戏加载成功 ${gameInfo.gname}")
                                                // 游戏启动成功后开始读取传感器数据
                                                try {
                                                    sendLogToFlutter("开始读取传感器数据用于游戏")
                                                    // 注册6轴传感器监听器，用于游戏控制
                                                    LmAPI.READ_6_AXIS_SENSORS_SHIMI(axisListener)
                                                    
                                                    Log.d("YongxinChannelHandler", "已启动传感器数据读取")
                                                } catch (e: Exception) {
                                                    Log.e("YongxinChannelHandler", "启动传感器失败", e)
                                                    sendLogToFlutter("启动传感器数据读取失败: ${e.message}")
                                                }
                                                
                                                val gameData = HashMap<String, Any>()
                                                gameData["gameId"] = gameInfo.gid
                                                gameData["gameName"] = gameInfo.gname
                                                gameData["startTime"] = recentGameStartTime
                                                
                                                sendLogToFlutter("游戏将要打开: ${gameInfo.gname}")
                                                eventSink?.success(mapOf(
                                                    "event" to "onWillOpenGame",
                                                    "data" to gameData
                                                ))
                                                result.success(true)
                                            } else {
                                                sendLogToFlutter("游戏加载失败: ${gameInfo.gname}")
                                                Log.e("YongxinChannelHandler", "游戏加载失败: ${gameInfo.gname}")
                                                result.error("OPEN_GAME_ERROR", "游戏加载失败", null)
                                            }
                                        }
                                    }
                                }
                                
                                SMGameClient.getInstance().startGame(gameInfo, activity, listener)
                            }
                        }
                        
                        override fun onError(message: String) {
                            android.os.Handler(android.os.Looper.getMainLooper()).post {
                                result.error("OPEN_GAME_ERROR", "获取游戏列表失败: $message", null)
                            }
                        }
                    })
                } catch (e: Exception) {
                    sendLogToFlutter("打开游戏失败: ${e.message}")    
                    Log.e("YongxinChannelHandler", "打开游戏失败", e)
                    result.error("OPEN_GAME_ERROR", "打开游戏失败: ${e.message}", null)
                }
            }
            

            "moveGamePlayer" -> {
                try {
                    val axisRealTurn = (args?.get("axisRealTurn") as? Number)?.toInt() ?: 0
                    val axisRealPitch = (args?.get("axisRealPitch") as? Number)?.toInt() ?: 0
                    val realSpeed = (args?.get("realSpeed") as? Number)?.toInt() ?: 0
                    val instantTurn = (args?.get("instantTurn") as? Number)?.toInt() ?: 0
                    val instantPitch = (args?.get("instantPitch") as? Number)?.toInt() ?: 0
                    val xAxisAccelerometer = (args?.get("xAxisAccelerometer") as? Number)?.toInt() ?: 0
                    val yAxisAccelerometer = (args?.get("yAxisAccelerometer") as? Number)?.toInt() ?: 0
                    val zAxisAccelerometer = (args?.get("zAxisAccelerometer") as? Number)?.toInt() ?: 0
                    val count = (args?.get("count") as? Number)?.toInt() ?: 0
                    
                    val sensorData = SMGameSensor(
                        axisRealTurn, axisRealPitch, realSpeed,
                        instantTurn, instantPitch, zAxisAccelerometer,
                        count, xAxisAccelerometer, yAxisAccelerometer
                    )
                    
                    SMGameClient.getInstance().movePlayer(1, sensorData)
                    result.success(true)
                } catch (e: Exception) {
                    Log.e("YongxinChannelHandler", "移动角色失败", e)
                    result.error("MOVE_PLAYER_ERROR", "移动角色失败: ${e.message}", null)
                }
            }

            "compressLogAndDataFiles" -> {
                val path = exportAndroidSdkLogsZip()
                sendLogToFlutter("导出 Android 勇芯日志结果: $path")
                result.success(path)
            }

            else -> result.notImplemented()
        }
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
    }

    private fun getTimeZone(): Byte {
        // 获取当前系统时区的偏移量(单位:小时)
        val offsetSeconds = TimeZone.getDefault().rawOffset / 1000 // 获取系统默认时区偏移里(毫秒转为秒)
        return (offsetSeconds / 3600).toByte() // 转换为小时并返回
    }

    // 开始监控连接状态
    private fun startConnectionMonitor(mac: String) {
        stopConnectionMonitor() // 先停止之前的监控
        
        sendLogToFlutter("🔍 [ConnectionMonitor] 开始监控连接状态, MAC: $mac")
        connectionMonitorHandler = Handler(Looper.getMainLooper())
        
        var checkCount = 0
        connectionMonitorRunnable = object : Runnable {
            override fun run() {
                checkCount++
                val isConnecting = BLEUtils.isConnecting()

                sendLogToFlutter("🔍 [ConnectionMonitor] 第${checkCount}次检查 (${checkCount * 2}秒) - isConnecting: $isConnecting")
                
                // 如果15秒后还没有任何回调，主动报告异常
                if (checkCount >= 5) {
                    sendLogToFlutter("⚠️ [ConnectionMonitor] 连接超过10秒仍无回调，可能SDK卡住")
                    sendLogToFlutter("⚠️ [ConnectionMonitor] 当前状态 - isConnecting: $isConnecting")
                }
                
                // 如果已经连接成功或失败，停止监控
                if (!isConnecting && checkCount > 1) {
                    sendLogToFlutter("✅ [ConnectionMonitor] 检测到状态变化，停止监控")
                    stopConnectionMonitor()
                    return
                }
                
                // 最多监控15秒（检查7次）
                if (checkCount < 7) {
                    connectionMonitorHandler?.postDelayed(this, 2000)
                } else {
                    sendLogToFlutter("❌ [ConnectionMonitor] 监控超时，主动断开并通知 Flutter")
                    try {
                        BLEUtils.disconnectBLE(application)
                    } catch (e: Exception) {
                        sendLogToFlutter("❌ [ConnectionMonitor] disconnectBLE failed: ${e.message}")
                    }
                    BLEUtils.setConnecting(false)
                    BLEUtils.setConnected(false)
                    BLEUtils.setGetToken(false)
                    connectedDevice = null
                    directConnectedMac = null
                    broadcastManager.sendBroadcast(Intent(BroadcastManager.ACTION_RING_DISCONNECTED))
                    stopConnectionMonitor()
                }
            }
        }
        
        connectionMonitorHandler?.postDelayed(connectionMonitorRunnable!!, 2000)
    }
    
    // 停止监控连接状态
    private fun stopConnectionMonitor() {
        connectionMonitorRunnable?.let {
            connectionMonitorHandler?.removeCallbacks(it)
        }
        connectionMonitorHandler = null
        connectionMonitorRunnable = null
    }
    
    private fun ringDataToMap(ringData: HistoryDataBean): Map<String, Any> {
        val rrValues = mutableListOf<Int>()
        val rrsData = ringData.rrBytes
        if (rrsData != null && rrsData.size >= 2) {
            for (i in rrsData.indices step 2) {
                if (i + 1 < rrsData.size) {
                    val lowByte = rrsData[i].toInt() and 0xFF
                    val highByte = rrsData[i + 1].toInt() and 0xFF
                    val value = lowByte or (highByte shl 8)
                    rrValues.add(value)
                }
            }
        }


        val result = mutableMapOf<String, Any>(
            "total" to ringData.totalNumber,
            "serialNum" to ringData.indexNumber,
            "timestamp" to ringData.time,
            "steps" to ringData.stepCount,
            "rate" to ringData.heartRate,
            "o2" to ringData.bloodOxygen,
            "hrv" to ringData.heartRateVariability,
            "stress" to ringData.stressIndex,
            "temp" to ringData.temperature.toDouble() / 100,
            "sleep_type" to ringData.sleepType,
            "rr_nums" to ringData.rrCount,
            "rrs" to rrValues,
            "reserve_battery" to ringData.reserve,
            "sport" to ringData.exerciseIntensity,
            "is_wear" to ringData.measurementMarker
        )

        // 新增扩展字段（GoMore固件等场景可能有值）
        // 使用反射安全读取，兼容不同SDK版本
        val extFields = mapOf(
            "step_counting_type" to "stepCountingType",
            "measure_type" to "measureType",
            "steps_per_unit_time" to "stepsPerUnitTime",
            "accumulation_flag" to "accumulationFlag",
            "battery_level" to "batteryLevel",
            "battery_voltage" to "batteryVoltage",
            "not_worn_reason" to "notWornReason",
            "record_calibration_flag" to "recordCalibrationFlag",
            "ambient_light_intensity_factor" to "ambientLightIntensityFactor",
            "step_rate_max" to "stepRateMax",
            "step_rate_min" to "stepRateMin",
            "breathing_rate" to "breathingRate",
            "breathing_rate_confidence" to "breathingRateConfidence",
            "activity_status" to "activityStatus",
            "total_calories" to "totalCalories",
            "basal_metabolic_calories" to "basalMetabolicCalories",
            "exercise_calories" to "exerciseCalories",
            "hard_adt" to "hardAdt",
            "high_blood_pressure" to "highBloodPressure",
            "low_blood_pressure" to "lowBloodPressure"
        )
        for ((key, fieldName) in extFields) {
            try {
                val field = ringData.javaClass.getDeclaredField(fieldName)
                field.isAccessible = true
                val value = field.get(ringData)
                if (value != null) {
                    result[key] = value
                }
            } catch (_: Exception) {
                // 字段不存在，跳过
            }
        }

        return result
    }
    

    
    // 处理游戏关闭事件
    private fun handleGameClose() {
        try {
            val game = recentPlayedGame
            val startTime = recentGameStartTime
            
            Log.d("YongxinChannelHandler", "游戏SDK回调关闭事件触发, 游戏: ${game?.gname ?: "null"}")
            
            // 停止传感器数据读取
            try {
                sendLogToFlutter("停止读取传感器数据")
                LmAPI.STOP_PLAY_SHIMMI(axisListener)
                sendLogToFlutter("成功停止传感器数据读取")
                Log.d("YongxinChannelHandler", "游戏关闭回调：已停止传感器数据读取")
            } catch (e: Exception) {
                Log.e("YongxinChannelHandler", "游戏关闭回调：停止传感器失败", e)
                sendLogToFlutter("停止传感器失败: ${e.message}")
            }
            
            if (game != null && startTime != 0L) {
                val endTime = System.currentTimeMillis()
                val duration = (endTime - startTime) / 1000
                
                val gameInfo = HashMap<String, Any>()
                gameInfo["gameId"] = game.gid
                gameInfo["gameName"] = game.gname
                gameInfo["startTime"] = startTime / 1000.0
                gameInfo["endTime"] = endTime / 1000.0
                gameInfo["duration"] = duration
                
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Log.d("YongxinChannelHandler", "发送游戏关闭事件到Flutter")
                    eventSink?.success(mapOf(
                        "event" to "onWillCloseGame",
                        "data" to gameInfo
                    ))
                }
                sendLogToFlutter("游戏将要关闭: ${game.gname}, 游戏时长: ${duration}秒")
                Log.d("YongxinChannelHandler", "游戏将要关闭: ${game.gname}, 游戏时长: ${duration}秒")
                
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    Log.d("YongxinChannelHandler", "清除游戏记录")
                    recentPlayedGame = null
                    recentGameStartTime = 0
                }, 500)
            }
        } catch (e: Exception) {
            Log.e("YongxinChannelHandler", "处理游戏关闭事件异常", e)
        }
    }
}
