package com.example.yongxin_ring

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothAdapter.LeScanCallback
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.text.TextUtils
import android.util.Log
import android.view.MotionEvent
import android.view.Window
import com.lm.sdk.DataApi
import com.lm.sdk.LmAPI
import com.lm.sdk.LogicalApi
import com.lm.sdk.inter.IHeartListener
import com.lm.sdk.inter.IHistoryListener
import com.lm.sdk.inter.IQ2Listener
import com.lm.sdk.inter.IResponseListener
import com.lm.sdk.inter.ITempListener
import com.lm.sdk.mode.BleDeviceInfo
import com.lm.sdk.mode.HistoryDataBean
import com.lm.sdk.mode.SystemControlBean
import com.lm.sdk.utils.BLEUtils
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.EventChannel.StreamHandler
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import java.text.SimpleDateFormat
import java.util.*

/** YongxinRingPlugin */
class YongxinRingPlugin : FlutterPlugin,ActivityAware  {

    companion object {
        @JvmStatic
        var activity: Activity? = null
    }

    /// The MethodChannel that will the communication between Flutter and native Android
    ///
    /// This local reference serves to register the plugin with the Flutter Engine and unregister it
    /// when the Flutter Engine is detached from the Activity
    private lateinit var channel: MethodChannel
    private lateinit var eventChannel: EventChannel

    private lateinit var application: Application
    private lateinit var binaryMessenger: BinaryMessenger
    private var originalWindowCallback: Window.Callback? = null
    private var touchGuardInstalled = false

    override fun onAttachedToEngine(flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
        binaryMessenger = flutterPluginBinding.binaryMessenger
        application = flutterPluginBinding.applicationContext as Application

        channel = MethodChannel(binaryMessenger, "yongxin_ring")
        eventChannel = EventChannel(binaryMessenger, "yongxin_ring_events")
        val channelHandler = YongxinChannelHandler(application)
        channel.setMethodCallHandler(channelHandler)
        eventChannel.setStreamHandler(channelHandler)

        LmAPI.setDebug(true)
        LmAPI.init(application)
        val broadcastManager = BroadcastManager(application)
        val listener = YongxinResponseListener(broadcastManager)
        LmAPI.addWLSCmdListener(application, listener)
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel.setMethodCallHandler(null)
        eventChannel.setStreamHandler(null)
    }

    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        activity = binding.activity
        installDetachedFlutterTouchGuard(binding.activity)
    }

    override fun onDetachedFromActivityForConfigChanges() {
        uninstallDetachedFlutterTouchGuard()
    }

    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        activity = binding.activity
        installDetachedFlutterTouchGuard(binding.activity)
    }

    override fun onDetachedFromActivity() {
        uninstallDetachedFlutterTouchGuard()
        activity = null
    }

    private fun installDetachedFlutterTouchGuard(currentActivity: Activity) {
        val window = currentActivity.window
        if (touchGuardInstalled) {
            return
        }
        val callback = window.callback
        if (callback is DetachedFlutterTouchGuardCallback) {
            return
        }
        originalWindowCallback = callback
        window.callback = DetachedFlutterTouchGuardCallback(callback)
        touchGuardInstalled = true
        Log.i("YongxinRingPlugin", "Installed detached Flutter touch guard")
    }

    private fun uninstallDetachedFlutterTouchGuard() {
        val currentActivity = activity
        if (currentActivity == null || !touchGuardInstalled) {
            return
        }
        val window = currentActivity.window
        val installedCallback = window.callback
        if (installedCallback is DetachedFlutterTouchGuardCallback) {
            window.callback = originalWindowCallback ?: installedCallback
        }
        originalWindowCallback = null
        touchGuardInstalled = false
        Log.i("YongxinRingPlugin", "Restored original window callback")
    }

    private class DetachedFlutterTouchGuardCallback(
        private val delegate: Window.Callback
    ) : Window.Callback by delegate {
        override fun dispatchTouchEvent(event: MotionEvent): Boolean {
            return try {
                delegate.dispatchTouchEvent(event)
            } catch (e: RuntimeException) {
                if (e.message?.contains("FlutterJNI is not attached to native") == true) {
                    Log.w("YongxinRingPlugin", "Drop detached Flutter touch event")
                    true
                } else {
                    throw e
                }
            }
        }
    }
}
