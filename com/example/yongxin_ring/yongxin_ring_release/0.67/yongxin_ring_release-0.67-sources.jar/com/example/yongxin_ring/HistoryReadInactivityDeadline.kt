package com.example.yongxin_ring

import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/** Packet activity extends a history read; its age alone must not abort a large transfer. */
internal class HistoryReadInactivityDeadline(
    private val initialTimeoutMillis: Long,
    private val progressTimeoutMillis: Long,
    startedAtMillis: Long
) {
    private val lastActivity = AtomicLong(startedAtMillis)
    private val receivedProgress = AtomicBoolean(false)

    fun onProgress(nowMillis: Long) {
        lastActivity.set(nowMillis)
        receivedProgress.set(true)
    }

    fun remainingMillis(nowMillis: Long): Long {
        val limit = if (receivedProgress.get()) progressTimeoutMillis else initialTimeoutMillis
        return (limit - (nowMillis - lastActivity.get()).coerceAtLeast(0)).coerceAtLeast(0)
    }
}
