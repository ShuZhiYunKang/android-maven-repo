package com.example.yongxin_ring

/** Serializes vendor callbacks with connection/cancellation on the main thread.
 * The SDK supplies no attempt ID. Capture our session when a callback arrives so
 * callbacks already queued before cancellation cannot mutate a later session.
 */
internal class RingConnectionCallbackGuard(
    private val dispatch: (() -> Unit) -> Unit,
    private val onLateCallback: () -> Unit,
    private val log: (String) -> Unit,
    private val schedule: (Long, () -> Unit) -> Unit,
    private val isTargetConnected: () -> Boolean = { true }
) {
    enum class Event { CONNECTING, CONNECTED, DISCONNECTED }
    private class Session {
        var connected = false
        var disconnectCheckPending = false
    }
    @Volatile private var session: Session? = null
    @Volatile var generation = 0L
        private set
    private var recoveryRequested = false
    private var disposed = false
    val hasActiveConnection: Boolean get() = session != null

    fun begin() {
        check(!disposed)
        generation++
        session = Session()
        recoveryRequested = false
    }

    fun invalidate() {
        generation++
        session = null
    }

    fun dispose() {
        disposed = true
        invalidate()
    }

    fun deliver(event: Event, callback: (Long) -> Unit) {
        val observedSession = session
        val observedGeneration = generation
        dispatch {
            if (disposed || observedSession !== session || observedGeneration != generation) {
                log("ignored queued $event from an ended session")
                return@dispatch
            }
            val active = session
            if (active == null && event != Event.DISCONNECTED) {
                log("ignored late $event without an active connection")
                // One recovery per cancelled/failed session. Further vendor noise
                // must not create a loop of disconnect requests or new connects.
                if (!recoveryRequested) {
                    recoveryRequested = true
                    onLateCallback()
                }
                return@dispatch
            }
            when (event) {
                Event.CONNECTING -> if (active!!.connected) {
                    log("ignored CONNECTING after connection succeeded")
                    return@dispatch
                }
                Event.CONNECTED -> {
                    // Untagged vendor callbacks arriving AFTER a new request
                    // cannot be assigned by generation alone. Require Android
                    // to confirm that request's actual target before success.
                    if (!runCatching { isTargetConnected() }.getOrDefault(false)) {
                        log("ignored CONNECTED without target GATT confirmation")
                        invalidate()
                        if (!recoveryRequested) {
                            recoveryRequested = true
                            onLateCallback()
                        }
                        return@dispatch
                    }
                    active!!.connected = true
                }
                Event.DISCONNECTED -> {
                    if (active != null) {
                        // An untagged failure arriving after begin() may belong
                        // to the previous attempt. Before success, only the
                        // existing connection deadline can fail this attempt.
                        if (!active.connected) {
                            log("ignored unassigned DISCONNECTED during connection attempt")
                            return@dispatch
                        }
                        if (!active.disconnectCheckPending) {
                            active.disconnectCheckPending = true
                            confirmDisconnected(active, callback)
                        }
                        return@dispatch
                    }
                    // With no active attempt, still deliver terminal events to
                    // let an explicit disconnect/cancellation finish draining.
                    invalidate()
                }
            }
            callback(generation)
        }
    }

    private fun confirmDisconnected(
        active: Session,
        callback: (Long) -> Unit,
        remainingChecks: Int = 25
    ) {
        if (disposed || session !== active) return
        if (runCatching { isTargetConnected() }.getOrNull() == false) {
            invalidate()
            callback(generation)
            return
        }
        // Android's GATT list can lag the SDK failure callback. Recheck for a
        // bounded 2.5s; duplicate callbacks share this check, and a replacement
        // session invalidates it. A read error is not proof of disconnection.
        if (remainingChecks == 0) {
            active.disconnectCheckPending = false
            log("ignored DISCONNECTED without target GATT disconnection")
            return
        }
        schedule(100L) { confirmDisconnected(active, callback, remainingChecks - 1) }
    }
}
