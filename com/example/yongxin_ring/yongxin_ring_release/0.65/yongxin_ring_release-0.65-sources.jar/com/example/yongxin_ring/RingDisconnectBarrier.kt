package com.example.yongxin_ring

/** Main-thread barrier between an SDK disconnect request and the next connection.
 *
 * The SDK's disconnect method returns before its untagged broadcast is delivered.
 * Release callers only after the transport is disconnected and events have settled.
 */
internal class RingDisconnectBarrier(
    private val requestDisconnect: () -> Unit,
    private val isTransportDisconnected: () -> Boolean,
    private val nowMillis: () -> Long,
    private val schedule: (Long, () -> Unit) -> Unit,
    private val log: (String) -> Unit,
    private val isSdkIdle: () -> Boolean = { true },
    private val onTransportVerified: () -> Unit = {},
    private val timeoutMillis: Long = 2_500L,
    private val missingEventWaitMillis: Long = 1_500L,
    private val quietMillis: Long = 250L,
    private val pollMillis: Long = 50L,
    private val maximumWaitMillis: Long = 5_000L
) {
    private class Pending(val startedAt: Long) {
        val waiters = mutableListOf<(Boolean) -> Unit>()
        var lastEventAt: Long? = null
        var disconnectedSince: Long? = null
    }

    private var pending: Pending? = null
    private var blocked = false
    val isPending: Boolean get() = pending != null
    val canConnect: Boolean get() = pending == null && !blocked

    fun disconnect(onComplete: (Boolean) -> Unit) {
        pending?.let {
            it.waiters.add(onComplete)
            return
        }
        val operation = Pending(nowMillis())
        operation.waiters.add(onComplete)
        pending = operation
        blocked = true
        try {
            requestDisconnect()
            log("requested")
            check(operation)
        } catch (e: Exception) {
            finish(operation, false, "request failed: $e")
        }
    }

    fun onDisconnected(verifyIdleTransport: Boolean = false) {
        // A late SDK terminal event can recover a previously timed-out barrier,
        // but must never restart a cancelled connection or complete old waiters.
        // A spontaneous disconnect also needs physical confirmation before the
        // handler retires its targets. This path sends no new SDK disconnect.
        val operation = pending ?: if (blocked || verifyIdleTransport) {
            Pending(nowMillis()).also {
                blocked = true
                pending = it
                scheduleCheck(it)
            }
        } else {
            return
        }
        operation.lastEventAt = nowMillis()
        operation.disconnectedSince = null
    }

    fun cancelWaiters() {
        pending?.let { finish(it, false, "cancelled") }
    }

    private fun scheduleCheck(operation: Pending) {
        schedule(pollMillis) { check(operation) }
    }

    private fun check(operation: Pending) {
        if (pending !== operation) return
        val now = nowMillis()
        val disconnected = try {
            isTransportDisconnected()
        } catch (e: Exception) {
            finish(operation, false, "state unavailable: $e")
            return
        }
        if (disconnected) {
            if (operation.disconnectedSince == null) operation.disconnectedSince = now
            val observedAt = operation.lastEventAt
            val eventSettled = if (observedAt != null) {
                now - observedAt >= quietMillis
            } else {
                now - operation.startedAt >= missingEventWaitMillis
            }
            // Stale SDK flags can survive a cancelled native attempt. Only
            // repair them after the physical transport stays absent for the
            // longer settle period, never on a broadcast alone.
            val requiredStableMillis = try {
                if (isSdkIdle()) quietMillis else missingEventWaitMillis
            } catch (e: Exception) {
                finish(operation, false, "SDK state unavailable: $e")
                return
            }
            if (eventSettled && now - operation.disconnectedSince!! >= requiredStableMillis) {
                try {
                    onTransportVerified()
                } catch (e: Exception) {
                    finish(operation, false, "SDK reset failed: $e")
                    return
                }
                finish(operation, true, if (observedAt == null) "transport verified" else "event settled")
                return
            }
        } else {
            operation.disconnectedSince = null
        }
        val requestDeadline = operation.startedAt + timeoutMillis
        // GATT can disappear after the terminal broadcast. Give the first
        // physical absence observation its own full stability window, even if
        // the broadcast is missing. Neither broadcasts nor GATT flapping may
        // extend the fixed total limit.
        val settleWindow = maxOf(quietMillis, missingEventWaitMillis) + pollMillis
        val settleStart = maxOf(operation.lastEventAt ?: operation.startedAt,
            operation.disconnectedSince ?: operation.startedAt)
        val deadline = minOf(operation.startedAt + maximumWaitMillis,
            maxOf(requestDeadline, settleStart + settleWindow))
        if (now >= deadline) {
            finish(operation, false, "timeout; reconnect blocked")
        } else {
            scheduleCheck(operation)
        }
    }

    private fun finish(operation: Pending, success: Boolean, reason: String) {
        if (pending !== operation) return
        pending = null
        blocked = !success
        log("completed success=$success elapsedMs=${nowMillis() - operation.startedAt} reason=$reason")
        val waiters = operation.waiters.toList()
        operation.waiters.clear()
        waiters.forEach { it(success) }
    }
}
