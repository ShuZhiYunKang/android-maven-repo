package com.example.yongxin_ring

import android.content.BroadcastReceiver
import android.os.Handler
import io.flutter.plugin.common.MethodChannel.Result

/** One GET_COLLECTION request. All callbacks run on the Android main thread. */
internal class RingFrequencyReader(
    private val broadcasts: BroadcastManager,
    private val handler: Handler,
    private val currentMac: () -> String?,
    private val isReady: () -> Boolean,
    private val send: () -> Unit,
    private val result: Result,
    private val expectedMac: String? = null,
    private val isBusy: () -> Boolean = { false },
    private val log: (String) -> Unit = {}
) {
    private val receivers = mutableListOf<BroadcastReceiver>()
    private var started = false
    private var finished = false
    private var targetMac: String? = null
    private val timeout = Runnable { fail("FREQUENCY_TIMEOUT", "No frequency response within 10s") }

    fun start() {
        if (started) return
        started = true
        try {
            targetMac = currentMac()
            if (!isReady() || targetMac.isNullOrEmpty()) {
                fail("FREQUENCY_NOT_CONNECTED", "Ring is not ready for frequency read")
                return
            }
            if (expectedMac != null && !expectedMac.equals(targetMac, ignoreCase = true)) {
                fail("FREQUENCY_DEVICE_CHANGED", "Frequency read target has changed")
                return
            }
            if (isBusy()) {
                fail("FREQUENCY_BUSY", "History or sleep transfer is still active")
                return
            }
            receivers += broadcasts.registerReceiver(BroadcastManager.ACTION_RING_GET_COLLECTION) { intent, _ ->
                if (!finished) {
                    if (!isReady() || !targetMac.equals(currentMac(), ignoreCase = true)) {
                        fail("FREQUENCY_DEVICE_CHANGED", "Ring changed during frequency read")
                    } else {
                        val frequency = intent.getIntExtra("p0", 0)
                        finish { result.success(frequency) }
                    }
                }
            }
            receivers += broadcasts.registerReceiver(BroadcastManager.ACTION_RING_DISCONNECTED) { _, _ ->
                cancel("BLE disconnected")
            }
            // SDK instruction timeouts carry no command identity and may be
            // from battery/charging reads. Only this request's timer may expire it.
            handler.postDelayed(timeout, 10_000L)
            send()
        } catch (error: Exception) {
            fail("FREQUENCY_READ_FAILED", error.message ?: "Frequency command failed")
        }
    }

    fun cancel(reason: String) {
        fail("FREQUENCY_DISCONNECTED", reason)
    }

    private fun fail(code: String, message: String) {
        finish {
            log("readFrequency failed mac=$targetMac code=$code reason=$message")
            result.error(code, message, null)
        }
    }

    private fun finish(complete: () -> Unit) {
        if (finished) return
        finished = true
        handler.removeCallbacks(timeout)
        receivers.forEach { broadcasts.unregisterReceiver(it) }
        receivers.clear()
        log("readFrequency completed mac=$targetMac")
        complete()
    }
}
