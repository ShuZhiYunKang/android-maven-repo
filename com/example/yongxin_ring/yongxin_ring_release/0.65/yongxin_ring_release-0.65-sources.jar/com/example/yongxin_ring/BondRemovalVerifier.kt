package com.example.yongxin_ring

import android.bluetooth.BluetoothDevice

internal data class BondRemovalResult(
    val removed: Boolean,
    val bondState: Int?,
    val error: String? = null
)

/** SDK removeBond returns void; only BOND_NONE confirms that pairing was removed. */
internal class BondRemovalVerifier(
    private val readBondState: () -> Int,
    private val requestRemoval: () -> Unit,
    private val nowMillis: () -> Long,
    private val schedule: (Long, () -> Unit) -> Unit,
    private val onComplete: (BondRemovalResult) -> Unit,
    private val timeoutMillis: Long = 3_000L,
    private val pollMillis: Long = 150L
) {
    private var started = false
    private var finished = false
    private var startedAt = 0L

    fun start() {
        if (started) return
        started = true
        startedAt = nowMillis()
        try {
            if (readBondState() != BluetoothDevice.BOND_NONE) requestRemoval()
        } catch (e: Exception) {
            finish(BondRemovalResult(false, null, e.toString()))
            return
        }
        checkState()
    }

    private fun checkState() {
        if (finished) return
        val state = try {
            readBondState()
        } catch (e: Exception) {
            finish(BondRemovalResult(false, null, e.toString()))
            return
        }
        if (state == BluetoothDevice.BOND_NONE) {
            finish(BondRemovalResult(true, state))
            return
        }
        val remaining = timeoutMillis - (nowMillis() - startedAt)
        if (remaining <= 0L) {
            finish(BondRemovalResult(false, state, "bond removal timed out"))
            return
        }
        schedule(minOf(pollMillis, remaining), ::checkState)
    }

    private fun finish(result: BondRemovalResult) {
        if (finished) return
        finished = true
        onComplete(result)
    }
}
